	component multicore_access_controller_v4 is
		port (
			clk_clk                                               : in  std_logic                     := 'X';             -- clk
			compare_and_swap_0_db_signals_db_address_output       : out std_logic_vector(31 downto 0);                    -- db_address_output
			compare_and_swap_0_db_signals_db_done_output          : out std_logic;                                        -- db_done_output
			compare_and_swap_0_db_signals_db_expecteddata_output  : out std_logic_vector(31 downto 0);                    -- db_expecteddata_output
			compare_and_swap_0_db_signals_db_newdata_index_output : out std_logic_vector(7 downto 0);                     -- db_newdata_index_output
			compare_and_swap_0_db_signals_db_reset                : in  std_logic                     := 'X';             -- db_reset
			compare_and_swap_0_db_signals_db_start_output         : out std_logic;                                        -- db_start_output
			compare_and_swap_1_db_signals_db_address_output       : out std_logic_vector(31 downto 0);                    -- db_address_output
			compare_and_swap_1_db_signals_db_done_output          : out std_logic;                                        -- db_done_output
			compare_and_swap_1_db_signals_db_expecteddata_output  : out std_logic_vector(31 downto 0);                    -- db_expecteddata_output
			compare_and_swap_1_db_signals_db_newdata_index_output : out std_logic_vector(7 downto 0);                     -- db_newdata_index_output
			compare_and_swap_1_db_signals_db_reset                : in  std_logic                     := 'X';             -- db_reset
			compare_and_swap_1_db_signals_db_start_output         : out std_logic;                                        -- db_start_output
			dma_0_control_port_slave_address                      : in  std_logic_vector(2 downto 0)  := (others => 'X'); -- address
			dma_0_control_port_slave_chipselect                   : in  std_logic                     := 'X';             -- chipselect
			dma_0_control_port_slave_readdata                     : out std_logic_vector(15 downto 0);                    -- readdata
			dma_0_control_port_slave_write_n                      : in  std_logic                     := 'X';             -- write_n
			dma_0_control_port_slave_writedata                    : in  std_logic_vector(15 downto 0) := (others => 'X'); -- writedata
			entrada_nios_ii_0_external_connection_export          : in  std_logic_vector(7 downto 0)  := (others => 'X'); -- export
			entrada_nios_ii_1_external_connection_export          : in  std_logic_vector(7 downto 0)  := (others => 'X'); -- export
			hexa7seg_external_connection_export                   : out std_logic_vector(23 downto 0);                    -- export
			lag_0_users_input_us_delay                            : in  std_logic_vector(3 downto 0)  := (others => 'X'); -- us_delay
			lag_0_users_input_go                                  : in  std_logic                     := 'X';             -- go
			lag_1_users_input_us_delay                            : in  std_logic_vector(3 downto 0)  := (others => 'X'); -- us_delay
			lag_1_users_input_go                                  : in  std_logic                     := 'X';             -- go
			reset_reset_n                                         : in  std_logic                     := 'X';             -- reset_n
			saida_nios_ii_0_external_connection_export            : out std_logic_vector(7 downto 0);                     -- export
			saida_nios_ii_1_external_connection_export            : out std_logic_vector(7 downto 0)                      -- export
		);
	end component multicore_access_controller_v4;

	u0 : component multicore_access_controller_v4
		port map (
			clk_clk                                               => CONNECTED_TO_clk_clk,                                               --                                   clk.clk
			compare_and_swap_0_db_signals_db_address_output       => CONNECTED_TO_compare_and_swap_0_db_signals_db_address_output,       --         compare_and_swap_0_db_signals.db_address_output
			compare_and_swap_0_db_signals_db_done_output          => CONNECTED_TO_compare_and_swap_0_db_signals_db_done_output,          --                                      .db_done_output
			compare_and_swap_0_db_signals_db_expecteddata_output  => CONNECTED_TO_compare_and_swap_0_db_signals_db_expecteddata_output,  --                                      .db_expecteddata_output
			compare_and_swap_0_db_signals_db_newdata_index_output => CONNECTED_TO_compare_and_swap_0_db_signals_db_newdata_index_output, --                                      .db_newdata_index_output
			compare_and_swap_0_db_signals_db_reset                => CONNECTED_TO_compare_and_swap_0_db_signals_db_reset,                --                                      .db_reset
			compare_and_swap_0_db_signals_db_start_output         => CONNECTED_TO_compare_and_swap_0_db_signals_db_start_output,         --                                      .db_start_output
			compare_and_swap_1_db_signals_db_address_output       => CONNECTED_TO_compare_and_swap_1_db_signals_db_address_output,       --         compare_and_swap_1_db_signals.db_address_output
			compare_and_swap_1_db_signals_db_done_output          => CONNECTED_TO_compare_and_swap_1_db_signals_db_done_output,          --                                      .db_done_output
			compare_and_swap_1_db_signals_db_expecteddata_output  => CONNECTED_TO_compare_and_swap_1_db_signals_db_expecteddata_output,  --                                      .db_expecteddata_output
			compare_and_swap_1_db_signals_db_newdata_index_output => CONNECTED_TO_compare_and_swap_1_db_signals_db_newdata_index_output, --                                      .db_newdata_index_output
			compare_and_swap_1_db_signals_db_reset                => CONNECTED_TO_compare_and_swap_1_db_signals_db_reset,                --                                      .db_reset
			compare_and_swap_1_db_signals_db_start_output         => CONNECTED_TO_compare_and_swap_1_db_signals_db_start_output,         --                                      .db_start_output
			dma_0_control_port_slave_address                      => CONNECTED_TO_dma_0_control_port_slave_address,                      --              dma_0_control_port_slave.address
			dma_0_control_port_slave_chipselect                   => CONNECTED_TO_dma_0_control_port_slave_chipselect,                   --                                      .chipselect
			dma_0_control_port_slave_readdata                     => CONNECTED_TO_dma_0_control_port_slave_readdata,                     --                                      .readdata
			dma_0_control_port_slave_write_n                      => CONNECTED_TO_dma_0_control_port_slave_write_n,                      --                                      .write_n
			dma_0_control_port_slave_writedata                    => CONNECTED_TO_dma_0_control_port_slave_writedata,                    --                                      .writedata
			entrada_nios_ii_0_external_connection_export          => CONNECTED_TO_entrada_nios_ii_0_external_connection_export,          -- entrada_nios_ii_0_external_connection.export
			entrada_nios_ii_1_external_connection_export          => CONNECTED_TO_entrada_nios_ii_1_external_connection_export,          -- entrada_nios_ii_1_external_connection.export
			hexa7seg_external_connection_export                   => CONNECTED_TO_hexa7seg_external_connection_export,                   --          hexa7seg_external_connection.export
			lag_0_users_input_us_delay                            => CONNECTED_TO_lag_0_users_input_us_delay,                            --                     lag_0_users_input.us_delay
			lag_0_users_input_go                                  => CONNECTED_TO_lag_0_users_input_go,                                  --                                      .go
			lag_1_users_input_us_delay                            => CONNECTED_TO_lag_1_users_input_us_delay,                            --                     lag_1_users_input.us_delay
			lag_1_users_input_go                                  => CONNECTED_TO_lag_1_users_input_go,                                  --                                      .go
			reset_reset_n                                         => CONNECTED_TO_reset_reset_n,                                         --                                 reset.reset_n
			saida_nios_ii_0_external_connection_export            => CONNECTED_TO_saida_nios_ii_0_external_connection_export,            --   saida_nios_ii_0_external_connection.export
			saida_nios_ii_1_external_connection_export            => CONNECTED_TO_saida_nios_ii_1_external_connection_export             --   saida_nios_ii_1_external_connection.export
		);

