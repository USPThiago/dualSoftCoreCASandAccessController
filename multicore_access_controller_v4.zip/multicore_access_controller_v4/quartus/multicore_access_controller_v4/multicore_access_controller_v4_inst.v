	multicore_access_controller_v4 u0 (
		.clk_clk                                               (<connected-to-clk_clk>),                                               //                                   clk.clk
		.compare_and_swap_0_db_signals_db_address_output       (<connected-to-compare_and_swap_0_db_signals_db_address_output>),       //         compare_and_swap_0_db_signals.db_address_output
		.compare_and_swap_0_db_signals_db_done_output          (<connected-to-compare_and_swap_0_db_signals_db_done_output>),          //                                      .db_done_output
		.compare_and_swap_0_db_signals_db_expecteddata_output  (<connected-to-compare_and_swap_0_db_signals_db_expecteddata_output>),  //                                      .db_expecteddata_output
		.compare_and_swap_0_db_signals_db_newdata_index_output (<connected-to-compare_and_swap_0_db_signals_db_newdata_index_output>), //                                      .db_newdata_index_output
		.compare_and_swap_0_db_signals_db_reset                (<connected-to-compare_and_swap_0_db_signals_db_reset>),                //                                      .db_reset
		.compare_and_swap_0_db_signals_db_start_output         (<connected-to-compare_and_swap_0_db_signals_db_start_output>),         //                                      .db_start_output
		.compare_and_swap_1_db_signals_db_address_output       (<connected-to-compare_and_swap_1_db_signals_db_address_output>),       //         compare_and_swap_1_db_signals.db_address_output
		.compare_and_swap_1_db_signals_db_done_output          (<connected-to-compare_and_swap_1_db_signals_db_done_output>),          //                                      .db_done_output
		.compare_and_swap_1_db_signals_db_expecteddata_output  (<connected-to-compare_and_swap_1_db_signals_db_expecteddata_output>),  //                                      .db_expecteddata_output
		.compare_and_swap_1_db_signals_db_newdata_index_output (<connected-to-compare_and_swap_1_db_signals_db_newdata_index_output>), //                                      .db_newdata_index_output
		.compare_and_swap_1_db_signals_db_reset                (<connected-to-compare_and_swap_1_db_signals_db_reset>),                //                                      .db_reset
		.compare_and_swap_1_db_signals_db_start_output         (<connected-to-compare_and_swap_1_db_signals_db_start_output>),         //                                      .db_start_output
		.dma_0_control_port_slave_address                      (<connected-to-dma_0_control_port_slave_address>),                      //              dma_0_control_port_slave.address
		.dma_0_control_port_slave_chipselect                   (<connected-to-dma_0_control_port_slave_chipselect>),                   //                                      .chipselect
		.dma_0_control_port_slave_readdata                     (<connected-to-dma_0_control_port_slave_readdata>),                     //                                      .readdata
		.dma_0_control_port_slave_write_n                      (<connected-to-dma_0_control_port_slave_write_n>),                      //                                      .write_n
		.dma_0_control_port_slave_writedata                    (<connected-to-dma_0_control_port_slave_writedata>),                    //                                      .writedata
		.entrada_nios_ii_0_external_connection_export          (<connected-to-entrada_nios_ii_0_external_connection_export>),          // entrada_nios_ii_0_external_connection.export
		.entrada_nios_ii_1_external_connection_export          (<connected-to-entrada_nios_ii_1_external_connection_export>),          // entrada_nios_ii_1_external_connection.export
		.hexa7seg_external_connection_export                   (<connected-to-hexa7seg_external_connection_export>),                   //          hexa7seg_external_connection.export
		.lag_0_users_input_us_delay                            (<connected-to-lag_0_users_input_us_delay>),                            //                     lag_0_users_input.us_delay
		.lag_0_users_input_go                                  (<connected-to-lag_0_users_input_go>),                                  //                                      .go
		.lag_1_users_input_us_delay                            (<connected-to-lag_1_users_input_us_delay>),                            //                     lag_1_users_input.us_delay
		.lag_1_users_input_go                                  (<connected-to-lag_1_users_input_go>),                                  //                                      .go
		.reset_reset_n                                         (<connected-to-reset_reset_n>),                                         //                                 reset.reset_n
		.saida_nios_ii_0_external_connection_export            (<connected-to-saida_nios_ii_0_external_connection_export>),            //   saida_nios_ii_0_external_connection.export
		.saida_nios_ii_1_external_connection_export            (<connected-to-saida_nios_ii_1_external_connection_export>)             //   saida_nios_ii_1_external_connection.export
	);

