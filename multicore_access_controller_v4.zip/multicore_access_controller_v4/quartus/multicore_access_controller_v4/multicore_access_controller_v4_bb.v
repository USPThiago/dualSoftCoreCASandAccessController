
module multicore_access_controller_v4 (
	clk_clk,
	compare_and_swap_0_db_signals_db_address_output,
	compare_and_swap_0_db_signals_db_done_output,
	compare_and_swap_0_db_signals_db_expecteddata_output,
	compare_and_swap_0_db_signals_db_newdata_index_output,
	compare_and_swap_0_db_signals_db_reset,
	compare_and_swap_0_db_signals_db_start_output,
	compare_and_swap_1_db_signals_db_address_output,
	compare_and_swap_1_db_signals_db_done_output,
	compare_and_swap_1_db_signals_db_expecteddata_output,
	compare_and_swap_1_db_signals_db_newdata_index_output,
	compare_and_swap_1_db_signals_db_reset,
	compare_and_swap_1_db_signals_db_start_output,
	dma_0_control_port_slave_address,
	dma_0_control_port_slave_chipselect,
	dma_0_control_port_slave_readdata,
	dma_0_control_port_slave_write_n,
	dma_0_control_port_slave_writedata,
	entrada_nios_ii_0_external_connection_export,
	entrada_nios_ii_1_external_connection_export,
	hexa7seg_external_connection_export,
	lag_0_users_input_us_delay,
	lag_0_users_input_go,
	lag_1_users_input_us_delay,
	lag_1_users_input_go,
	reset_reset_n,
	saida_nios_ii_0_external_connection_export,
	saida_nios_ii_1_external_connection_export);	

	input		clk_clk;
	output	[31:0]	compare_and_swap_0_db_signals_db_address_output;
	output		compare_and_swap_0_db_signals_db_done_output;
	output	[31:0]	compare_and_swap_0_db_signals_db_expecteddata_output;
	output	[7:0]	compare_and_swap_0_db_signals_db_newdata_index_output;
	input		compare_and_swap_0_db_signals_db_reset;
	output		compare_and_swap_0_db_signals_db_start_output;
	output	[31:0]	compare_and_swap_1_db_signals_db_address_output;
	output		compare_and_swap_1_db_signals_db_done_output;
	output	[31:0]	compare_and_swap_1_db_signals_db_expecteddata_output;
	output	[7:0]	compare_and_swap_1_db_signals_db_newdata_index_output;
	input		compare_and_swap_1_db_signals_db_reset;
	output		compare_and_swap_1_db_signals_db_start_output;
	input	[2:0]	dma_0_control_port_slave_address;
	input		dma_0_control_port_slave_chipselect;
	output	[15:0]	dma_0_control_port_slave_readdata;
	input		dma_0_control_port_slave_write_n;
	input	[15:0]	dma_0_control_port_slave_writedata;
	input	[7:0]	entrada_nios_ii_0_external_connection_export;
	input	[7:0]	entrada_nios_ii_1_external_connection_export;
	output	[23:0]	hexa7seg_external_connection_export;
	input	[3:0]	lag_0_users_input_us_delay;
	input		lag_0_users_input_go;
	input	[3:0]	lag_1_users_input_us_delay;
	input		lag_1_users_input_go;
	input		reset_reset_n;
	output	[7:0]	saida_nios_ii_0_external_connection_export;
	output	[7:0]	saida_nios_ii_1_external_connection_export;
endmodule
