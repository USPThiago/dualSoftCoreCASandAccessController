

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity multiplexador_demultiplexador_access_controller is
port(
	-- mem slave/master bus 0 							--
	-- access controller master signals 	--
	access_controller_0_master_address 		: out std_logic_vector(9 downto 0);
	access_controller_0_master_clken	  		: out std_logic;
	access_Controller_0_master_chipselect 	: out std_logic;
	access_controller_0_master_wrtite		: out std_logic;
	access_controller_0_master_readdata		: in  std_logic_vector(31 downto 0); 
	access_controller_0_master_writedata	: out std_logic_vector(31 downto 0);
	access_controller_0_master_byteenable	: out std_logic_vector(3  downto 0);
	access_controller_0_master_waitrequest	: in  std_logic;							 
	-- access controller slave signals 		--
	access_controller_0_slave_address 		: in  std_logic_vector(9 downto 0);
	access_controller_0_slave_clken	  		: in  std_logic;
	access_Controller_0_slave_chipselect 	: in  std_logic;
	access_controller_0_slave_wrtite			: in  std_logic;
	access_controller_0_slave_readdata		: out std_logic_vector(31 downto 0); 
	access_controller_0_slave_writedata		: in  std_logic_vector(31 downto 0);
	access_controller_0_slave_byteenable	: in  std_logic_vector(3  downto 0);
	access_controller_0_slave_waitrequest	: out std_logic;							 
	-- Nios II 0 master signals 				-- 
	nios_II_0_slave_address 					: in  std_logic_vector(9 downto 0);
	nios_II_0_slave_clken	  					: in  std_logic;
	nios_II_0_slave_chipselect 				: in  std_logic;
	nios_II_0_slave_wrtite						: in  std_logic;
	nios_II_0_slave_readdata					: out std_logic_vector(31 downto 0);
	nios_II_0_slave_writedata					: in  std_logic_vector(31 downto 0);
	nios_II_0_slave_byteenable					: in  std_logic_vector(3  downto 0);
	nios_II_0_slave_waitrequest				: out std_logic;
	-- selection key mes slave bus 0 		--
	mem_slave_bus_0_sel_key						: in  std_logic;
	-- mem slave/master bus 1 							--
	-- access controller master signals 	--
	access_controller_1_master_address 		: out std_logic_vector(9 downto 0);
	access_controller_1_master_clken	  		: out std_logic;
	access_Controller_1_master_chipselect 	: out std_logic;
	access_controller_1_master_wrtite		: out std_logic;
	access_controller_1_master_readdata		: in  std_logic_vector(31 downto 0); 
	access_controller_1_master_writedata	: out std_logic_vector(31 downto 0);
	access_controller_1_master_byteenable	: out std_logic_vector(3  downto 0);
	access_controller_1_master_waitrequest	: in  std_logic;		
	-- access controller master signals 	--
	access_controller_1_slave_address 		: in  std_logic_vector(9 downto 0);
	access_controller_1_slave_clken	  		: in  std_logic;
	access_Controller_1_slave_chipselect 	: in  std_logic;
	access_controller_1_slave_wrtite			: in  std_logic;
	access_controller_1_slave_readdata		: out std_logic_vector(31 downto 0); 
	access_controller_1_slave_writedata		: in  std_logic_vector(31 downto 0);
	access_controller_1_slave_byteenable	: in  std_logic_vector(3  downto 0);
	access_controller_1_slave_waitrequest	: out std_logic;							 
	-- Nios II 1 master signals 				-- 
	nios_II_1_slave_address 					: in  std_logic_vector(9 downto 0);
	nios_II_1_slave_clken	  					: in  std_logic;
	nios_II_1_slave_chipselect 				: in  std_logic;
	nios_II_1_slave_wrtite						: in  std_logic;
	nios_II_1_slave_readdata					: out std_logic_vector(31 downto 0);
	nios_II_1_slave_writedata					: in  std_logic_vector(31 downto 0);
	nios_II_1_slave_byteenable					: in  std_logic_vector(3  downto 0);
	nios_II_1_slave_waitrequest				: out std_logic;
	-- selection key mes slave bus 1			--
	mem_slave_bus_1_sel_key						: in  std_logic
); 
end entity;


architecture rtl of multiplexador_demultiplexador_access_controller is

begin 
	
	-- multiplexer signals --
	
	access_controller_0_master_address 		<= access_controller_0_slave_address 		when mem_slave_bus_0_sel_key = '1' else nios_II_0_slave_address;
	access_controller_0_master_clken	  		<= access_controller_0_slave_clken			when mem_slave_bus_0_sel_key = '1' else nios_II_0_slave_clken;
	access_Controller_0_master_chipselect	<= access_Controller_0_slave_chipselect	when mem_slave_bus_0_sel_key = '1' else nios_II_0_slave_chipselect;	
	access_controller_0_master_wrtite		<= access_controller_0_slave_wrtite			when mem_slave_bus_0_sel_key = '1' else nios_II_0_slave_wrtite;
	access_controller_0_master_writedata	<= access_controller_0_slave_writedata		when mem_slave_bus_0_sel_key = '1' else nios_II_0_slave_writedata;
	access_controller_0_master_byteenable	<= access_controller_0_slave_byteenable	when mem_slave_bus_0_sel_key = '1' else nios_II_0_slave_byteenable;

	access_controller_1_master_address 		<= access_controller_1_slave_address 		when mem_slave_bus_1_sel_key = '1' else nios_II_1_slave_address;
	access_controller_1_master_clken	  		<= access_controller_1_slave_clken			when mem_slave_bus_1_sel_key = '1' else nios_II_1_slave_clken;
	access_Controller_1_master_chipselect	<= access_Controller_1_slave_chipselect	when mem_slave_bus_1_sel_key = '1' else nios_II_1_slave_chipselect;	
	access_controller_1_master_wrtite		<= access_controller_1_slave_wrtite			when mem_slave_bus_1_sel_key = '1' else nios_II_1_slave_wrtite;
	access_controller_1_master_writedata	<= access_controller_1_slave_writedata		when mem_slave_bus_1_sel_key = '1' else nios_II_1_slave_writedata;
	access_controller_1_master_byteenable	<= access_controller_1_slave_byteenable	when mem_slave_bus_1_sel_key = '1' else nios_II_1_slave_byteenable;

	-- demultiplexer signals --
	access_controller_0_slave_readdata 		<= access_controller_0_master_readdata		when mem_slave_bus_0_sel_key = '1' else (others => '0');
	nios_II_0_slave_readdata					<= access_controller_0_master_readdata 	when mem_slave_bus_0_sel_key = '0' else (others => '0');
	access_controller_0_slave_waitrequest	<= access_controller_0_master_waitrequest when mem_slave_bus_0_sel_key = '1' else '0';
	nios_II_0_slave_waitrequest				<= access_controller_0_master_waitrequest when mem_slave_bus_0_sel_key = '0' else '0';

	access_controller_1_slave_readdata		<= access_controller_1_master_readdata 	when mem_slave_bus_1_sel_key = '1' else (others => '0');
	nios_II_1_slave_readdata					<= access_controller_1_master_readdata 	when mem_slave_bus_1_sel_key = '0' else (others => '0');
	access_controller_1_slave_waitrequest	<= access_controller_1_master_waitrequest when mem_slave_bus_1_sel_key = '1' else '0';
	nios_II_1_slave_waitrequest				<= access_controller_1_master_waitrequest when mem_slave_bus_1_sel_key = '0' else '0';
	
end architecture;
	
	
	
	
