
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity comparador is
port(
	op_a		: in  std_logic_vector(31 downto 0);
	op_b		: in  std_logic_vector(31 downto 0);
	res		: out std_logic := '0'
);
end entity comparador;


architecture behavior of comparador is

	begin 
	
		res <= '1' when op_a = op_b else '0';
		
end architecture behavior;

