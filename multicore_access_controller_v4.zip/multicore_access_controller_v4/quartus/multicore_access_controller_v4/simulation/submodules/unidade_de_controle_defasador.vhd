
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity unidade_de_controle_defasador is 
port(
	clock 		: in  std_logic;
	reset			: in  std_logic;
	
	ci_start		: in  std_logic;
	user_start	: in  std_logic;
	eql			: in  std_logic;
	en_reg_ci	: out std_logic;
	en_reg_dly	: out std_logic;
	en_counter	: out std_logic;
	en_output	: out std_logic;
	clear_data	: out std_logic;
	
	db_state		: out std_logic_vector(1 downto 0)
); 
end entity;


architecture behavior of unidade_de_controle_defasador is

	type state_t is (idle, wait_user, delay, end_process);
	signal state, next_state : state_t;
	
	begin 
	
		process(clock)
		begin 
		
			if clock'event and clock = '1' then
				if reset = '1' then 
					state <= idle;
				else
					state <= next_state;
				end if;
			end if;
		
		end process;
		
		next_state <= idle 			when state = idle 	  and ci_start   = '0' else
						  wait_user		when state = idle 	  and ci_start   = '1' else
						  wait_user 	when state = wait_user and user_start = '0' else
						  delay			when state = wait_user and user_start = '1' else
						  delay 			when state = delay	  and eql		  = '0' else
						  end_process	when state = delay 	  and eql		  = '1' else
						  idle;

		en_reg_ci	<= '1' when state = idle 					 else '0';
		en_reg_dly	<= '1' when state = wait_user				 else '0';
		en_counter	<= '1' when state = delay					 else '0';
		en_output	<= '1' when state = delay and eql = '1' else '0';
		clear_data	<= '1' when state = end_process 			 else '0';
			
		db_state	<= "00" when state = idle 			else
						"01" when state = wait_user 	else
						"10" when state = delay 		else
						"11" when state = end_process else
						"00";
						
		
end architecture;
						  
						  
						  
		
		
		
			
			
			
			
			
			
			
			
			