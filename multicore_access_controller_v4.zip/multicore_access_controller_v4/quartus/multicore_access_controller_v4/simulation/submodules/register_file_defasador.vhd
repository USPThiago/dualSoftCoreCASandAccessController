
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity register_file_defasador is
port(
	
	clock 			: in  std_logic;
	
	reset				: in  std_logic := '0'; 
	enable_ci		: in  std_logic := '0';
	enable_delay	: in  std_logic := '0';
	
	d_delay			: in  std_logic_vector(3  downto 0);
	d_dataa			: in  std_logic_Vector(31 downto 0);
	d_datab			: in  std_logic_vector(31 downto 0);
	d_n				: in  std_logic_vector(4  downto 0);
	d_start			: in  std_logic := '0';
	
	q_delay			: out std_logic_vector(3  downto 0);
	q_dataa			: out std_logic_Vector(31 downto 0);
	q_datab			: out std_logic_vector(31 downto 0);
	q_n				: out std_logic_vector(4  downto 0);
	q_start			: out std_logic := '0'
	
); 
end entity;


architecture behavior of register_file_defasador is

	component register_n_bits is
	generic(
		dataSize	: integer := 31
	);
	port(
		clock		: in  std_logic;
		reset 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic_vector(dataSize downto 0);
		Q 			: out std_logic_Vector(dataSize downto 0)
	);
	end component;
	
	signal internal_delay_in   : std_logic_Vector(3  downto 0);
	signal internal_dataa_in 	: std_logic_vector(31 downto 0);
	signal internal_datab_in 	: std_logic_vector(31 downto 0);
	signal internal_n_in		 	: std_logic_vector(4  downto 0);
	signal internal_start_in 	: std_logic_vector(0  downto 0);
	
	signal internal_delay_out  : std_logic_Vector(3  downto 0);
	signal internal_dataa_out  : std_logic_vector(31 downto 0);
	signal internal_datab_out  : std_logic_vector(31 downto 0);
	signal internal_n_out 		: std_logic_vector(4  downto 0);
	signal internal_start_out  : std_logic_vector(0  downto 0);
	
	begin 
		
		DEVICE_DELAY_REGISTER : register_n_bits 
		generic map(
			dataSize	=> 3
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable_delay,
			D			=> internal_delay_in,
			Q 			=> internal_delay_out
		);
		
		DEVICE_DATAA_REGISTER : register_n_bits 
		generic map(
			dataSize	=> 31
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable_ci,
			D			=> internal_dataa_in,
			Q 			=> internal_dataa_out
		);
		
		DEVICE_DATAB_REGISTER : register_n_bits 
		generic map(
			dataSize	=> 31
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable_ci,
			D			=> internal_datab_in,
			Q 			=> internal_datab_out
		);
		
		DEVICE_N_REGISTER : register_n_bits 
		generic map(
			dataSize	=> 4
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable_ci,
			D			=> internal_n_in,
			Q 			=> internal_n_out
		);

		DEVICE_START_REGISTER : register_n_bits 
		generic map(
			dataSize	=> 0
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable_ci,
			D			=> internal_start_in,
			Q 			=> internal_start_out
		);
	
		internal_delay_in  	<=	d_delay;
		internal_dataa_in  	<= d_dataa;
		internal_datab_in  	<= d_datab;
		internal_n_in  	 	<= d_n    ;
		internal_start_in(0) <= d_start;
	
		q_delay	<= internal_delay_out	;
		q_dataa	<= internal_dataa_out	;
		q_datab	<= internal_datab_out	;
		q_n    	<= internal_n_out    	;
		q_start	<= internal_start_out(0);
		
end architecture;
	
