

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity access_Controller_v3 is
	generic(
		dataSize					: integer := 31;
		AddressSize				: integer := 9
	);
	port(
		clock						: in  std_logic;
		reset						: in  std_logic;
		
		-- uP 0 bus							  --
		-- uP communication signals     --
		avs_address_0   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect_0		: in  std_logic                     := '0';
		avs_read_0     		: in  std_logic                     := '0'; 	
		avs_write_0     		: in  std_logic                     := '0';             
		avs_writedata_0		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_waitrequest_0		: out std_logic							:= '0';
		avs_readdata_0			: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		avs_readdata_valid_0	: out std_logic;
		
		tas_lock_0				: in  std_logic;
		tas_locked_0			: out std_logic;	
		tas_unlock_0			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata_0  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address_0    		: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken_0     		: out std_logic                     := '0';              
		avm_chipselect_0 		: out std_logic                     := '0';              				-- enable componente to work
		avm_read_0				: out std_logic							:= '0';
		avm_write_0      		: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata_0  		: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable_0		: out std_logic_vector(3 downto 0)  := (others => '0'); 		                   
		avm_waitrequest_0	   : in  std_logic      				   := '1'; 									-- waitrequest RAM component. Active in low

		-- db signals 						  --
		db_state_uc_0			: out std_logic_vector(3 downto 0);
		-- uP 1 bus							  --
		-- uP communication signals     --
		avs_address_1   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect_1		: in  std_logic                     := '0';
		avs_read_1     		: in  std_logic                     := '0'; 	
		avs_write_1     		: in  std_logic                     := '0';             
		avs_writedata_1		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_waitrequest_1		: out std_logic							:= '0';
		avs_readdata_1			: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		avs_readdata_valid_1	: out std_logic;
		
		tas_lock_1				: in  std_logic; 
		tas_locked_1			: out std_logic;
		tas_unlock_1			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata_1  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address_1    		: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken_1     		: out std_logic                     := '0';              
		avm_chipselect_1 		: out std_logic                     := '0';              				-- enable componente to work
		avm_read_1				: out std_logic							:= '0';
		avm_write_1      		: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata_1  		: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable_1		: out std_logic_vector(3 downto 0) := (others => '0'); 		                   
		avm_waitrequest_1	   : in  std_logic      				   := '1'; 									-- waitrequest RAM component. Active in low
		
		-- db signals 						  --
		db_state_uc_1			: out std_logic_vector(3 downto 0);
		
		-- Nios II 0 master signals 				-- 
		nios_II_0_slave_address 					: in  std_logic_vector(9 downto 0);
		nios_II_0_slave_clken	  					: in  std_logic;
		nios_II_0_slave_chipselect 				: in  std_logic;
		nios_II_0_slave_wrtite						: in  std_logic;
		nios_II_0_slave_readdata					: out std_logic_vector(31 downto 0);
		nios_II_0_slave_writedata					: in  std_logic_vector(31 downto 0);
		nios_II_0_slave_byteenable					: in  std_logic_vector(3  downto 0);
		nios_II_0_slave_waitrequest				: out std_logic;
		nios_II_0_slave_readdata_valid			: out std_logic;
		-- selection key mes slave bus 0 		--
		mem_slave_bus_0_sel_key						: in  std_logic;
		
		-- Nios II 1 master signals 				-- 
		nios_II_1_slave_address 					: in  std_logic_vector(9 downto 0);
		nios_II_1_slave_clken	  					: in  std_logic;
		nios_II_1_slave_chipselect 				: in  std_logic;
		nios_II_1_slave_wrtite						: in  std_logic;
		nios_II_1_slave_readdata					: out std_logic_vector(31 downto 0);
		nios_II_1_slave_writedata					: in  std_logic_vector(31 downto 0);
		nios_II_1_slave_byteenable					: in  std_logic_vector(3  downto 0);
		nios_II_1_slave_waitrequest				: out std_logic;
		nios_II_1_slave_readdata_valid			: out std_logic;
		-- selection key mes slave bus 1			--
		mem_slave_bus_1_sel_key						: in  std_logic
		
	); 
end entity;


architecture rtl of access_Controller_v3 is

	component top_level_entity is
	generic(
		dataSize					: integer := 31;
		AddressSize				: integer := 9
	);
	port(
		clock						: in  std_logic;
		reset						: in  std_logic;
		
		-- uP 0 bus							  --
		-- uP communication signals     --
		avs_address_0   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect_0		: in  std_logic                     := '0';
		avs_read_0     		: in  std_logic                     := '0'; 	
		avs_write_0     		: in  std_logic                     := '0';             
		avs_writedata_0		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_waitrequest_0		: out std_logic 							:= '0';
		avs_readdata_0			: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		avs_readdata_valid_0	: out std_logic;
		
		tas_lock_0				: in  std_logic;
		tas_locked_0			: out std_logic;	
		tas_unlock_0			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata_0  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address_0    		: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken_0     		: out std_logic                     := '0';              
		avm_chipselect_0 		: out std_logic                     := '0';              				-- enable componente to work
		avm_read_0				: out std_logic							:= '0';
		avm_write_0      		: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata_0  		: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable_0		: out std_logic_vector(3 downto 0)  := (others => '0'); 		                   
		avm_waitrequest_0	   : in  std_logic      				   := '1'; 									-- waitrequest RAM component. Active in low
		
		-- load logic communication signals --
		compare_and_swap_address_0	: out std_logic_vector(9 downto 0);
		compare_and_swap_locked_0	: out std_logic;
		load_address_0					: in  std_logic_vector(9 downto 0);
		load_locked_0					: in  std_logic;
		
		-- db signals 						  --
		db_state_uc_0			: out std_logic_vector(3 downto 0);
		-- uP 1 bus							  --
		-- uP communication signals     --
		avs_address_1   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect_1		: in  std_logic                     := '0';
		avs_read_1     		: in  std_logic                     := '0'; 	
		avs_write_1     		: in  std_logic                     := '0';             
		avs_writedata_1		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_waitrequest_1		: out std_logic							:= '0';
		avs_readdata_1			: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		avs_readdata_valid_1	: out std_logic;
		
		tas_lock_1				: in  std_logic; 
		tas_locked_1			: out std_logic;
		tas_unlock_1			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata_1  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address_1    		: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken_1     		: out std_logic                     := '0';              
		avm_chipselect_1 		: out std_logic                     := '0';              				-- enable componente to work
		avm_read_1				: out std_logic							:= '0';
		avm_write_1      		: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata_1  		: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable_1		: out std_logic_vector(3 downto 0) := (others => '0'); 		                   
		avm_waitrequest_1	   : in  std_logic      				   := '1'; 									-- waitrequest RAM component. Active in low
		
		-- load logic communication signals --
		compare_and_swap_address_1	: out std_logic_vector(9 downto 0);
		compare_and_swap_locked_1	: out std_logic;
		load_address_1					: in  std_logic_vector(9 downto 0);
		load_locked_1					: in  std_logic;
		
		
		-- db signals 						  --
		db_state_uc_1			: out std_logic_vector(3 downto 0)
	); 
	end component;

	component multiplexador_demultiplexador_access_controller is
	port(
		-- mem slave/master bus 0 							--
		-- access controller master signals 	--
		access_controller_0_master_address 		: out std_logic_vector(9 downto 0);
		access_controller_0_master_clken	  		: out std_logic;
		access_Controller_0_master_chipselect 	: out std_logic;
		access_controller_0_master_wrtite		: out std_logic;
		access_controller_0_master_readdata		: in  std_logic_vector(31 downto 0); 
		access_controller_0_master_writedata	: out std_logic_vector(31 downto 0);
		access_controller_0_master_byteenable	: out std_logic_vector(3  downto 0);
		access_controller_0_master_waitrequest	: in  std_logic;							 
		-- access controller slave signals 		--
		access_controller_0_slave_address 		: in  std_logic_vector(9 downto 0);
		access_controller_0_slave_clken	  		: in  std_logic;
		access_Controller_0_slave_chipselect 	: in  std_logic;
		access_controller_0_slave_wrtite			: in  std_logic;
		access_controller_0_slave_readdata		: out std_logic_vector(31 downto 0); 
		access_controller_0_slave_writedata		: in  std_logic_vector(31 downto 0);
		access_controller_0_slave_byteenable	: in  std_logic_vector(3  downto 0);
		access_controller_0_slave_waitrequest	: out std_logic;							 
		-- Nios II 0 master signals 				-- 
		nios_II_0_slave_address 					: in  std_logic_vector(9 downto 0);
		nios_II_0_slave_clken	  					: in  std_logic;
		nios_II_0_slave_chipselect 				: in  std_logic;
		nios_II_0_slave_wrtite						: in  std_logic;
		nios_II_0_slave_readdata					: out std_logic_vector(31 downto 0);
		nios_II_0_slave_writedata					: in  std_logic_vector(31 downto 0);
		nios_II_0_slave_byteenable					: in  std_logic_vector(3  downto 0);
		nios_II_0_slave_waitrequest				: out std_logic;
		-- selection key mes slave bus 0 		--
		mem_slave_bus_0_sel_key						: in  std_logic;
		-- mem slave/master bus 1 							--
		-- access controller master signals 	--
		access_controller_1_master_address 		: out std_logic_vector(9 downto 0);
		access_controller_1_master_clken	  		: out std_logic;
		access_Controller_1_master_chipselect 	: out std_logic;
		access_controller_1_master_wrtite		: out std_logic;
		access_controller_1_master_readdata		: in  std_logic_vector(31 downto 0); 
		access_controller_1_master_writedata	: out std_logic_vector(31 downto 0);
		access_controller_1_master_byteenable	: out std_logic_vector(3  downto 0);
		access_controller_1_master_waitrequest	: in  std_logic;		
		-- access controller master signals 	--
		access_controller_1_slave_address 		: in  std_logic_vector(9 downto 0);
		access_controller_1_slave_clken	  		: in  std_logic;
		access_Controller_1_slave_chipselect 	: in  std_logic;
		access_controller_1_slave_wrtite			: in  std_logic;
		access_controller_1_slave_readdata		: out std_logic_vector(31 downto 0); 
		access_controller_1_slave_writedata		: in  std_logic_vector(31 downto 0);
		access_controller_1_slave_byteenable	: in  std_logic_vector(3  downto 0);
		access_controller_1_slave_waitrequest	: out std_logic;							 
		-- Nios II 1 master signals 				-- 
		nios_II_1_slave_address 					: in  std_logic_vector(9 downto 0);
		nios_II_1_slave_clken	  					: in  std_logic;
		nios_II_1_slave_chipselect 				: in  std_logic;
		nios_II_1_slave_wrtite						: in  std_logic;
		nios_II_1_slave_readdata					: out std_logic_vector(31 downto 0);
		nios_II_1_slave_writedata					: in  std_logic_vector(31 downto 0);
		nios_II_1_slave_byteenable					: in  std_logic_vector(3  downto 0);
		nios_II_1_slave_waitrequest				: out std_logic;
		-- selection key mes slave bus 1			--
		mem_slave_bus_1_sel_key						: in  std_logic
	); 
	end component;
	
	component access_controller_rdwr is
	generic(
		AddressSize 					: integer := 9;
		dataSize							: integer := 31;
		byteenSize						: integer := 3
	);
	port(
		
		clock 							: in  std_logic;
		reset 							: in  std_logic;
		
		-- control unit 		--
		
		compare_and_swap_address_0 : in  std_logic_vector(AddressSize downto 0);
		compare_and_swap_address_1 : in  std_logic_vector(AddressSize downto 0);
		compare_and_swap_locked_0	: in  std_logic;
		compare_and_swap_locked_1	: in  std_logic;
		
		load_locked_0					: out std_logic;												-- Access controller signal: Nios II 0					  --
		load_locked_1					: out std_logic;												-- Access controller signal: Nios II 1					  --
		
		-- Data Path signals --
		
		DAddress_0						: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 0
		Dwrite_0							: in  std_logic := '0';										-- Avalon MM read input 								Nios II 0
		Dchipselect_0					: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 0
		Dreset_n_0						: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 0
		Dclk_en_0						: in  std_logic := '0';										-- Avalon MM clk_en input 								Nios II 0
		Dbyteen_0						: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 0
		
		Dreaddata_0						: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
		
		QAddress_0						: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 0
		Qwrite_0							: out std_logic := '0';										-- Avalon MM read output 								Nios II 0
		Qchipselect_0					: out std_logic := '0';										-- Avalon MM chipselect output 						Nios II 0
		Qreset_n_0						: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 0
		Qclk_en_0						: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 0
		Qbyteen_0						: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output 							Nios II 0
		
		Qreaddata_0						: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 0
		Qreaddata_valid_0				: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 0
		
		addressAquired_0 				: out std_logic_vector(AddressSize downto 0);
		
		DAddress_1						: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 1
		Dwrite_1							: in  std_logic := '0';										-- Avalon MM read input 								Nios II 1 
		Dchipselect_1					: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 1
		Dreset_n_1						: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 1
		Dclk_en_1						: in  std_logic := '0';											-- Avalon MM clk_en input 							Nios II 1
		Dbyteen_1						: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 1
		
		Dreaddata_1						: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
		
		QAddress_1						: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 1
		Qwrite_1							: out std_logic := '0';										-- Avalon MM read output 								Nios II 1
		Qchipselect_1					: out std_logic := '0';										-- Avalon MM chipselect outpuy 						Nios II 1
		Qreset_n_1						: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 1
		Qclk_en_1						: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 1
		Qbyteen_1						: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output 							Nios II 1
		
		Qreaddata_1						: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 1
		Qreaddata_valid_1				: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 1
		
		addressAquired_1 				: out std_logic_vector(AddressSize downto 0)
	);
	end component;
		
	signal internal_avm_address_0						: std_logic_vector(9 downto 0);
	signal internal_avm_clken_0						: std_logic;
	signal internal_avm_chipselect_0					: std_logic;
	signal internal_avm_read_0							: std_logic;
	signal internal_avm_write_0						: std_logic;
	signal internal_avm_readdata_0					: std_logic_Vector(31 downto 0);
	signal internal_avm_writedata_0					: std_logic_Vector(31 downto 0);
	signal internal_avm_byteenable_0					: std_logic_vector(3  downto 0);
	signal internal_avm_waitrequest_0				: std_logic;
	
	signal internal_avm_address_1						: std_logic_vector(9 downto 0);
	signal internal_avm_clken_1						: std_logic;
	signal internal_avm_chipselect_1					: std_logic;
	signal internal_avm_read_1							: std_logic;
	signal internal_avm_write_1						: std_logic;
	signal internal_avm_readdata_1					: std_logic_Vector(31 downto 0);
	signal internal_avm_writedata_1					: std_logic_Vector(31 downto 0);
	signal internal_avm_byteenable_1					: std_logic_vector(3  downto 0);
	signal internal_avm_waitrequest_1				: std_logic;
	
	signal output_avm_write_0							: std_logic := '0';
	signal output_avm_write_1							: std_logic := '0';
	signal output_avm_chipselect_0					: std_logic := '0';
	signal output_avm_chipselect_1					: std_logic := '0';
	
	signal nios_II_0_slave_read						: std_logic := '0';
	signal nios_II_1_slave_read						: std_logic := '0';
	
	signal internal_nios_II_0_slave_address 		: std_logic_vector(9 downto 0);
	signal internal_nios_II_0_slave_read	 		: std_logic;
	signal internal_nios_II_0_slave_chipselect	: std_logic;
	signal internal_nios_II_0_slave_clken			: std_logic;
	signal internal_nios_II_0_slave_byteen			: std_logic_vector(3 downto 0);
	signal internal_nios_II_0_slave_readdata		: std_logic_vector(31 downto 0);
	
	signal internal_nios_II_1_slave_address 		: std_logic_vector(9 downto 0);
	signal internal_nios_II_1_slave_read	 		: std_logic;
	signal internal_nios_II_1_slave_chipselect	: std_logic;
	signal internal_nios_II_1_slave_clken			: std_logic;
	signal internal_nios_II_1_slave_byteen			: std_logic_vector(3 downto 0);
	signal internal_nios_II_1_slave_readdata		: std_logic_vector(31 downto 0);
	
	signal internal_compare_and_swap_address_0	: std_logic_vector(9 downto 0);	
	signal internal_compare_and_swap_locked_0		: std_logic;
	signal internal_load_address_0					: std_logic_vector(9 downto 0);
	signal internal_load_locked_0						: std_logic;
	
	signal internal_compare_and_swap_address_1	: std_logic_vector(9 downto 0);	
	signal internal_compare_and_swap_locked_1		: std_logic;
	signal internal_load_address_1					: std_logic_vector(9 downto 0);
	signal internal_load_locked_1						: std_logic;
	
	begin 
	
		DEVICE_ACCESS_CONTROLLER_V2 : top_level_entity
		generic map(
			dataSize					=> 31,
			AddressSize				=> 9
		)
		port map(
			clock						=> clock,
			reset						=> reset,
			
			-- uP 0 bus							  --
			-- uP communication signals     --
			avs_address_0   		=> avs_address_0,           
			avs_chipselect_0		=> avs_chipselect_0,
			avs_read_0     		=> avs_read_0, 	
			avs_write_0     		=> avs_write_0,             
			avs_writedata_0		=> avs_writedata_0,
			
			avs_waitrequest_0		=> avs_waitrequest_0,
			avs_readdata_0			=> avs_readdata_0,
			avs_readdata_valid_0	=> avs_readdata_valid_0,
			
			tas_lock_0				=> tas_lock_0,
			tas_locked_0			=> tas_locked_0,	
			tas_unlock_0			=> tas_unlock_0,
			
			-- Memory communication signals --
			avm_readdata_0  		=> internal_avm_readdata_0,			-- data received from memory
				
			avm_address_0    		=> internal_avm_address_0,  			-- especify one position of memory
			avm_clken_0     		=> internal_avm_clken_0,          
			avm_chipselect_0 		=> internal_avm_chipselect_0,    	-- enable componente to work
			avm_read_0				=> internal_avm_read_0,
			avm_write_0      		=> internal_avm_write_0,         	-- enable a write operation
			avm_writedata_0  		=> internal_avm_writedata_0,  		-- data to be store in memory 
			avm_byteenable_0		=> internal_avm_byteenable_0,              
			avm_waitrequest_0	   => internal_avm_waitrequest_0,		-- waitrequest RAM component. Active in low
			
			-- load logic communication signals --
			compare_and_swap_address_0	=> internal_compare_and_swap_address_0,
			compare_and_swap_locked_0	=> internal_compare_and_swap_locked_0,
			load_address_0					=> internal_load_address_0,
			load_locked_0					=> internal_load_locked_0,
			
			-- db signals 						  --
			db_state_uc_0			=> db_state_uc_0,
			-- uP 1 bus							  --
			-- uP communication signals     --
			avs_address_1   		=> avs_address_1,          
			avs_chipselect_1		=> avs_chipselect_1,
			avs_read_1     		=> avs_read_1, 	
			avs_write_1     		=> avs_write_1,            
			avs_writedata_1		=> avs_writedata_1,
			
			avs_waitrequest_1		=> avs_waitrequest_1,
			avs_readdata_1			=> avs_readdata_1,
			avs_readdata_valid_1	=> avs_readdata_valid_1,
			
			tas_lock_1				=> tas_lock_1,
			tas_locked_1			=> tas_locked_1,
			tas_unlock_1			=> tas_unlock_1,
			
			-- Memory communication signals --
			avm_readdata_1  		=> internal_avm_readdata_1,			-- data received from memory
				
			avm_address_1    		=> internal_avm_address_1,  			-- especify one position of memory
			avm_clken_1     		=> internal_avm_clken_1,          
			avm_chipselect_1 		=> internal_avm_chipselect_1,    	-- enable componente to work
			avm_read_1				=> internal_avm_read_1,
			avm_write_1      		=> internal_avm_write_1,         	-- enable a write operation
			avm_writedata_1  		=> internal_avm_writedata_1, 			-- data to be store in memory 
			avm_byteenable_1		=> internal_avm_byteenable_1,              
			avm_waitrequest_1	   => internal_avm_waitrequest_1,		-- waitrequest RAM component. Active in low
			
			-- load logic communication signals --
			compare_and_swap_address_1	=> internal_compare_and_swap_address_1,
			compare_and_swap_locked_1	=> internal_compare_and_swap_locked_1,
			load_address_1					=> internal_load_address_1,
			load_locked_1					=> internal_load_locked_1,
			
			-- db signals 						  --
			db_state_uc_1			=> db_state_uc_1
		); 
	
		DEVICE_MULTIPLEXER_DEMULTIPLEXER : multiplexador_demultiplexador_access_controller port map(
			-- mem slave/master bus 0 							--
			-- access controller master signals 	--
			access_controller_0_master_address 		=> avm_address_0,
			access_controller_0_master_clken	  		=> avm_clken_0,
			access_Controller_0_master_chipselect 	=> output_avm_chipselect_0,
			access_controller_0_master_wrtite		=> output_avm_write_0,
			access_controller_0_master_readdata		=> avm_readdata_0, 
			access_controller_0_master_writedata	=> avm_writedata_0,
			access_controller_0_master_byteenable	=> avm_byteenable_0,
			access_controller_0_master_waitrequest	=> avm_waitrequest_0,							 
			-- access controller slave signals 		--
			access_controller_0_slave_address 		=> internal_avm_address_0,
			access_controller_0_slave_clken	  		=> internal_avm_clken_0,
			access_Controller_0_slave_chipselect 	=> internal_avm_chipselect_0,
			access_controller_0_slave_wrtite			=> internal_avm_write_0,
			access_controller_0_slave_readdata		=> internal_avm_readdata_0,
			access_controller_0_slave_writedata		=> internal_avm_writedata_0,
			access_controller_0_slave_byteenable	=> internal_avm_byteenable_0,
			access_controller_0_slave_waitrequest	=> internal_avm_waitrequest_0,						 
			-- Nios II 0 master signals 				-- 
			nios_II_0_slave_address 					=> internal_nios_II_0_slave_address,
			nios_II_0_slave_clken	  					=> internal_nios_II_0_slave_clken,
			nios_II_0_slave_chipselect 				=> internal_nios_II_0_slave_chipselect,
			nios_II_0_slave_wrtite						=> internal_nios_II_0_slave_read,
			nios_II_0_slave_readdata					=> internal_nios_II_0_slave_readdata,				-- ***
			nios_II_0_slave_writedata					=> nios_II_0_slave_writedata,				-- ***
			nios_II_0_slave_byteenable					=> internal_nios_II_0_slave_byteen,
			nios_II_0_slave_waitrequest				=> nios_II_0_slave_waitrequest,			-- ***
			-- selection key mes slave bus 0 		--	
			mem_slave_bus_0_sel_key						=> mem_slave_bus_0_sel_key,
			-- mem slave/master bus 1 							--
			-- access controller master signals 	--
			access_controller_1_master_address 		=> avm_address_1,
			access_controller_1_master_clken	  		=> avm_clken_1,
			access_Controller_1_master_chipselect 	=> output_avm_chipselect_1,
			access_controller_1_master_wrtite		=> output_avm_write_1,
			access_controller_1_master_readdata		=> avm_readdata_1,
			access_controller_1_master_writedata	=> avm_writedata_1,
			access_controller_1_master_byteenable	=> avm_byteenable_1,
			access_controller_1_master_waitrequest => avm_waitrequest_1,	
			-- access controller master signals 	--
			access_controller_1_slave_address 		=> internal_avm_address_1,
			access_controller_1_slave_clken	  		=> internal_avm_clken_1,
			access_Controller_1_slave_chipselect 	=> internal_avm_chipselect_1,
			access_controller_1_slave_wrtite			=> internal_avm_write_1,
			access_controller_1_slave_readdata		=> internal_avm_readdata_1,
			access_controller_1_slave_writedata		=> internal_avm_writedata_1,
			access_controller_1_slave_byteenable	=> internal_avm_byteenable_1,
			access_controller_1_slave_waitrequest	=> internal_avm_waitrequest_1,							 
			-- Nios II 1 master signals 				-- 
			nios_II_1_slave_address 					=> internal_nios_II_1_slave_address,	
			nios_II_1_slave_clken	  					=> internal_nios_II_1_slave_clken,
			nios_II_1_slave_chipselect 				=> internal_nios_II_1_slave_chipselect,
			nios_II_1_slave_wrtite						=> internal_nios_II_1_slave_read,
			nios_II_1_slave_readdata					=> internal_nios_II_1_slave_readdata,				-- ***
			nios_II_1_slave_writedata					=> nios_II_1_slave_writedata,				-- ***
			nios_II_1_slave_byteenable					=> internal_nios_II_1_slave_byteen,
			nios_II_1_slave_waitrequest				=> nios_II_1_slave_waitrequest,			-- ***
			-- selection key mes slave bus 1			--
			mem_slave_bus_1_sel_key						=> mem_slave_bus_1_sel_key
		); 
		
		DEVICE_ACCESS_CONTROLLER_RDWR : access_controller_rdwr
		generic map(
			AddressSize 					=> 9,
			dataSize							=> 31,
			byteenSize						=> 3
		)
		port map(
			
			clock 							=> clock,
			reset 							=> reset,
			
			-- control unit 		--
			
			compare_and_swap_address_0 => internal_compare_and_swap_address_0,
			compare_and_swap_address_1 => internal_compare_and_swap_address_1,
			compare_and_swap_locked_0	=> internal_compare_and_swap_locked_0,
			compare_and_swap_locked_1	=> internal_compare_and_swap_locked_1,
			
			load_locked_0					=> internal_load_locked_0,
			load_locked_1					=> internal_load_locked_1,
			
			-- Data Path signals --
			
			DAddress_0						=> nios_II_0_slave_address,
			Dwrite_0							=> nios_II_0_slave_read,
			Dchipselect_0					=> nios_II_0_slave_chipselect,
			Dreset_n_0						=> open,
			Dclk_en_0						=> nios_II_0_slave_clken,
			Dbyteen_0						=> nios_II_0_slave_byteenable,
			
			Dreaddata_0						=> internal_nios_II_0_slave_readdata,
			
			QAddress_0						=> internal_nios_II_0_slave_address,
			Qwrite_0							=> internal_nios_II_0_slave_read,
			Qchipselect_0					=> internal_nios_II_0_slave_chipselect,
			Qreset_n_0						=> open,
			Qclk_en_0						=> internal_nios_II_0_slave_clken,
			Qbyteen_0						=> internal_nios_II_0_slave_byteen,
			
			Qreaddata_0						=> nios_II_0_slave_readdata,
			Qreaddata_valid_0				=> nios_II_0_slave_readdata_valid,
			
			addressAquired_0 				=> internal_load_address_0,
			
			DAddress_1						=> nios_II_1_slave_address,
			Dwrite_1							=> nios_II_1_slave_read,
			Dchipselect_1					=> nios_II_1_slave_chipselect,
			Dreset_n_1						=> open,
			Dclk_en_1						=> nios_II_1_slave_clken,
			Dbyteen_1						=> nios_II_1_slave_byteenable,
			
			Dreaddata_1						=> internal_nios_II_1_slave_readdata,
			
			QAddress_1						=> internal_nios_II_1_slave_address,
			Qwrite_1							=> internal_nios_II_1_slave_read,
			Qchipselect_1					=> internal_nios_II_1_slave_chipselect,
			Qreset_n_1						=> open,
			Qclk_en_1						=> internal_nios_II_1_slave_clken,
			Qbyteen_1						=> internal_nios_II_1_slave_byteen,
			
			Qreaddata_1						=> nios_II_1_slave_readdata,
			Qreaddata_valid_1				=> nios_II_1_slave_readdata_valid,
			
			addressAquired_1 				=> internal_load_address_1
			
		); 
		
		nios_II_0_slave_read <= (not nios_II_0_slave_wrtite) and nios_II_0_slave_chipselect;
		nios_II_1_slave_read <= (not nios_II_1_slave_wrtite) and nios_II_1_slave_chipselect;
		
		avm_read_0 	<= (not output_avm_write_0) and output_avm_chipselect_0;
		avm_read_1 	<= (not output_avm_write_1) and output_avm_chipselect_1;
		
		avm_write_0 <= output_avm_write_0;
		avm_write_1 <= output_avm_write_1;
		
		avm_chipselect_0 <= output_avm_chipselect_0;
		avm_chipselect_1 <= output_avm_chipselect_1;
		
end architecture;








