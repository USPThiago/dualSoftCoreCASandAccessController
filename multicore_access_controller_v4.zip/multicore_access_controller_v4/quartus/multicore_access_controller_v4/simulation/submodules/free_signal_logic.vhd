
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;



entity free_signal_logic_generator is
port(
	------------------------------------------
	-- uc 0 signals								 --
	------------------------------------------
	cas_address_0				 : in  std_logic_vector(9  downto 0); 
	new_address_0 				 : in  std_logic_vector(9  downto 0);
	load_locked_1				 : in  std_logic;
	load_acquired_address_1	 : in  std_logic_vector(9  downto 0);
	mutex_acquired_address_1 : in  std_logic_vector(9  downto 0);
	mutex_locked_1	 			 : in  std_logic;
	free_0	 					 : out std_logic;
	------------------------------------------
	-- uc 1 signals								 --
	------------------------------------------
	cas_address_1				 : in  std_logic_vector(9  downto 0); 
	new_address_1 				 : in  std_logic_vector(9  downto 0);
	load_locked_0				 : in  std_logic;
	load_acquired_address_0	 : in  std_logic_vector(9  downto 0);
	mutex_acquired_address_0 : in  std_logic_vector(9  downto 0);
	mutex_locked_0	 			 : in  std_logic;
	free_1	 					 : out std_logic
);
end entity;


architecture behavior of free_signal_logic_generator is

	begin
	
		free_0 <= 	'0' when mutex_locked_1 = '1'	and new_address_0 = mutex_acquired_address_1 else
						'0' when mutex_locked_1 = '1'	and cas_address_0 = mutex_acquired_address_1 else
						'0' when load_locked_1  = '1'	and new_address_0 = load_acquired_address_1  else
--						'0' when new_address_0 = mutex_acquired_address_1 									else
						'1';
		free_1 <= 	'0' when mutex_locked_0 = '1'	and new_address_1 = mutex_acquired_address_0 else
						'0' when mutex_locked_0 = '1'	and cas_address_1 = mutex_acquired_address_0 else
						'0' when load_locked_0  = '1'	and new_address_1 = load_acquired_address_0  else
--						'0' when new_address_1 = mutex_acquired_address_0 else
						'1';
				  
end architecture;