
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity Fluxo_de_Dados_CAS is
port(
	-- System inputs			  				  -- 
	clock 						: in  std_logic;
	start							: in  std_logic;
	reset							: in  std_logic;
	enable_registers			: in  std_logic;
	enable_load_data			: in  std_logic;
	set_result					: in 	std_logic;
	----------------------------------------
	-- Custom intruction slave 							 			 --
	address						: in  std_logic_vector(31 downto 0);
	expecteddata				: in  std_logic_vector(31 downto 0);
	newdata_index				: in  std_logic_vector(7  downto 0);
	result						: out std_logic_vector(31 downto 0);
	------------------------------------------------------------
	-- Internal Timer signals 	  	  		  --
	timer_done					: out std_logic;
	timer_reset					: in  std_logic;
	timer_enable				: in  std_logic;
	----------------------------------------
	-- Compare Signal				    		  -- 
	equal							: out std_logic;
	----------------------------------------
	-- Test-and-Set signals 	  	  		  --
	tas_locked					: in  std_logic;
	tas_unlock_IDLE			: out std_logic; 
	----------------------------------------
	-- Avalon MM master bus 									 		 --
	avm_master_address		: out std_logic_vector(31 downto 0);
	avm_master_readdata		: in  std_logic_vector(31 downto 0);
	avm_master_writedata		: out std_logic_vector(31 downto 0);
	------------------------------------------------------------
	-- Register File bus													 -- 
	avs_slave_address			: in  std_logic_vector(31 downto 0);
	avs_slave_chipselect		: in 	std_logic;
	avs_slave_write			: in  std_logic;
	avs_slave_writedata		: in  std_logic_vector(31 downto 0);
	------------------------------------------------------------
	-- Debug signals 					  				 		  			 -- 
	deb_expecteddata		   : out std_logic_vector(31 downto 0);
	deb_avm_master_readdata : out std_logic_vector(31 downto 0)
	------------------------------------------------------------
); 
end entity Fluxo_de_dados_CAS;



architecture behavior of Fluxo_de_Dados_CAS is
	
	component registrador is
	port(
		clock 	: in  std_logic;
		clear 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic_vector(31 downto 0);
		Q 			: out std_logic_vector(31 downto 0)
	); 
	end component registrador;
	
	component timer is
	generic(
		COUNTING_LIMIT : integer := 8
	);
	port(
		clock 	: in  std_logic;
		clear 	: in  std_logic;
		enable	: in  std_logic;
		Q 			: out std_logic
	); 
	end component timer;
	
	component flipflop is
	port(
		clock 	: in  std_logic;
		clear 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic;
		Q 			: out std_logic;
		Q_n		: out std_logic
	); 
	end component flipflop;
	
	component Register_File is
	port(
		-- System inputs		  --
		clock 	: in  std_logic;
		reset 	: in  std_logic;
		-------------------------
		-- Data Out 			  							    --
		reg_index	: in  std_logic_vector(7  downto 0);
		Q				: out std_logic_vector(31 downto 0);
		------------------------------------------------
		-- Avalon MM slave bus 													 --
		avs_slave_address			   : in  std_logic_vector(31 downto 0);
		avs_slave_chipselect			: in 	std_logic;
		avs_slave_write				: in  std_logic;
		avs_slave_writedata			: in  std_logic_vector(31 downto 0)
		---------------------------------------------------------------
	); 
	end component Register_File;
	
	component comparador is
	port(
		op_a		: in  std_logic_vector(31 downto 0);
		op_b		: in  std_logic_vector(31 downto 0);
		res		: out std_logic := '0'
	);
	end component comparador;	
	
	signal reg_index_32bits 				: std_logic_vector(31 downto 0);
	signal internal_address 				: std_logic_vector(31 downto 0);
	signal internal_expecteddata 			: std_logic_vector(31 downto 0);
	signal internal_newdata_index			: std_logic_vector(31 downto 0);
	signal internal_avm_master_readdata : std_logic_vector(31 downto 0);
	signal internal_newdata					: std_logic_vector(31 downto 0);
	
	signal internal_FLAG_Q_n				: std_logic;
	signal newdata_index_32bits			: std_logic_vector(31 downto 0);
	
	signal internal_result					: std_logic := '0';
	signal internal_result_n				: std_logic := '1';
	
	begin 
	
		REG_1 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable_registers,
			D			=> address,
			Q 			=> internal_address
		); 
		
		REG_2 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable_registers,
			D			=> expecteddata,
			Q 			=> internal_expecteddata
		); 
		
		REG_3 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable_registers,
			D			=> newdata_index_32bits,
			Q 			=> internal_newdata_index
		); 
		
		REG_4	: registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable_load_data,
			D			=> avm_master_readdata,
			Q 			=> internal_avm_master_readdata
		); 
	
		REG_FILE : Register_File port map (
		-- System inputs		  									--
		clock 						=> clock,
		reset 						=> reset,
		--------------------------------------------------
		-- Data Out 			  							    	--
		reg_index					=> internal_newdata_index(7 downto 0),
		Q								=> internal_newdata,
		--------------------------------------------------
		-- Avalon MM slave bus 								 	--
		avs_slave_address			=> avs_slave_address,  
		avs_slave_chipselect		=> avs_slave_chipselect,	
		avs_slave_write			=> avs_slave_write,	
		avs_slave_writedata		=> avs_slave_writedata	
		--------------------------------------------------
		); 
		
		COMP : comparador port map (
			op_a	=> internal_expecteddata,		
			op_b	=> internal_avm_master_readdata,
			res	=> equal	
		);
		
		FD_TIMER : timer 
		generic map (
			COUNTING_LIMIT => 8
		)
		port map (
			clock 			=> clock,
			clear 			=> timer_reset, 	
			enable			=> timer_enable,
			Q 					=> timer_done
		); 
		
		FLAG_UNLOCK : flipflop port map (
			clock 	=> clock,
			clear 	=> start,
			enable	=> internal_FLAG_Q_n,
			D			=> tas_locked,
			Q			=> tas_unlock_IDLE,
			Q_n 		=> internal_FLAG_Q_n	
		); 
		
		FLAG_ReSULT : flipflop port map (
			clock 	=> clock,
			clear 	=> start,
			enable	=> internal_result_n,
			D			=> set_result,
			Q			=> internal_result,
			Q_n 		=> internal_result_n	
		);
		
		avm_master_address	<= internal_address;
		avm_master_writedata <= internal_newdata;
		newdata_index_32bits <= x"000000" & newdata_index;
		result					<= (others => '1') when internal_result = '1' else (others => '0');
		
		-- DEBUG CONECTOINS --
		deb_expecteddata 			<= internal_expecteddata;
		deb_avm_master_readdata	<= internal_avm_master_readdata;
		
end architecture behavior;







