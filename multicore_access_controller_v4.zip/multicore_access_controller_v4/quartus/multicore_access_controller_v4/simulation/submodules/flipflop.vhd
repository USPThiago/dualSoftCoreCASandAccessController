
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity flipflop is
port(
	clock 	: in  std_logic;
	clear 	: in  std_logic;
	enable	: in  std_logic;
	D			: in  std_logic;
	Q 			: out std_logic;
	Q_n		: out std_logic
); 
end entity flipflop;


architecture behavior of flipflop is

	signal internal : std_logic := '0';
	
	begin 
	
		process(clock)
		begin 
			
			if clock'event and clock = '1' then
				if clear = '1' then
					internal <= '0';
				elsif enable = '1' then
					internal <= D ;
				end if;
			end if;
		end process;	
			
		Q 		<= internal;
		Q_n 	<= not internal; 
			
end architecture behavior;