
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity registrador is
port(
	clock 	: in  std_logic;
	clear 	: in  std_logic;
	enable	: in  std_logic;
	D			: in  std_logic_vector(31 downto 0);
	Q 			: out std_logic_vector(31 downto 0)
); 
end entity registrador;


architecture behavior of registrador is

	signal internal : std_logic_vector(31 downto 0) := (others => '0');
	
	begin 
	
		process(clock)
		begin 
			
			if clock'event and clock = '1' then
				if clear = '1' then
					internal <= (others => '0');
				elsif enable = '1' then
					internal <= D ;
				end if;
			end if;
		end process;
			
			Q <= internal;
			
end architecture behavior;