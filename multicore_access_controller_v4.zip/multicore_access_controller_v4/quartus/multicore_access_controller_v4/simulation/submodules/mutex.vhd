
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity mutex is 
generic(
	dataSize		  : integer := 9
);
port(
	--------------------------------------------------------------
	-- SYSTEM SIGNALS														   --
	--------------------------------------------------------------
	clock   		  : in  std_logic;
	reset	  		  : in  std_logic;
	enable  		  : in  std_logic;
	--------------------------------------------------------------
	--------------------------------------------------------------
	-- DATA SIGNALS															--
	--------------------------------------------------------------
	address 		  : in  std_logic_vector(dataSize  downto 0);
	tas_lock		  : in  std_logic := '0';
	tas_unlock    : in  std_logic := '0';
	uc_lock		  : in  std_logic := '0';	
	--------------------------------------------------------------
	mutex_address : out std_logic_vector(dataSize  downto 0);
	mutex_locked  : out std_logic
	--------------------------------------------------------------
);
end entity;



architecture behavior of mutex is

	component registrador_access_controller is
		generic(
			dataSize : natural := 31
		);
		port(
			clock 	: in  std_logic;
			clear 	: in  std_logic;
			enable	: in  std_logic;
			D			: in  std_logic_vector(dataSize downto 0);
			Q 			: out std_logic_vector(dataSize downto 0)
		); 
	end component registrador_access_controller;

	signal internal_lock 				: std_logic_vector(0 downto 0);
	signal internal_mutex_unlock 		: std_logic_vector(0 downto 0);
	signal internal_mutex_unlock_n	: std_logic_vector(0 downto 0);
	signal internal_clear				: std_logic := '0';
	
	begin 
	
		DEVICE_MUTEX_ADDRESS : registrador_access_controller 
		generic map(
			dataSize => dataSize
		)
		port map(
			clock 	=> clock,
			clear 	=> internal_clear,
			enable	=> enable,
			D			=> address,
			Q 			=> mutex_address
		); 
		
		DEVICE_MUTEX_LOCKED : registrador_access_controller 
		generic map(
			dataSize => 0
		)
		port map(
			clock 	=> clock,
			clear 	=> internal_clear,
			enable	=> internal_mutex_unlock_n(0),
			D			=> internal_lock,
			Q 			=> internal_mutex_unlock
		); 
		
		internal_mutex_unlock_n(0)	<= not internal_mutex_unlock(0);
		internal_lock(0)   			<= tas_lock   and uc_lock;
		mutex_locked	 	 			<= internal_mutex_unlock(0);
		
		internal_clear		 			<= tas_unlock or reset;		
		
end architecture; 
	
	
	