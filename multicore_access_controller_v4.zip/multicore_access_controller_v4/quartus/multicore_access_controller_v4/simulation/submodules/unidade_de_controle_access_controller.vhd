
library ieee;
use	  ieee.std_logic_1164.all;
use	  ieee.numeric_std.all;


entity unidade_de_controle_access_controller is
port(
	----------------------------
	-- system inputs			  --
	----------------------------
	clock 					: in  std_logic;
	reset						: in  std_logic;
	done						: out std_logic;		-- indicates to uP that operation ended
	----------------------------
	-- control signals inputs --
	----------------------------
	start_i					: in  std_logic;		-- shoud be connect to Avalon MM chipselect signal referent to current uP 
	start_j					: in  std_logic;		-- shoud be connect to Avalon MM chipselect signal referent the other uP
	read						: in  std_logic;
	free						: in  std_logic;		-- indicates that mutex is free to be locked and operation should be accepted
	----------------------------
	-- output signals 		  --
	----------------------------
	en_custom_regfile 	: out std_logic;		-- enable communication with uP 
	en_avm_regfile			: out std_logic;		-- enable communication with shared resource
	en_mutex					: out std_logic;		-- enable mutex acquire a resource
	reset_custom_regfile : out std_logic;		-- clear last transation 
	reset_avm_regfile		: out std_logic;		-- clear last transation 
	lock						: out std_logic;		-- acquire mutex
	locked					: out std_logic;		-- indicates to uP that mutex has been locked
	----------------------------
	-- db signals				  --
	----------------------------
	db_state 				: out std_logic_vector(3 downto 0)
); 
end entity;


architecture behavior of unidade_de_controle_access_controller is

	type state_type is (init, init_read, read_mem, acquire_mutex, write_mem, locked_state, return_successeful_read,
								return_failed_read, return_successeful_write, return_failed_write);
	signal state, next_state : state_type;
	
	begin
		
		process(clock)
		begin 
		
			if clock'event and clock = '1' then
				if reset = '1' then
					state <= init;
				else
					state <= next_state;
				end if;
			end if;
		end process;
		
		-- state transitions description 	--
		next_state <= 	init 								when state = init	 and start_i = '0'				 							else
							init 								when state = return_successeful_read										 	else
							init 								when state = return_successeful_write										 	else
							init								when state = return_failed_write												 	else
							init_read						when state = init	 and start_i = '1' and read = '1' and free = '1'	else -- MODIFIED ( and free = '1')
							acquire_mutex					when state = init  and start_i = '1' and read = '0' and free = '1'	else 
							locked_state					when state = init  and start_i = '1' and read = '0' and free = '0' 	else
							read_mem							when state = init_read 															 	else
							write_mem						when state = acquire_mutex														 	else
							return_successeful_read 	when state = read_mem and free = '1'										 	else 
							return_failed_read			when state = read_mem and free = '0'										 	else 
							return_successeful_write 	when state = write_mem															 	else
							return_failed_write		 	when state = locked_state														 	else
							init;
					
		-- output signals logic description --
		
		en_custom_regfile			<= '1' 		when state = init 										else '0';
		en_avm_regfile				<= '1' 		when state = init_read or state = acquire_mutex	else '0'; 
		en_mutex						<= '1' 		when state = init_read									else '0';
		reset_custom_regfile		<= '1' 		when state = return_successeful_read				else
											'1'		when state = return_successeful_write				else
											'1'		when state = return_failed_write						else
											'1'		when reset = '1'											else
											'0';
		reset_avm_regfile			<= '1' 		when state = return_successeful_read				else
											'1'		when state = return_successeful_write				else
											'1'		when state = return_failed_write						else
											'1'		when state = write_mem									else
											'1'		when reset = '1' 											else
											'0';
		lock							<= '1' 		when state = init_read and free = '1'				else '0'; -- MODIFIED
		locked						<= '1' 		when state = return_successeful_read				else '0'; -- MODIFIED
		
		done							<= '1'		when state = return_successeful_write				else 
											'1'		when state = return_successeful_read			 	else
											'1' 		when state = return_failed_read						else
											'0';
											
		-- depuration signals 					--
		
		db_state <= "0000" when state = init							else
						"0001" when state = init_read						else
						"0010" when state = read_mem						else
						"0011" when state = return_successeful_read 	else
						"0100" when state = acquire_mutex				else
						"0101" when state = write_mem						else
						"0110" when state = return_successeful_write	else
						"0111" when state = locked_state					else
						"1000" when state = return_failed_write		else
						"1001" when state = return_failed_read			else
						"1111";
		
end architecture;
						
		
		
		
		
		
		
		
		