
library ieee;
use 	  ieee.std_logic_1164.all;
use 	  ieee.numeric_std.all;


entity fluxo_de_dados_access_controller_rdwr is
generic(
	AddressSize : integer := 9;
	dataSize		: integer := 31;
	byteenSize	: integer := 3
);
port(
	
	clock					: in  std_logic;
	
	reset 				: in  std_logic;
	
	clear_0				: in  std_logic;												-- control inputs 										Nios II 0
	enable_0				: in  std_logic;												-- control inputs 										Nios II 0
	select_0				: in  std_logic;												-- control inputs 										Nios II 0

	DAddress_0			: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 0
	Dread_0				: in  std_logic := '0';										-- Avalon MM read input 								Nios II 0
	Dchipselect_0		: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 0
	Dreset_n_0			: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 0
	Dclk_en_0			: in  std_logic := '0';										-- Avalon MM clk_en input 								Nios II 0
	Dbyteen_0			: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 0
	
	Dreaddata_0			: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
	Dreaddata_valid_0	: in  std_logic;												-- Avalon MM readdata_valid (from memory)input
	
	QAddress_0			: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 0
	Qread_0				: out std_logic := '0';										-- Avalon MM read output 								Nios II 0
	Qchipselect_0		: out std_logic := '0';										-- Avalon MM chipselect output 						Nios II 0
	Qreset_n_0			: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 0
	Qclk_en_0			: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 0
	Qbyteen_0			: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output 							Nios II 0
	
	Qreaddata_0			: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 0
	Qreaddata_valid_0	: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 0
	
	addressAquired_0 	: out std_logic_vector(AddressSize downto 0);
	
	clear_1				: in  std_logic;												-- control inputs 										Nios II 1
	enable_1				: in  std_logic;												-- control inputs 										Nios II 1
	select_1				: in  std_logic;												-- control inputs 										Nios II 1
	
	DAddress_1			: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 1
	Dread_1				: in  std_logic := '0';										-- Avalon MM read input 								Nios II 1 
	Dchipselect_1		: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 1
	Dreset_n_1			: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 1
	Dclk_en_1			: in  std_logic := '0';											-- Avalon MM clk_en input 							Nios II 1
	Dbyteen_1			: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 1
	
	Dreaddata_1			: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
	Dreaddata_valid_1	: in  std_logic;												-- Avalon MM readdata_valid (from memory)input
	
	QAddress_1			: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 1
	Qread_1				: out std_logic := '0';										-- Avalon MM read output 								Nios II 1
	Qchipselect_1		: out std_logic := '0';										-- Avalon MM chipselect outpuy 						Nios II 1
	Qreset_n_1			: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 1
	Qclk_en_1			: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 1
	Qbyteen_1			: out std_logic_vector(byteenSize downto 0);		-- Avalon MM byteen output 							Nios II 1
	
	Qreaddata_1			: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 1
	Qreaddata_valid_1	: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 1
	
	addressAquired_1 	: out std_logic_vector(AddressSize downto 0)
	
); 
end entity;


architecture behavior of fluxo_de_dados_access_controller_rdwr is

	component register_file_access_controller_rdwr is
	generic(
		AddressSize : integer := 9;
		dataSize		: integer := 31;
		byteenSize	: integer := 3
	);
	port(
		
		clock 		: in  std_logic;
		 
		reset			: in  std_logic := '0'; 									-- force all registers states to zero 
		enable		: in  std_logic := '0';										-- enable register to write the inputs 
				
		DAddress		: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input
		Dread			: in  std_logic := '0';										-- Avalon MM read input
		Dchipselect	: in  std_logic := '0';										-- Avalon MM chipselect input
		Dreset_n		: in  std_logic := '1';										-- Avalon MM reset_n input
		Dclk_en		: in  std_logic := '0';										-- Avalon MM clk_en input
		Dbyteen		: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input
		
		QAddress		: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output
		Qread			: out std_logic := '0';										-- Avalon MM read output
		Qchipselect	: out std_logic := '0';										-- Avalon MM chipselect outpuy
		Qreset_n		: out std_logic := '1';										-- Avalon MM reset_n output
		Qclk_en		: out std_logic := '0';										-- Avalon MM clk_en output
		Qbyteen		: out std_logic_vector(byteenSize downto 0)			-- Avalon MM byteen output
		
	);
	end component;

	
	component instruction_selector is
	generic(
		AddressSize : integer := 9;
		dataSize		: integer := 31;
		byteenSize	: integer := 3
	);
	port(
		
		clock 			: in  std_logic;
		 
		reset				: in  std_logic := '0'; 									-- force all registers states to zero 
		sel				: in  std_logic := '0';										-- enable register to write the inputs 
				
		DAddress			: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input
		Dread				: in  std_logic := '0';										-- Avalon MM read input
		Dchipselect		: in  std_logic := '0';										-- Avalon MM chipselect input
		Dreset_n			: in  std_logic := '1';										-- Avalon MM reset_n input
		Dclk_en			: in  std_logic := '0';										-- Avalon MM clk_en input
		Dbyteen			: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input
		
		Dreaddata		: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
		Dreaddata_valid: in  std_logic;												-- Avalon MM readdata_valid (from memory)input
		
		QAddress			: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output
		Qread				: out std_logic := '0';										-- Avalon MM read output
		Qchipselect		: out std_logic := '0';										-- Avalon MM chipselect output
		Qreset_n			: out std_logic := '1';										-- Avalon MM reset_n output
		Qclk_en			: out std_logic := '0';										-- Avalon MM clk_en output
		Qbyteen			: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output
		
		Qreaddata		: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output
		Qreaddata_valid: out std_logic												-- Avalon MM readdata_valid (to master) output
				
	);
	end component;

	signal internal_reset_0	: std_logic := '0';
	signal internal_reset_1	: std_logic := '0';
	
	signal Address_0		: std_logic_vector(AddressSize downto 0);	
	signal read_0			: std_logic;	
	signal chipselect_0	: std_logic;
	signal reset_n_0		: std_logic;	
	signal clk_en_0		: std_logic;	
	signal byteen_0		: std_logic_vector(byteenSize downto 0);
			
	signal Address_1		: std_logic_vector(AddressSize downto 0);	
	signal read_1			: std_logic;	
	signal chipselect_1	: std_logic;
	signal reset_n_1		: std_logic;	
	signal clk_en_1		: std_logic;	
	signal byteen_1		: std_logic_vector(byteenSize downto 0);
	
	begin 
	
		
		DEVICE_REGFILE_ACCESS_CONTROLLER_RDWR_0 : register_file_access_controller_rdwr 
		generic map(
			AddressSize => AddressSize,
			dataSize		=> dataSize,
			byteenSize	=> byteenSize
		)
		port map(
			
			clock 		=> clock,
			 
			reset			=> internal_reset_0,
			enable		=> enable_0,
					
			DAddress		=> DAddress_0,
			Dread			=> Dread_0,
			Dchipselect	=> Dchipselect_0,
			Dreset_n		=> Dreset_n_0,
			Dclk_en		=> Dclk_en_0,
			Dbyteen		=> Dbyteen_0,
			
			QAddress		=> Address_0,
			Qread			=> read_0,
			Qchipselect	=> chipselect_0,
			Qreset_n		=> reset_n_0,
			Qclk_en		=> clk_en_0,
			Qbyteen		=> byteen_0
			
		);
		
		DEVICE_REGFILE_ACCESS_CONTROLLER_RDWR_1 : register_file_access_controller_rdwr 
		generic map(
			AddressSize => AddressSize,
			dataSize		=> dataSize,
			byteenSize	=> byteenSize
		)
		port map(
			
			clock 		=> clock,
			 
			reset			=> internal_reset_1,
			enable		=> enable_1,
					
			DAddress		=> DAddress_1,
			Dread			=> Dread_1,
			Dchipselect	=> Dchipselect_1,
			Dreset_n		=> Dreset_n_1,
			Dclk_en		=> Dclk_en_1,
			Dbyteen		=> Dbyteen_1,
			
			QAddress		=> Address_1,
			Qread			=> read_1,
			Qchipselect	=> chipselect_1,
			Qreset_n		=> reset_n_1,
			Qclk_en		=> clk_en_1,
			Qbyteen		=> byteen_1
			
		);

		DEVICE_INSTRUCTION_SELECTOR_0 : instruction_selector 
		generic map(
			AddressSize 	=> AddressSize,
			dataSize			=> dataSize,
			byteenSize		=> byteenSize
		)
		port map(
			
			clock 			=> clock,
			 
			reset				=> reset,								 
			sel				=> select_0,
					
			DAddress			=> Address_0,
			Dread				=> read_0,
			Dchipselect		=> chipselect_0,
			Dreset_n			=> reset_n_0,
			Dclk_en			=> clk_en_0,
			Dbyteen			=> byteen_0,
			
			Dreaddata		=> Dreaddata_0,
			Dreaddata_valid=> Dreaddata_valid_0,
			
			QAddress			=> QAddress_0,
			Qread				=> Qread_0,
			Qchipselect		=> Qchipselect_0,
			Qreset_n			=> Qreset_n_0,
			Qclk_en			=> Qclk_en_0,
			Qbyteen			=> Qbyteen_0,
			
			Qreaddata		=> Qreaddata_0,
			Qreaddata_valid=> Qreaddata_valid_0
					
		);
		
		DEVICE_INSTRUCTION_SELECTOR_1 : instruction_selector 
		generic map(
			AddressSize 	=> AddressSize,
			dataSize			=> dataSize,
			byteenSize		=> byteenSize
		)
		port map(
			
			clock 			=> clock,
			 
			reset				=> reset,								 
			sel				=> select_1,
					
			DAddress			=> Address_1,
			Dread				=> read_1,
			Dchipselect		=> chipselect_1,
			Dreset_n			=> reset_n_1,
			Dclk_en			=> clk_en_1,
			Dbyteen			=> byteen_1,
			
			Dreaddata		=> Dreaddata_1,
			Dreaddata_valid=> Dreaddata_valid_1,
			
			QAddress			=> QAddress_1,
			Qread				=> Qread_1,
			Qchipselect		=> Qchipselect_1,
			Qreset_n			=> Qreset_n_1,
			Qclk_en			=> Qclk_en_1,
			Qbyteen			=> Qbyteen_1,
			
			Qreaddata		=> Qreaddata_1,
			Qreaddata_valid=> Qreaddata_valid_1
					
		);
			
		addressAquired_0 <= Address_0;	
		addressAquired_1 <= Address_1;
		
		internal_reset_0 <= reset or clear_0;
		internal_reset_1 <= reset or clear_1;
		
end architecture;





