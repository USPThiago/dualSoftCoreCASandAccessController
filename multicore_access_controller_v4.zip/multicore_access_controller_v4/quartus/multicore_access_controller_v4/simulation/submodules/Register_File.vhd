
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity Register_File is
port(
	-- System inputs		  --
	clock 	: in  std_logic;
	reset 	: in  std_logic;
	-------------------------
	-- Data Out 			  							    --
	reg_index	: in  std_logic_vector(7  downto 0);
	Q				: out std_logic_vector(31 downto 0);
	------------------------------------------------
	-- Avalon MM slave bus 													 --
	avs_slave_address			   : in  std_logic_vector(31 downto 0);
	avs_slave_chipselect			: in 	std_logic;
	avs_slave_write				: in  std_logic;
	avs_slave_writedata			: in  std_logic_vector(31 downto 0)
	---------------------------------------------------------------
); 
end entity Register_File;


architecture behavior of Register_File is

	component registrador is
	port(
		clock 	: in  std_logic;
		clear 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic_vector(31 downto 0);
		Q 			: out std_logic_vector(31 downto 0)
	); 
	end component registrador;
	
	signal en_reg_1 : std_logic := '0';
	signal en_reg_2 : std_logic := '0';
	signal en_reg_3 : std_logic := '0';
	signal en_reg_4 : std_logic := '0';
	
	signal q_reg_1  : std_logic_vector(31 downto 0);
	signal q_reg_2  : std_logic_vector(31 downto 0);
	signal q_reg_3  : std_logic_vector(31 downto 0);
	signal q_reg_4  : std_logic_vector(31 downto 0);
	
	begin
	
		REG_1 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> en_reg_1,
			D			=> avs_slave_writedata,
			Q 			=> q_reg_1
		); 
		
		REG_2 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> en_reg_2,
			D			=> avs_slave_writedata,
			Q 			=> q_reg_2
		); 
		 
		REG_3 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> en_reg_3,
			D			=> avs_slave_writedata,
			Q 			=> q_reg_3
		);  
		 
		REG_4 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> en_reg_4,
			D			=> avs_slave_writedata,
			Q 			=> q_reg_4
		);  
		
		en_reg_1 <= '1' 		when avs_slave_write = '1' and avs_slave_chipselect = '1' 												 else '0';
		en_reg_2 <= '1' 		when avs_slave_write = '1' and avs_slave_chipselect = '1' and avs_slave_address = x"00000001" else '0';			
		en_reg_3 <= '1' 		when avs_slave_write = '1' and avs_slave_chipselect = '1' and avs_slave_address = x"00000002" else '0';
		en_reg_4 <= '1' 		when avs_slave_write = '1' and avs_slave_chipselect = '1' and avs_slave_address = x"00000003" else '0';
		
		Q 			<= q_reg_1 	when reg_index = x"00" else
						q_reg_2 	when reg_index = x"01" else
						q_reg_3 	when reg_index = x"02" else
						q_reg_4 	when reg_index = x"03" else
						(others => '0');
		
end architecture behavior;
		
		 
		 