
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity register_file_access_controller_rdwr is
generic(
	AddressSize : integer := 9;
	dataSize		: integer := 31;
	byteenSize	: integer := 3
);
port(
	
	clock 		: in  std_logic;
	 
	reset			: in  std_logic := '0'; 									-- force all registers states to zero 
	enable		: in  std_logic := '0';										-- enable register to write the inputs 
			
	DAddress		: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input
	Dread			: in  std_logic := '0';										-- Avalon MM read input
	Dchipselect	: in  std_logic := '0';										-- Avalon MM chipselect input
	Dreset_n		: in  std_logic := '1';										-- Avalon MM reset_n input
	Dclk_en		: in  std_logic := '0';										-- Avalon MM clk_en input
	Dbyteen		: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input
	
	QAddress		: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output
	Qread			: out std_logic := '0';										-- Avalon MM read output
	Qchipselect	: out std_logic := '0';										-- Avalon MM chipselect outpuy
	Qreset_n		: out std_logic := '1';										-- Avalon MM reset_n output
	Qclk_en		: out std_logic := '0';										-- Avalon MM clk_en output
	Qbyteen		: out std_logic_vector(byteenSize downto 0)			-- Avalon MM byteen output
	
);
end entity;


architecture behavior of register_file_access_controller_rdwr is

	component register_n_bit is
	generic(
		dataSize	: integer := 31
	);
	port(
		clock		: in  std_logic;
		reset 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic_vector(dataSize downto 0);
		Q 			: out std_logic_Vector(dataSize downto 0)
	);
	end component;
	
	signal internal_DAddress	: std_logic_Vector(AddressSize downto 0);
	signal internal_Dread	 	: std_logic_vector(0 downto 0);
	signal internal_Dchipselect: std_logic_vector(0 downto 0);
	signal internal_Dreset_n 	: std_logic_vector(0 downto 0);
	signal internal_Dclk_en		: std_logic_vector(0 downto 0);
	signal internal_Dbyteen 	: std_logic_vector(byteenSize downto 0);
	
	signal internal_QAddress	: std_logic_Vector(AddressSize downto 0);
	signal internal_Qread	 	: std_logic_vector(0 downto 0);
	signal internal_Qchipselect: std_logic_vector(0 downto 0);
	signal internal_Qreset_n 	: std_logic_vector(0 downto 0);
	signal internal_Qclk_en		: std_logic_vector(0 downto 0);
	signal internal_Qbyteen 	: std_logic_vector(byteenSize downto 0);
	
	begin 
		
		DEVICE_DELAY_Address_rdwr : register_n_bit 
		generic map(
			dataSize	=> AddressSize
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable,
			D			=> internal_DAddress,
			Q 			=> internal_QAddress
		);
		
		DEVICE_DATAA_read_rdwr : register_n_bit 
		generic map(
			dataSize	=> 0
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable,
			D			=> internal_Dread,
			Q 			=> internal_Qread
		);
		
		DEVICE_DATAB_clk_en_rdwr : register_n_bit 
		generic map(
			dataSize	=> 0
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable,
			D			=> internal_Dclk_en,
			Q 			=> internal_Qclk_en
		);
		
		DEVICE_chipselect_rdwr : register_n_bit 
		generic map(
			dataSize	=> 0
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable,
			D			=> internal_Dchipselect,
			Q 			=> internal_Qchipselect
		);

		DEVICE_START_reset_n_rdwr : register_n_bit 
		generic map(
			dataSize	=> 0
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable,
			D			=> internal_Dreset_n,
			Q 			=> internal_Qreset_n
		);
	
		DEVICE_START_byteen_rdwr : register_n_bit 
		generic map(
			dataSize	=> byteenSize
		)
		port map(
			clock		=> clock,
			reset 	=> reset,
			enable	=> enable,
			D			=> internal_Dbyteen,
			Q 			=> internal_Qbyteen
		);
	
		internal_DAddress			<= DAddress;
		internal_Dread(0)	 		<= Dread;
		internal_Dchipselect(0)	<= Dchipselect;
		internal_Dreset_n(0) 	<= Dreset_n;
		internal_Dclk_en(0)		<= Dclk_en;
		internal_Dbyteen 			<= Dbyteen;
	
		QAddress		<= internal_QAddress;
		Qread			<= internal_Qread(0);
		Qchipselect	<= internal_Qchipselect(0);
		Qreset_n		<= internal_Qreset_n(0);
		Qclk_en		<= internal_Qclk_en(0);
		Qbyteen		<= internal_Qbyteen;
		
end architecture;
	
