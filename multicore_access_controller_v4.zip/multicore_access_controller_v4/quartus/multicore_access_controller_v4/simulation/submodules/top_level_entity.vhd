

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity top_level_entity is
	generic(
		dataSize					: integer := 31;
		AddressSize				: integer := 9
	);
	port(
		clock						: in  std_logic;
		reset						: in  std_logic;
		
		-- uP 0 bus							  --
		-- uP communication signals     --
		avs_address_0   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect_0		: in  std_logic                     := '0';
		avs_read_0     		: in  std_logic                     := '0'; 	
		avs_write_0     		: in  std_logic                     := '0';             
		avs_writedata_0		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_waitrequest_0		: out std_logic							:= '0';
		avs_readdata_0			: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		avs_readdata_valid_0	: out std_logic;
		
		tas_lock_0				: in  std_logic;
		tas_locked_0			: out std_logic;	
		tas_unlock_0			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata_0  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address_0    		: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken_0     		: out std_logic                     := '0';              
		avm_chipselect_0 		: out std_logic                     := '0';              				-- enable componente to work
		avm_read_0				: out std_logic							:= '0';
		avm_write_0      		: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata_0  		: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable_0		: out std_logic_vector(3 downto 0)  := (others => '0'); 		                   
		avm_waitrequest_0	   : in  std_logic      				   := '1'; 									-- waitrequest RAM component. Active in low
		
		-- load logic communication signals --
		compare_and_swap_address_0	: out std_logic_vector(9 downto 0);
		compare_and_swap_locked_0	: out std_logic;
		load_address_0					: in  std_logic_vector(9 downto 0);
		load_locked_0					: in  std_logic;
		
		-- db signals 						  --
		db_state_uc_0			: out std_logic_vector(3 downto 0);
		-- uP 1 bus							  --
		-- uP communication signals     --
		avs_address_1   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect_1		: in  std_logic                     := '0';
		avs_read_1     		: in  std_logic                     := '0'; 	
		avs_write_1     		: in  std_logic                     := '0';             
		avs_writedata_1		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_waitrequest_1		: out std_logic							:= '0';
		avs_readdata_1			: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		avs_readdata_valid_1	: out std_logic;
		
		tas_lock_1				: in  std_logic; 
		tas_locked_1			: out std_logic;
		tas_unlock_1			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata_1  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address_1    		: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken_1     		: out std_logic                     := '0';              
		avm_chipselect_1 		: out std_logic                     := '0';              				-- enable componente to work
		avm_read_1				: out std_logic							:= '0';
		avm_write_1      		: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata_1  		: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable_1		: out std_logic_vector(3 downto 0) := (others => '0'); 		                   
		avm_waitrequest_1	   : in  std_logic      				   := '1'; 									-- waitrequest RAM component. Active in low
		
		-- load logic communication signals --
		compare_and_swap_address_1	: out std_logic_vector(9 downto 0);
		compare_and_swap_locked_1	: out std_logic;
		load_address_1					: in  std_logic_vector(9 downto 0);
		load_locked_1					: in  std_logic;
		
		
		-- db signals 						  --
		db_state_uc_1			: out std_logic_vector(3 downto 0)
	); 
end entity;


architecture behavior of top_level_entity is

	component fluxo_de_dados_access_controller is
	generic(
		dataSize				: integer := 31;
		AddressSize			: integer := 9
	);
	port(
		clock					: in  std_logic;
		reset					: in  std_logic;
		
		-- uc signals					     --
		en_custom_regfile 	: in  std_logic;		-- enable communication with uP 
		en_avm_regfile			: in  std_logic;		-- enable communication with shared resource
		en_mutex					: in  std_logic;
		reset_custom_regfile : in  std_logic;		-- clear last transation 
		reset_avm_regfile		: in  std_logic;		-- clear last transation 
		Uc_lock					: in  std_logic;		-- acquire mutex
		
		read						: out std_logic;
		
		-- free logic componente communication --
		new_address 		 : out std_logic_vector(AddressSize  downto 0);
		mutex_address		 : out std_logic_vector(AddressSize  downto 0);
		mutex_locked	 	 : out std_logic;
		
		-- uP communication signals     --
		avs_address   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
		avs_chipselect		: in  std_logic                     := '0';
		avs_read      		: in  std_logic                     := '0'; 	
		avs_write     		: in  std_logic                     := '0';             
		avs_writedata 		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		avs_readdata		: out std_logic_vector(dataSize	 downto 0) := (others => '0');
		
		tas_lock				: in  std_logic; 
		tas_unlock			: in  std_logic;
		
		-- Memory communication signals --
		avm_readdata  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
			
		avm_address    	: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
		avm_clken     		: out std_logic                     := '0';              
		avm_chipselect 	: out std_logic                     := '0';              				-- enable componente to work
		avm_read				: out std_logic							:= '0';
		avm_write      	: out std_logic                     := '0';              				-- enable a write operation
		avm_writedata  	: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
		avm_byteenable 	: out std_logic_vector(3 downto 0) := (others => '0'); 		                   
		avm_reset_reset_n : out std_logic      				   := '1' 									-- reset RAM component. Active in low
		
		-- db signals 						  --
	); 
	end component;

	component unidade_de_controle_access_controller is
		port(
			----------------------------
			-- system inputs			  --
			----------------------------
			clock 					: in  std_logic;
			reset						: in  std_logic;
			done						: out std_logic;		-- indicates to uP that operation ended
			----------------------------
			-- control signals inputs --
			----------------------------
			start_i					: in  std_logic;		-- shoud be connect to Avalon MM chipselect signal referent to current uP 
			start_j					: in  std_logic;		-- shoud be connect to Avalon MM chipselect signal referent the other uP
			read						: in  std_logic;
			free						: in  std_logic;		-- indicates that mutex is free to be locked and operation should be accepted
			----------------------------
			-- output signals 		  --
			----------------------------
			en_custom_regfile 	: out std_logic;		-- enable communication with uP 
			en_avm_regfile			: out std_logic;		-- enable communication with shared resource
			en_mutex					: out std_logic;		-- enable mutex acquire a resource
			reset_custom_regfile : out std_logic;		-- clear last transation 
			reset_avm_regfile		: out std_logic;		-- clear last transation 
			lock						: out std_logic;		-- acquire mutex
			locked					: out std_logic;		-- indicates to uP that mutex has been locked
			----------------------------
			-- db signals				  --
			----------------------------
			db_state 				: out std_logic_vector(3 downto 0)
		); 
	end component;

	component free_signal_logic_generator is
	port(
		------------------------------------------
		-- uc 0 signals								 --
		------------------------------------------
		cas_address_0				 : in  std_logic_vector(9  downto 0); 
		new_address_0 				 : in  std_logic_vector(9  downto 0);
		load_locked_1				 : in  std_logic;
		load_acquired_address_1	 : in  std_logic_vector(9  downto 0);
		mutex_acquired_address_1 : in  std_logic_vector(9  downto 0);
		mutex_locked_1	 			 : in  std_logic;
		free_0	 					 : out std_logic;
		------------------------------------------
		-- uc 1 signals								 --
		------------------------------------------
		cas_address_1				 : in  std_logic_vector(9  downto 0); 
		new_address_1 				 : in  std_logic_vector(9  downto 0);
		load_locked_0				 : in  std_logic;
		load_acquired_address_0	 : in  std_logic_vector(9  downto 0);
		mutex_acquired_address_0 : in  std_logic_vector(9  downto 0);
		mutex_locked_0	 			 : in  std_logic;
		free_1	 					 : out std_logic
	);
	end component;

	constant top_level_dataSize 		: integer := 31;
	constant top_level_AddressSize 	: integer := 9;
	
	signal internal_en_custom_regfile_0 	: std_logic;
	signal internal_en_avm_regfile_0			: std_logic;
	signal internal_reset_custom_regfile_0	: std_logic;
	signal internal_reset_avm_regfile_0		: std_logic;
	signal internal_Uc_lock_0					: std_logic;
	
	signal internal_new_address_0				: std_logic_vector(top_level_AddressSize downto 0);
	signal internal_mutex_address_0			: std_logic_vector(top_level_AddressSize downto 0);
	signal internal_mutex_locked_0			: std_logic;
	
	signal internal_read_0						: std_logic;
	signal internal_free_0						: std_logic;
	
	signal internal_en_custom_regfile_1 	: std_logic;
	signal internal_en_avm_regfile_1			: std_logic;
	signal internal_reset_custom_regfile_1	: std_logic;
	signal internal_reset_avm_regfile_1		: std_logic;
	signal internal_Uc_lock_1					: std_logic;
	
	signal internal_new_address_1				: std_logic_vector(AddressSize downto 0);
	signal internal_mutex_address_1			: std_logic_vector(AddressSize downto 0);
	signal internal_mutex_locked_1			: std_logic;
	
	signal internal_read_1						: std_logic;
	signal internal_free_1						: std_logic;
	
	signal internal_en_mutex_0					: std_logic;
	signal internal_en_mutex_1					: std_logic;
	
	begin 
	
		DEVICE_FLUXO_DE_DADOS_0 : fluxo_de_dados_access_controller generic map(
			dataSize					=> top_level_dataSize,
			AddressSize				=> top_level_AddressSize
		)
		port map(
			clock						=> clock,
			reset						=> reset,
			
			-- uc signals					     --
			en_custom_regfile 	=> internal_en_custom_regfile_0,
			en_avm_regfile			=> internal_en_avm_regfile_0,
			en_mutex					=>	internal_en_mutex_0,
			reset_custom_regfile => internal_reset_custom_regfile_0,
			reset_avm_regfile		=> internal_reset_avm_regfile_0, 
			Uc_lock					=> internal_Uc_lock_0,
			
			read						=> internal_read_0,
			
			-- free logic componente communication --
			new_address 		   => internal_new_address_0,
			mutex_address		   => internal_mutex_address_0,
			mutex_locked	 	   => internal_mutex_locked_0,
			
			-- uP communication signals     --
			avs_address   		   => avs_address_0(9 downto 0),       
			avs_chipselect		   => avs_chipselect_0,
			avs_read      		   => avs_read_0,
			avs_write     		   => avs_write_0,   
			avs_writedata 			=> avs_writedata_0,
			
			avs_readdata			=> avs_readdata_0,
			
			tas_lock					=> tas_lock_0,
			tas_unlock				=> tas_unlock_0,
			
			-- Memory communication signals --
			avm_readdata  			=> avm_readdata_0,						-- data received from memory
				
			avm_address    	  	=> avm_address_0(9 downto 0),			-- especify one position of memory
			avm_clken     		   => avm_clken_0,           
			avm_chipselect 	   => avm_chipselect_0,     				-- enable componente to work
			avm_read					=> avm_read_0,
			avm_write      	   => avm_write_0,           				-- enable a write operation
			avm_writedata  	  	=> avm_writedata_0,						-- data to be store in memory 
			avm_byteenable 		=> avm_byteenable_0,	                 
			avm_reset_reset_n  	=> open										-- reset RAM component. Active in low
			
			-- db signals 						  --
		); 
		
		DEVICE_FLUXO_DE_DADOS_1 : fluxo_de_dados_access_controller generic map(
			dataSize					=> top_level_dataSize,
			AddressSize				=> top_level_AddressSize
		)
		port map(
			clock						=> clock,
			reset						=> reset,
			
			-- uc signals					     --
			en_custom_regfile 	=> internal_en_custom_regfile_1,
			en_avm_regfile			=> internal_en_avm_regfile_1,
			en_mutex					=>	internal_en_mutex_1,
			reset_custom_regfile => internal_reset_custom_regfile_1,
			reset_avm_regfile		=> internal_reset_avm_regfile_1, 
			Uc_lock					=> internal_Uc_lock_1,
			
			read						=> internal_read_1,
			
			-- free logic componente communication --
			new_address 		   => internal_new_address_1(9 downto 0),
			mutex_address		   => internal_mutex_address_1(9 downto 0),
			mutex_locked	 	   => internal_mutex_locked_1,
			
			-- uP communication signals     --
			avs_address   		   => avs_address_1(9 downto 0),       
			avs_chipselect		   => avs_chipselect_1,
			avs_read      		   => avs_read_1,
			avs_write     		   => avs_write_1,   
			avs_writedata 			=> avs_writedata_1,
			
			avs_readdata			=> avs_readdata_1,
			
			tas_lock					=> tas_lock_1,
			tas_unlock				=> tas_unlock_1,
			
			-- Memory communication signals --
			avm_readdata  			=> avm_readdata_1,						-- data received from memory
				
			avm_address    	  	=> avm_address_1(9 downto 0),							-- especify one position of memory
			avm_clken     		   => avm_clken_1,           
			avm_chipselect 	   => avm_chipselect_1,     				-- enable componente to work
			avm_read					=> avm_read_1,
			avm_write      	   => avm_write_1,           				-- enable a write operation
			avm_writedata  	  	=> avm_writedata_1,						-- data to be store in memory 
			avm_byteenable 		=> avm_byteenable_1,	                 
			avm_reset_reset_n  	=> open										-- reset RAM component. Active in low
			
			-- db signals 						  --
		); 
		
		DEVICE_UNIDADE_DE_CONTROLE_0 : unidade_de_controle_access_controller port map(
			----------------------------
			-- system inputs			  --
			----------------------------
			clock 					=> clock,
			reset						=> reset,
			done						=> avs_readdata_valid_0,				-- indicates to uP that operation ended
			----------------------------
			-- control signals inputs --
			----------------------------
			start_i					=> avs_chipselect_0,						-- shoud be connect to Avalon MM chipselect signal 
			start_j					=> avs_chipselect_1,						-- shoud be connect to Avalon MM chipselect signal referent the other uP
			read						=> internal_read_0,
			free						=> internal_free_0,						-- indicates that mutex is free to be locked and operation should be accepted
			----------------------------
			-- output signals 		  --
			----------------------------
			en_custom_regfile 	=> internal_en_custom_regfile_0,		-- enable communication with uP 
			en_avm_regfile			=> internal_en_avm_regfile_0,			-- enable communication with shared resource
			en_mutex					=> internal_en_mutex_0,
			reset_custom_regfile => internal_reset_custom_regfile_0,	-- clear last transation 
			reset_avm_regfile		=> internal_reset_avm_regfile_0,		-- clear last transation 
			lock						=> internal_uc_lock_0,					-- acquire mutex
			locked					=> tas_locked_0,							-- indicates to uP that mutex has been locked
			----------------------------
			-- db signals				  --
			----------------------------
			db_state 				=> db_state_uc_0
		);
	
		DEVICE_UNIDADE_DE_CONTROLE_1 : unidade_de_controle_access_controller port map(
			----------------------------
			-- system inputs			  --
			----------------------------
			clock 					=> clock,
			reset						=> reset,
			done						=> avs_readdata_valid_1,				-- indicates to uP that operation ended
			----------------------------
			-- control signals inputs --
			----------------------------
			start_i					=> avs_chipselect_1,						-- shoud be connect to Avalon MM chipselect signal 
			start_j					=> avs_chipselect_0,						-- shoud be connect to Avalon MM chipselect signal referent the other uP
			read						=> internal_read_1,
			free						=> internal_free_1,						-- indicates that mutex is free to be locked and operation should be accepted
			----------------------------
			-- output signals 		  --
			----------------------------
			en_custom_regfile 	=> internal_en_custom_regfile_1,		-- enable communication with uP 
			en_avm_regfile			=> internal_en_avm_regfile_1,			-- enable communication with shared resource
			en_mutex					=> internal_en_mutex_1,	
			reset_custom_regfile => internal_reset_custom_regfile_1,	-- clear last transation 
			reset_avm_regfile		=> internal_reset_avm_regfile_1,		-- clear last transation 
			lock						=> internal_uc_lock_1,					-- acquire mutex
			locked					=> tas_locked_1,							-- indicates to uP that mutex has been locked
			----------------------------
			-- db signals				  --
			----------------------------
			db_state 				=> db_state_uc_1
		); 	
		
		DEVICE_FREE_LOGIC_GENERATOR : free_signal_logic_generator port map(
			------------------------------------------
			-- uc 0 signals								 --
			------------------------------------------
			cas_address_0				 => avs_address_0,
			new_address_0 				 => internal_new_address_0,
			load_locked_1				 => load_locked_1,
			mutex_acquired_address_1 => internal_mutex_address_1(9 downto 0),
			load_acquired_address_1	 => load_address_1,
			mutex_locked_1	 			 => internal_mutex_locked_1,
			free_0	 					 => internal_free_0,
			------------------------------------------
			-- uc 1 signals								 --
			------------------------------------------
			cas_address_1				 => avs_address_1,
			new_address_1 				 => internal_new_address_1(9 downto 0),
			load_locked_0				 => load_locked_0,
			mutex_acquired_address_0 => internal_mutex_address_0,
			load_acquired_address_0	 => load_address_0,
			mutex_locked_0	 			 => internal_mutex_locked_0,
			free_1	 					 => internal_free_1
		);	
		
		compare_and_swap_address_0 <= internal_mutex_address_0;
		compare_and_swap_locked_0  <= internal_mutex_locked_0;
		
		compare_and_swap_address_1 <= internal_mutex_address_1;
		compare_and_swap_locked_1  <= internal_mutex_locked_1;
		
		
		avs_waitrequest_0 <= '0';
		avs_waitrequest_1 <= '0';
	
end architecture;
	