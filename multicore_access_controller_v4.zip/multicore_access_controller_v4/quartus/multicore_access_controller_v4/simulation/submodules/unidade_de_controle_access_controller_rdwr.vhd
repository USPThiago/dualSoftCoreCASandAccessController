
library ieee;
use 	  ieee.std_logic_1164.all;
use 	  ieee.numeric_std.all;

entity unidade_de_controle_access_controller_rdwr is
generic(
	AddressSize 				: integer := 9;
	dataSize						: integer := 31;
	byteenSize					: integer := 3
);
port(
	
	clock 							: in  std_logic;
	reset 							: in  std_logic;
	
	chipselect_0					: in  std_logic;											-- Load Instruction 0        Nios II 0					  --
	chipselect_1					: in  std_logic;											-- Load Instruction 1		  Nios II 1					  --
	
	read_0							: in  std_logic;											-- Load Instruction 0        Nios II 0					  --
	read_1							: in  std_logic;											-- Load Instruction 1        Nios II 1					  --
	
	load_address_0 				: in  std_logic_vector(AddressSize downto 0);	-- Load Instruction 0        Nios II 0					  --
	load_address_1 				: in  std_logic_vector(AddressSize downto 0);	-- Load Instruction 1        Nios II 1					  --
	
	compare_and_swap_address_0 : in  std_logic_vector(AddressSize downto 0);	-- Access controller signal: Nios II 0					  --
	compare_and_swap_address_1 : in  std_logic_vector(AddressSize downto 0);	-- Access controller signal: Nios II 1					  --
	compare_and_swap_locked_0	: in  std_logic;											-- Access controller signal: Nios II 0					  --
	compare_and_swap_locked_1	: in  std_logic;											-- Access controller signal: Nios II 1					  --
	
	readdata_valid_0				: out std_logic;											-- access controller signal: Nios II 0					  --
	readdata_valid_1				: out std_logic;											-- access controller signal: Nios II 1					  --
	load_locked_0					: out std_logic;											-- Access controller signal: Nios II 0					  --
	load_locked_1					: out std_logic;											-- Access controller signal: Nios II 1					  --
	clear_0 							: out std_logic;											-- Control signal - Data Path access controlelr rdwr --  
	clear_1							: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 	
	enable_0 						: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 
	enable_1 						: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 
	select_0 						: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 
	select_1 						: out std_logic											-- Control signal - Data Path access controlelr rdwr -- 
	
);
end entity;

architecture behavior of unidade_de_controle_access_controller_rdwr is

	type state_t0 is (init0, delay_state0, requiredata0, receivedata0, concorrence0, clear_state0);
	signal state0, next_state0 : state_t0;
	
	type state_t1 is (init1, delay_state1, requiredata1, receivedata1, concurrence1, clear_state1);
	signal state1, next_state1 : state_t1;
	
	begin 
	
		stimulus_channel_0 : process(clock)
		begin 
			if reset = '1' then 
				state0 <= init0;
			else
				if clock'event and clock = '1' then
					state0 <= next_state0;
				end if;
			end if;
		end process;
		
		stimulus_channel_1 : process(clock)
		begin 
			if reset = '1' then 
				state1 <= init1;
			else
				if clock'event and clock = '1' then
					state1 <= next_state1;
				end if;
			end if;
		end process;
		
		next_state0 <= init0 			when state0 = init0 			and (chipselect_0 = '0' or read_0 = '0') 			  												  	else
							delay_state0	when state0 = init0																			  												  	else
							concorrence0	when state0 = delay_state0	and (compare_and_swap_address_1 = load_address_0 and compare_and_swap_locked_1 = '1') 	else
							concorrence0	when state0 = concorrence0 and (compare_and_swap_address_1 = load_address_0 and compare_and_swap_locked_1 = '1') 	else
							requiredata0	when state0 = concorrence0 																  												  	else
							requiredata0	when state0 = delay_state0															 		  												  	else
							receivedata0 	when state0 = requiredata0  											   				  												  	else
							clear_state0	when state0 = receivedata0  																										 		  	else
							init0				when state0 = clear_state0															 		  												  	else
							init0;
		
		next_state1 <= init1		 		when state1 = init1 and (chipselect_1 = '0' or read_1 = '0') 			 															else
							delay_state1	when state1 = init1     															 															else
							concurrence1	when state1 = delay_state1 and (compare_and_swap_address_0 = load_address_1 and compare_and_swap_locked_0 = '1') 	else
							concurrence1	when state1 = concurrence1 and (compare_and_swap_address_0 = load_address_1 and compare_and_swap_locked_0 = '1') 	else
							requiredata1 	when state1 = concurrence1															 															else
							requiredata1	when state1 = delay_state1															 															else
							receivedata1 	when state1 = requiredata1															 															else
							clear_state1	when state1 = receivedata1															 															else
							init1				when state1 = clear_state1															 															else
							init1;
		
		readdata_valid_0	<= '1' when state0 = receivedata0 							 		else '0';
		load_locked_0 		<= '1' when state0 = receivedata0 or state0 = requiredata0 	else '0';			
		clear_0 		  		<= '1' when state0 = clear_state0 or reset = '1'				else '0';				
		enable_0 	  		<= '1' when state0 = init0											 	else '0';		
		select_0 	  		<= '1' when state0 = receivedata0 								 	else 
									'1' when state0 = requiredata0								   else
									'1' when state0 = clear_state0									else
									'0';		
		
		readdata_valid_1	<= '1' when state1 = receivedata1 							 		else '0';	
		load_locked_1 		<= '1' when state1 = receivedata1 or state1 = requiredata1	else '0';			
		clear_1 		  		<= '1' when state1 = clear_state1 or reset = '1'				else '0';				
		enable_1 	  		<= '1' when state1 = init1											 	else '0';		
		select_1 	  		<= '1' when state1 = receivedata1 								 	else 
									'1' when state1 = requiredata1								   else
									'1' when state1 = clear_state1									else
									'0';			
		
end architecture behavior;		