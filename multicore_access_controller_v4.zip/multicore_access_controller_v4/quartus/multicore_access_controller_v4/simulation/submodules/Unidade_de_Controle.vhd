
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Unidade_de_Controle_CAS is
port(	
	-- System signals 			     --
	clock 				: in  std_logic;
	start					: in  std_logic;
	reset					: in  std_logic;
	enable_registers	: out std_logic;
	enable_load_data	: out std_logic;
	set_result			: out std_logic;
	done 					: out std_logic;
	----------------------------------
	-- Avalon Master signals 	     --
	readdata_valid		: in	std_logic;
	read					: out std_logic;
	write					: out std_logic;
	chipselect			: out std_logic;
	----------------------------------
	-- Compare Signal				     -- 
	equal					: in  std_logic;
	----------------------------------
	-- Internal Timer signals 	  	  --
	timer_done			: in  std_logic;
	timer_reset			: out std_logic;
	timer_enable		: out std_logic;
	----------------------------------
	-- Test-and-Set signals 	  	  --
	tas_locked			: in  std_logic;
	tas_lock				: out std_logic;
	tas_unlock			: out std_logic;
	----------------------------------
	-- processing signal				  --
	processing			: out std_logic;
	----------------------------------
	-- Debug signals 					  				 		  -- 
	deb_state			: out std_logic_vector(2 downto 0)
	----------------------------------------------------
);	
end entity Unidade_de_Controle_CAS;


architecture behavior of Unidade_de_Controle_CAS is

	type state_t is (INIT, ACQUIRE, READ_MEM, LOAD_DATA, STORE_MEM, STORE_DATA, RESULT, END_INSTRUCTION);
	signal state, next_state, last_state : state_t;
	
	begin 
	
		process(clock)
		begin 
			if reset = '1' then 
				state 	  <= INIT;
				last_state <= INIT;
			else
				if clock'event and clock = '1' then
					state 		<= next_state;
					last_state  <= state;
				end if;
			end if;
		end process;
		
		next_state <= READ_MEM				when state = END_INSTRUCTION 						 	 and start      = '1'	else
						  READ_MEM				when state = INIT			and start  		 = '1'									else
						  ACQUIRE 				when state = READ_MEM							    									else
						  ACQUIRE 				when state = ACQUIRE 	and readdata_valid = '0' and timer_done = '0'	else
						  LOAD_DATA				when state = ACQUIRE 	and readdata_valid = '1' and tas_locked = '1'	else
						  END_INSTRUCTION		when state = ACQUIRE 	and readdata_valid = '1' and tas_locked = '0'	else
						  END_INSTRUCTION		when state = ACQUIRE 	and readdata_valid = '0' and timer_done = '1'	else
						  STORE_MEM 			when state = LOAD_DATA  and equal		 = '1' 									else
						  STORE_DATA			when state = STORE_MEM																	else
						  END_INSTRUCTION    when state = LOAD_DATA  and equal 		 = '0'									else
						  STORE_DATA			when state = STORE_DATA and readdata_valid = '0' and timer_done = '0'	else
						  END_INSTRUCTION		when state = STORE_DATA and readdata_valid = '0' and timer_done = '1' 	else
						  RESULT					when state = STORE_DATA and readdata_valid = '1'								else
						  END_INSTRUCTION    when state = RESULT																		else
						  END_INSTRUCTION		when state = END_INSTRUCTION															else
						  INIT;
						  
		enable_registers 	  <= '1' when state = INIT    				and start = '1'  		 else
									  '1' when state = END_INSTRUCTION     and start = '1'  		 else	
									  '0';
									  
		enable_load_data	  <= '1' when state = ACQUIRE and readdata_valid = '1' else '0';
		
		chipselect 			  <= '1' when state = ACQUIRE    or state = READ_MEM	else
									  '1' when state = STORE_DATA or state = STORE_MEM	else
									  '0';
						  
		read		 			  <= '1' when state = READ_MEM   or state = ACQUIRE   else '0';
		write		 			  <= '1' when state = STORE_DATA	or state = STORE_MEM	else '0';
		done					  <= '1' when state = END_INSTRUCTION  					else '0';				  
		timer_reset 		  <= '0' when state = ACQUIRE									else
									  '0' when state = STORE_DATA								else
									  '1';
									  
		timer_enable		  <= '1' when state = ACQUIRE				else
									  '1' when state = STORE_DATA			else
									  '0';
		
   	tas_lock 			  <= '1' when state = READ_MEM		    else '0'; -- MODIFIED
 --	tas_lock 			  <= '1' when state = STORE_MEM		    else '0'; -- MODIFIED
		tas_unlock 			  <= '1' when state = END_INSTRUCTION	 else '0';
		set_result			  <= '1' when state = RESULT 				 else '0';
		
		processing			  <= '0' when state = INIT					 											else
									  '0' when state = END_INSTRUCTION and last_state = RESULT				else
									  '0' when state = END_INSTRUCTION and last_state = END_INSTRUCTION 	else
									  '1';
		
		
		deb_state			  <= "000" when state = INIT 				 else
									  "001" when state = READ_MEM			 else
									  "010" when state = ACQUIRE			 else
									  "011" when state = LOAD_DATA		 else
									  "100" when state = STORE_MEM		 else
									  "101" when state = STORE_DATA		 else
									  "110" when state = RESULT			 else
									  "111" when state = END_INSTRUCTION else
									  "000";
										
		
end architecture behavior;		
						 
						  
						  
			
		
			
			
		
		
		
		
		
		
	




