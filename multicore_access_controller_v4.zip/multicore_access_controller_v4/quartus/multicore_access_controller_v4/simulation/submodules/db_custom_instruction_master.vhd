
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity db_custom_instruction_master is
port(
	-- system signals --
	clock 						: in  std_logic; 
	reset 						: in  std_logic;
	
	-- Nios inputs --
	db_start_input				: in  std_logic;
	db_done_input				: in  std_logic;
	db_address_input			: in  std_logic_vector(31 downto 0);
	db_expecteddata_input	: in  std_logic_vector(31 downto 0);
	db_newdata_index_input	: in  std_logic_vector(7  downto 0);
	
	-- Nios outputs --
	db_start_output			: out  std_logic;
	db_done_output				: out  std_logic;
	db_address_output			: out  std_logic_vector(31 downto 0);
   db_expecteddata_output	: out  std_logic_vector(31 downto 0);
	db_newdata_index_output	: out  std_logic_vector(7  downto 0)
	
); 
end entity;


architecture behavior of db_custom_instruction_master is

	component registrador is
	port(
		clock 	: in  std_logic;
		clear 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic_vector(31 downto 0);
		Q 			: out std_logic_vector(31 downto 0)
	); 
	end component registrador;
	
	signal db_start			: std_logic_vector(31 downto 0) := (others => '0');
	signal db_done				: std_logic_vector(31 downto 0);
	signal db_address			: std_logic_vector(31 downto 0);
	signal db_expecteddata	: std_logic_vector(31 downto 0);
	signal db_newdata_index	: std_logic_vector(31 downto 0);
	signal internal_db_start_output : std_logic_vector(31 downto 0);
	signal internal_db_done_output  : std_logic_vector(31 downto 0);
	signal enable				: std_logic;
	signal enable_done		: std_logic;
	signal internal_db_newdata_index_output : std_logic_vector(31 downto 0);
	
	begin 
	
		DEVICE_DBREG_0 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> db_start,
			Q	 		=> internal_db_start_output
		); 
		
		DEVICE_DBREG_1 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable_done,
			D			=> db_done,
			Q			=> internal_db_done_output
		);
		
		DEVICE_DBREG_2 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> db_address,
			Q 			=> db_address_output
		);
		
		DEVICE_DBREG_3 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> db_expecteddata,
			Q 			=> db_expecteddata_output
		);
	
		DEVICE_DBREG_4 : registrador port map (
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> db_newdata_index,
			Q			=> internal_db_newdata_index_output
		);
		
		db_start(0)							<= db_start_input;
		db_done(0)							<= db_done_input;
		db_address							<= db_address_input;
		db_expecteddata					<= db_expecteddata_input;
		db_newdata_index(7 downto 0)	<= db_newdata_index_input;
		
		enable								<= not internal_db_start_output(0);
		enable_done							<= not internal_db_done_output(0);
		db_start_output					<= internal_db_start_output(0);
		db_done_output						<= internal_db_done_output(0);
		
		db_newdata_index_output <= internal_db_newdata_index_output(7 downto 0);
	
end architecture;