
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity register_n_bits is
generic(
	dataSize	: integer := 31
);
port(
	clock		: in  std_logic;
	reset 	: in  std_logic;
	enable	: in  std_logic;
	D			: in  std_logic_vector(dataSize downto 0);
	Q 			: out std_logic_Vector(dataSize downto 0)
);
end entity;


architecture behavior of register_n_bits is

	signal internal_Q : std_logic_vector(dataSize downto 0);
	
	begin 
	
		process(clock)
		begin 
		
			if clock'event and clock = '1' then
				if reset = '1' then 
					internal_Q <= (others => '0');
				elsif enable = '1' then
					internal_Q <= D;
				end if;
			end if;
			
		end process;
		
		Q <= internal_Q;

end architecture;