
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity defasador is 
port(
	
	clock 			: in  std_logic;
	reset 			: in  std_logic;
	
	-- users inputs 					  	--
	us_go				: in  std_logic;
	us_delay			: in  std_logic_vector(3 downto 0);
	
	-- custom instruction slave bus 	--
	ci_clk_in		: in  std_logic;
	ci_dataa_in		: in  std_logic_vector(31 downto 0);
	ci_datab_in		: in  std_logic_vector(31 downto 0);
	ci_n_in			: in  std_logic_vector(4  downto 0);
	ci_start_in 	: in  std_logic;
	ci_result_out	: out std_logic_vector(31 downto 0);
	ci_done_out		: out	std_logic; 
		
	-- custom instruction master bus --
	ci_dataa_out	: out std_logic_vector(31 downto 0);
	ci_datab_out	: out std_logic_vector(31 downto 0);
	ci_n_out			: out std_logic_vector(4  downto 0);
	ci_start_out 	: out std_logic;
	ci_result_in	: in  std_logic_vector(31 downto 0);
	ci_done_in		: in 	std_logic
		
		
); 
end entity;


architecture behavior of defasador is 

	COMPONENT unidade_de_controle_defasador is 
	port(
		clock 		: in  std_logic;
		reset			: in  std_logic;
		
		ci_start		: in  std_logic;
		user_start	: in  std_logic;
		eql			: in  std_logic;
		en_reg_ci	: out std_logic;
		en_reg_dly	: out std_logic;
		en_counter	: out std_logic;
		en_output	: out std_logic;
		clear_data	: out std_logic;
		
		db_state		: out std_logic_vector(1 downto 0)
	);  
	end COMPONENT;
	
	component fluxo_de_dados_defasador is
	port(
		
		clock 			: in  std_logic;
		reset				: in  std_logic;
		
		en_reg_ci		: in  std_logic;
		en_reg_delay	: in  std_logic;
		en_counter		: in  std_logic;
		en_output		: in  std_logic; 
		delay_in			: in  std_logic_vector(3  downto 0);
		eql				: out std_logic;
		
		-- custom instruction slave bus --
		ci_dataa_in		: in  std_logic_vector(31 downto 0);
		ci_datab_in		: in  std_logic_vector(31 downto 0);
		ci_n_in			: in  std_logic_vector(4  downto 0);
		ci_start_in 	: in  std_logic;
		ci_result_out	: out std_logic_vector(31 downto 0);
		ci_done_out		: out	std_logic; 
		
		-- custom instruction master bus --
		ci_dataa_out	: out std_logic_vector(31 downto 0);
		ci_datab_out	: out std_logic_vector(31 downto 0);
		ci_n_out			: out std_logic_vector(4  downto 0);
		ci_start_out 	: out std_logic;
		ci_result_in	: in  std_logic_vector(31 downto 0);
		ci_done_in		: in 	std_logic
			
	);
	end component; 
	
	signal internal_eql 				: std_logic;
	signal internal_en_reg 			: std_logic;
	signal internal_en_counter 	: std_logic;
	signal internal_clear_data 	: std_logic;
	signal internal_reset			: std_logic; -- considers bove, external and uc, resets
	signal internal_en_output		: std_logic;
	signal ineternal_en_reg_delay : std_logic;
	
	begin
	
		DEVICE_UNIDADE_CONTROLE_DEFASADOR : unidade_de_controle_defasador 
		port map(
			clock 		=> clock,
			reset			=> reset,
			
			ci_start		=> ci_start_in,
			user_start	=> us_go,
			eql			=> internal_eql,
			en_reg_ci	=> internal_en_reg,
			en_reg_dly	=> ineternal_en_reg_delay,
			en_counter	=> internal_en_counter,
			en_output	=> internal_en_output,
			clear_data	=> internal_clear_data
		); 

		DEVICE_FLUXO_DE_DADOS_DEFASADOR : fluxo_de_dados_defasador 
		port map (
			clock 			=> clock,
			reset				=> internal_reset,
			
			en_reg_ci		=> internal_en_reg,
			en_reg_delay	=> ineternal_en_reg_delay,
			en_counter		=> internal_en_counter,
			en_output		=> internal_en_output,
			delay_in			=> us_delay,
			eql				=> internal_eql,
			
			-- custom instruction slave bus --
			ci_dataa_in		=> ci_dataa_in,
			ci_datab_in		=> ci_datab_in,
			ci_n_in			=> ci_n_in,
			ci_start_in 	=> ci_start_in,
			ci_result_out	=> ci_result_out,
			ci_done_out		=> ci_done_out,
			
			-- custom instruction master bus --
			ci_dataa_out	=> ci_dataa_out,
			ci_datab_out	=> ci_datab_out,
			ci_n_out			=> ci_n_out,
			ci_start_out 	=> ci_start_out,
			ci_result_in	=> ci_result_in,
			ci_done_in		=> ci_done_in
			
		);
	
		internal_reset <= internal_clear_data or reset;
	
end architecture;
	

	
	