
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity instruction_selector is
generic(
	AddressSize : integer := 9;
	dataSize		: integer := 31;
	byteenSize	: integer := 3
);
port(
	
	clock 			: in  std_logic;
	 
	reset				: in  std_logic := '0'; 									-- force all registers states to zero 
	sel				: in  std_logic := '0';										-- enable register to write the inputs 
			
	DAddress			: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input
	Dread				: in  std_logic := '0';										-- Avalon MM read input
	Dchipselect		: in  std_logic := '0';										-- Avalon MM chipselect input
	Dreset_n			: in  std_logic := '1';										-- Avalon MM reset_n input
	Dclk_en			: in  std_logic := '0';										-- Avalon MM clk_en input
	Dbyteen			: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input
	
	Dreaddata		: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
	Dreaddata_valid: in  std_logic;												-- Avalon MM readdata_valid (from memory)input
	
	QAddress			: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output
	Qread				: out std_logic := '0';										-- Avalon MM read output
	Qchipselect		: out std_logic := '0';										-- Avalon MM chipselect output
	Qreset_n			: out std_logic := '1';										-- Avalon MM reset_n output
	Qclk_en			: out std_logic := '0';										-- Avalon MM clk_en output
	Qbyteen			: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output
	
	Qreaddata		: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output
	Qreaddata_valid: out std_logic												-- Avalon MM readdata_valid (to master) output
			
);
end entity;


architecture behavior of instruction_selector is

	signal internal_Address			 : std_logic_Vector(AddressSize downto 0);
	signal internal_read	 			 : std_logic_vector(0 downto 0);
	signal internal_chipselect		 : std_logic_vector(0 downto 0);
	signal internal_reset_n 		 : std_logic_vector(0 downto 0);
	signal internal_clk_en			 : std_logic_vector(0 downto 0);
	signal internal_byteen 			 : std_logic_vector(byteenSize downto 0);
	
	signal internal_readdata		 : std_logic_Vector(dataSize downto 0);			
	signal internal_readdata_valid : std_logic;																	

	begin 
		
	QAddress 			<= DAddress  when sel = '1' else (others => '0');
	Qread 				<= Dread 			 and sel;
	Qchipselect 		<= Dchipselect 	 and sel;
	Qreset_n 			<= Dreset_n  when sel = '1' else '1';
	Qclk_en 				<= Dclk_en 			 and sel;
	Qbyteen 				<= Dbyteen 	 when sel = '1' else (others => '0');
	Qreaddata 			<= Dreaddata when sel = '1' else (others => '0');
	Qreaddata_valid 	<= Dreaddata_valid and sel;
	
end architecture;
	

