

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity register_file_access_controller is
generic(
	dataSize							: integer := 31;
	AddressSize						: integer := 9
);
port(
	--------------------------------------------------------------
	-- SYSTEM SIGNALS														   --
	--------------------------------------------------------------
	clock 							: in  std_logic;
	reset								: in  std_logic;
	enable 						   : in  std_logic;
	--------------------------------------------------------------
	--------------------------------------------------------------
	-- AVALON MEMORY MAPPED SLAVE BUS 								   --
	--------------------------------------------------------------
	avs_master_writedata			: in  std_logic_vector(dataSize downto 0);
	avs_master_address			: in  std_logic_vector(AddressSize  downto 0);
	avs_master_read				: in  std_logic;
	avs_master_write				: in  std_logic;
	avs_master_chipselect		: in  std_logic;
	--------------------------------------------------------------
	-- ACQUIRED SIGNALS 														--
	--------------------------------------------------------------
	master_writedata				: out std_logic_vector(dataSize downto 0);
	master_address					: out std_logic_vector(AddressSize  downto 0);
	master_read						: out std_logic;
	master_write					: out std_logic;
	master_chipselect				: out std_logic;
	--------------------------------------------------------------
	--------------------------------------------------------------
	-- TEST AND SET SIGNALS												   --
	--------------------------------------------------------------
	tas_lock			   			: in  std_logic;
	--------------------------------------------------------------
	-- ACQUIRED SIGNALS 														--
	--------------------------------------------------------------
	lock				   			: out std_logic
); 
end entity;



architecture behavior of register_file_access_controller is

	
	component registrador_access_controller is
		generic(
			dataSize : natural := 31
		);
		port(
			clock 	: in  std_logic;
			clear 	: in  std_logic;
			enable	: in  std_logic;
			D			: in  std_logic_vector(dataSize downto 0);
			Q 			: out std_logic_vector(dataSize downto 0)
		); 
	end component registrador_access_controller;
	
	signal internal_avs_master_read  		: std_logic_vector(0 downto 0);
	signal internal_avs_master_write       : std_logic_vector(0 downto 0); 
	signal internal_avs_master_chipselect  : std_logic_vector(0 downto 0);
	signal internal_tas_lock					: std_logic_vector(0 downto 0);
	
	signal internal_master_read  				: std_logic_vector(0 downto 0);
	signal internal_master_write       		: std_logic_vector(0 downto 0); 
	signal internal_master_chipselect  		: std_logic_vector(0 downto 0);
	signal internal_lock							: std_logic_vector(0 downto 0);
	
	begin 

		DEVICE_AVS_MASTER_WRITEDATA : registrador_access_controller 
		generic map(
			dataSize => dataSize
		)
		port map(
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> avs_master_writedata,
			Q 			=> master_writedata
		); 

		DEVICE_AVS_MASTER_ADDRESS : registrador_access_controller 
		generic map(
			dataSize => AddressSize
		)
		port map(
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> avs_master_address,
			Q 			=> master_address
		); 

		DEVICE_AVS_MASTER_READ : registrador_access_controller 
		generic map(
			dataSize => 0
		)
		port map(
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> internal_avs_master_read,
			Q 			=> internal_master_read
		); 

		DEVICE_AVS_MASTER_WRITE : registrador_access_controller 
		generic map(
			dataSize => 0
		)
		port map(
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> internal_avs_master_write,
			Q 			=> internal_master_write
		); 
		
		DEVICE_AVS_MASTER_CHIPSELECT : registrador_access_controller 
		generic map(
			dataSize => 0
		)
		port map(
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> internal_avs_master_chipselect,
			Q 			=> internal_master_chipselect
		); 
		
		DEVICE_TAS_LOCK : registrador_access_controller 
		generic map(
			dataSize => 0
		)
		port map(
			clock 	=> clock,
			clear 	=> reset,
			enable	=> enable,
			D			=> internal_tas_lock,
			Q 			=> internal_lock
		); 
		
		internal_avs_master_read(0)  		 <= avs_master_read;
		internal_avs_master_write(0) 		 <= avs_master_write;
		internal_avs_master_chipselect(0) <= avs_master_chipselect;
		internal_tas_lock(0)					 <= tas_lock;
		
		master_read							 	 <= internal_master_read(0);	
		master_write						 	 <= internal_master_write(0);
		master_chipselect		 			 	 <= internal_master_chipselect(0);
		lock									 	 <= internal_lock(0);
		
end architecture;

		







