
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity timer is
generic(
	COUNTING_LIMIT : integer := 8
);
port(
	clock 	: in  std_logic;
	clear 	: in  std_logic;
	enable	: in  std_logic;
	Q 			: out std_logic
); 
end entity timer;


architecture behavior of timer is

	signal internal : std_logic_vector(7 downto 0) := (others => '0');
	
	begin 
	
		process(clock)
		begin 
			
			if clock'event and clock = '1' then
				if clear = '1' then
					internal <= (others => '0');
				else
					if enable = '1' then 
						if unsigned(internal) < COUNTING_LIMIT then
							internal <= std_logic_vector(unsigned(internal) + 1);
						end if;
					end if;
				end if;
			end if;
		end process;
			
		Q <=  '1' when unsigned(internal) = COUNTING_LIMIT else '0';
			
end architecture behavior;