
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity fluxo_de_dados_defasador is
port(
	
	clock 			: in  std_logic;
	reset				: in  std_logic;
	
	en_reg_ci		: in  std_logic;
	en_reg_delay	: in  std_logic;
	en_counter		: in  std_logic;
	en_output		: in  std_logic; 
	delay_in			: in  std_logic_vector(3  downto 0);
	eql				: out std_logic;
	
	-- custom instruction slave bus --
	ci_dataa_in		: in  std_logic_vector(31 downto 0);
	ci_datab_in		: in  std_logic_vector(31 downto 0);
	ci_n_in			: in  std_logic_vector(4  downto 0);
	ci_start_in 	: in  std_logic;
	ci_result_out	: out std_logic_vector(31 downto 0);
	ci_done_out		: out	std_logic; 
	
	-- custom instruction master bus --
	ci_dataa_out	: out std_logic_vector(31 downto 0);
	ci_datab_out	: out std_logic_vector(31 downto 0);
	ci_n_out			: out std_logic_vector(4  downto 0);
	ci_start_out 	: out std_logic;
	ci_result_in	: in  std_logic_vector(31 downto 0);
	ci_done_in		: in 	std_logic
	
);
end entity; 


architecture behavior of fluxo_de_dados_defasador is
	
	component register_file_defasador is
	port(
		
		clock 			: in  std_logic;
		
		reset				: in  std_logic := '0'; 
		enable_ci		: in  std_logic := '0';
		enable_delay	: in  std_logic := '0';
		
		d_delay			: in  std_logic_vector(3  downto 0);
		d_dataa			: in  std_logic_Vector(31 downto 0);
		d_datab			: in  std_logic_vector(31 downto 0);
		d_n				: in  std_logic_vector(4  downto 0);
		d_start			: in  std_logic := '0';
		
		q_delay			: out std_logic_vector(3  downto 0);
		q_dataa			: out std_logic_Vector(31 downto 0);
		q_datab			: out std_logic_vector(31 downto 0);
		q_n				: out std_logic_vector(4  downto 0);
		q_start			: out std_logic := '0'
		
	); 
	end component;
	
	component comparador_4bits is
	generic(
		dataSize	: integer := 4
	);
	port(
		dataa		: in  std_logic_vector(dataSize downto 0);
		datab		: in  std_logic_vector(dataSize downto 0);
		res		: out std_logic
	); 
	end component;
	
	component contador_defasador is
	generic(
		dataSize	: integer := 4
	);
	port(
		clock 	: in  std_logic;
		reset		: in  std_logic;
		enable	: in  std_logic;
		Q			: out std_logic_vector(dataSize downto 0)
	);
	end component;
	
	signal internal_counter : std_logic_vector(3  downto 0) := (others => '0');
	signal internal_dataa	: std_logic_vector(31 downto 0);
	signal internal_datab	: std_logic_vector(31 downto 0);		
	signal internal_delay	: std_logic_vector(3  downto 0);
	signal internal_n			: std_logic_vector( 4 downto 0);
	signal internal_start	: std_logic;
	
	begin 
	
		DEVICE_REGISTER_FILE_DEFASADOR : register_file_defasador port map(
			
			clock 			=> clock,
			
			reset				=> reset,
			enable_ci		=> en_reg_ci,
			enable_delay	=> en_reg_delay,
			
			d_delay			=> delay_in,
			d_dataa			=> ci_dataa_in,
			d_datab			=> ci_datab_in,
			d_n				=> ci_n_in,
			d_start			=> ci_start_in,
			
			q_delay			=> internal_delay,
			q_dataa			=> internal_dataa,
			q_datab			=> internal_datab,
			q_n				=> internal_n,
			q_start			=> internal_start
			
		); 
		
		DEVICE_CONTADOR_DEFASADOR : contador_defasador	
		generic map(
			dataSize	=> 3
		)
		port map(
			clock 	=> clock,
			reset		=> reset,
			enable	=> en_counter,
			Q			=> internal_counter
		);
		
		DEVICE_COMPARADOR : comparador_4bits
		generic map(
			dataSize	=> 3
		)
		port map(
			dataa		=> internal_delay,
			datab		=> internal_counter,
			res		=> eql
		); 
		
		ci_dataa_out	<= internal_dataa when en_output = '1' else (others => '0');
		ci_datab_out	<= internal_datab when en_output = '1' else (others => '0');
		ci_n_out			<= internal_n		when en_output = '1' else (others => '0');
		ci_start_out 	<= internal_start when en_output = '1' else '0';
		
		ci_result_out	<=	ci_result_in;
		ci_done_out		<=	ci_done_in;
		
end architecture;
		
		

