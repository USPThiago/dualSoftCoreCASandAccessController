
library ieee;
use	  ieee.std_logic_1164.all;
use	  ieee.numeric_std.all;


entity fluxo_de_dados_access_controller is
generic(
	dataSize				: integer := 31;
	AddressSize			: integer := 9
);
port(
	clock					: in  std_logic;
	reset					: in  std_logic;
	
	-- uc signals					     --
	en_custom_regfile 	: in  std_logic;		-- enable communication with uP 
	en_avm_regfile			: in  std_logic;		-- enable communication with shared resource
	en_mutex					: in  std_logic;
	reset_custom_regfile : in  std_logic;		-- clear last transation 
	reset_avm_regfile		: in  std_logic;		-- clear last transation 
	Uc_lock					: in  std_logic;		-- acquire mutex
	
	read						: out std_logic;
	
	-- free logic componente communication --
	new_address 		 : out std_logic_vector(AddressSize  downto 0);
	mutex_address		 : out std_logic_vector(AddressSize  downto 0);
	mutex_locked	 	 : out std_logic;
	
	-- uP communication signals     --
	avs_address   		: in  std_logic_vector(AddressSize  downto 0) := (others => '0');           
	avs_chipselect		: in  std_logic                     := '0';
	avs_read      		: in  std_logic                     := '0'; 	
	avs_write     		: in  std_logic                     := '0';             
	avs_writedata 		: in  std_logic_vector(dataSize	 downto 0) := (others => '0');
	
	avs_readdata		: out std_logic_vector(dataSize	 downto 0) := (others => '0');
	
	tas_lock				: in  std_logic; 
	tas_unlock			: in  std_logic;
	
	-- Memory communication signals --
	avm_readdata  		: in  std_logic_vector(dataSize	 downto 0);									-- data received from memory
		
	avm_address    	: out std_logic_vector(AddressSize  downto 0) := (others => '0');  	-- especify one position of memory
	avm_clken     		: out std_logic                     := '0';              
	avm_chipselect 	: out std_logic                     := '0';              				-- enable componente to work
	avm_read				: out std_logic							:= '0';
	avm_write      	: out std_logic                     := '0';              				-- enable a write operation
	avm_writedata  	: out std_logic_vector(dataSize	 downto 0) := (others => '0');  		-- data to be store in memory 
	avm_byteenable 	: out std_logic_vector(3 downto 0) := (others => '0'); 		                   
	avm_reset_reset_n : out std_logic      				   := '1' 									-- reset RAM component. Active in low
	
	-- db signals 						  --
); 
end entity;


architecture behavior of fluxo_de_dados_access_controller is

	component register_file_access_controller is
	port(
		--------------------------------------------------------------
		-- SYSTEM SIGNALS														   --
		--------------------------------------------------------------
		clock 							: in  std_logic;
		reset								: in  std_logic;
		enable 						   : in  std_logic;
		--------------------------------------------------------------
		--------------------------------------------------------------
		-- AVALON MEMORY MAPPED SLAVE BUS 								   --
		--------------------------------------------------------------
		avs_master_writedata			: in  std_logic_vector(dataSize 		downto 0);
		avs_master_address			: in  std_logic_vector(AddressSize  downto 0);
		avs_master_read				: in  std_logic;
		avs_master_write				: in  std_logic;
		avs_master_chipselect		: in  std_logic;
		--------------------------------------------------------------
		-- ACQUIRED SIGNALS 														--
		--------------------------------------------------------------
		master_writedata				: out std_logic_vector(dataSize 		downto 0);
		master_address					: out std_logic_vector(AddressSize  downto 0);
		master_read						: out std_logic;
		master_write					: out std_logic;
		master_chipselect				: out std_logic;
		--------------------------------------------------------------
		--------------------------------------------------------------
		-- TEST AND SET SIGNALS												   --
		--------------------------------------------------------------
		tas_lock			   			: in  std_logic;
		--------------------------------------------------------------
		-- ACQUIRED SIGNALS 														--
		--------------------------------------------------------------
		lock				   			: out std_logic
	); 
	end component;


	component mutex is 
	generic(
		dataSize		  : integer := 9
	);
	port(
		--------------------------------------------------------------
		-- SYSTEM SIGNALS														   --
		--------------------------------------------------------------
		clock   		  : in  std_logic;
		reset	  		  : in  std_logic;
		enable  		  : in  std_logic;
		--------------------------------------------------------------
		--------------------------------------------------------------
		-- DATA SIGNALS															--
		--------------------------------------------------------------
		address 		  : in  std_logic_vector(dataSize  downto 0);
		tas_lock		  : in  std_logic := '0';
		tas_unlock    : in  std_logic := '0';
		uc_lock		  : in  std_logic := '0';	
		--------------------------------------------------------------
		mutex_address : out std_logic_vector(dataSize  downto 0);
		mutex_locked  : out std_logic
		--------------------------------------------------------------
	);
	end component;

	signal internal_writedata	: std_logic_vector(dataSize 		downto 0);
	signal internal_address		: std_logic_vector(AddressSize 	downto 0);
	signal internal_read			: std_logic;
	signal internal_write		: std_logic;
	
	signal internal_lock			: std_logic;
	
	begin
	
		-- uP communication register file instantiation --
		SLAVE_REGISTER_FILE : register_file_access_controller	port map(
			--------------------------------------------------------------
			-- uc signals															   --
			--------------------------------------------------------------
			clock 						=> clock,	
			reset							=> reset_custom_regfile,	
			enable 						=> en_custom_regfile,  
			--------------------------------------------------------------
			--------------------------------------------------------------
			-- INPUT SIGNALS														   --
			--------------------------------------------------------------
			avs_master_writedata		=> avs_writedata,	
			avs_master_address		=> avs_address,	
			avs_master_read			=> avs_read,	
			avs_master_write			=> avs_write,	
			avs_master_chipselect	=> avs_chipselect,	
			--------------------------------------------------------------
			-- OUTPUT SIGNALS	 														--
			--------------------------------------------------------------
			master_writedata			=> internal_writedata,	
			master_address				=> internal_address,	
			master_read					=> internal_read,	
			master_write				=> internal_write,	
			master_chipselect			=> open,	
			--------------------------------------------------------------
			--------------------------------------------------------------
			-- TEST AND SET SIGNALS												   --
			--------------------------------------------------------------
			tas_lock			   		=> tas_lock,	
			--------------------------------------------------------------
			-- ACQUIRED SIGNALS 														--
			--------------------------------------------------------------
			lock				   		=> internal_lock	
		);
	
		-- memory communication register file instantiation --
		MASTER_REGISTER_FILE : register_file_access_controller port map(
			--------------------------------------------------------------
			-- uc signals															   --
			--------------------------------------------------------------
			clock 						=> clock,	
			reset							=> reset_avm_regfile,	
			enable 						=> en_avm_regfile,   
			--------------------------------------------------------------
			--------------------------------------------------------------
			-- AVALON MEMORY MAPPED SLAVE BUS 								   --
			--------------------------------------------------------------
			avs_master_writedata		=> internal_writedata,	
			avs_master_address		=> internal_address,	
			avs_master_read			=> internal_read,	
			avs_master_write			=> internal_write,	
			avs_master_chipselect	=> '1',	
			--------------------------------------------------------------
			-- ACQUIRED SIGNALS 														--
			--------------------------------------------------------------
			master_writedata			=> avm_writedata,	
			master_address				=> avm_address,	
			master_read					=> avm_read,	
			master_write				=> avm_write,	
			master_chipselect			=> avm_chipselect,	
			--------------------------------------------------------------
			--------------------------------------------------------------
			-- TEST AND SET SIGNALS												   --
			--------------------------------------------------------------
			tas_lock			   		=> '0',	
			--------------------------------------------------------------
			-- ACQUIRED SIGNALS 														--
			--------------------------------------------------------------
			lock				   		=> open	
		);
		
		DEVICE_MUTEX : mutex generic map(
			dataSize		 => AddressSize
		)
		port map(
			--------------------------------------------------------------
			-- SYSTEM SIGNALS														   --
			--------------------------------------------------------------
			clock   		  => clock,
			reset	  		  => reset,
			enable  		  => en_mutex,
			--------------------------------------------------------------
			--------------------------------------------------------------
			-- DATA SIGNALS															--
			--------------------------------------------------------------
			address 		  => internal_address,
			tas_lock		  => internal_lock,
			tas_unlock    => tas_unlock,
			uc_lock		  => Uc_lock,
			--------------------------------------------------------------
			mutex_address => mutex_address,
			mutex_locked  => mutex_locked
			--------------------------------------------------------------
		);
		
		avs_readdata	<= avm_readdata;
		new_address		<= internal_address;
		read				<= avs_read or internal_read;
		
		avm_clken		<= '1';
		avm_byteenable	<= (others=> '1');
		
end architecture;
	

