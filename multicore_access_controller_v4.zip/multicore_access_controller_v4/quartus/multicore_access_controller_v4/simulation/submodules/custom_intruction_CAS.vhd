
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity Compare_and_Swap is
port(	
	-- System inputs 			  --
	clock 		: in  std_logic;
	reset			: in  std_logic;
	----------------------------
	-- Avalon MM master bus 									 			 --
	avm_master_address			: out std_logic_vector(31 downto 0);
	avm_master_read				: out std_logic;
	avm_master_write				: out std_logic;
	avm_master_chipselect		: out std_logic;
	avm_master_waitrequest		: in  std_logic;
	avm_master_readdata_valid	: in	std_logic;
	avm_master_readdata			: in  std_logic_vector(31 downto 0);
	avm_master_writedata			: out std_logic_vector(31 downto 0);
	---------------------------------------------------------------
	-- Avalon MM slave bus 													 --
	avs_slave_address			   : in  std_logic_vector(1  downto 0);
	avs_slave_chipselect			: in 	std_logic;
	avs_slave_write				: in  std_logic;
	avs_slave_writedata			: in  std_logic_vector(31 downto 0);
	---------------------------------------------------------------
	-- Custom intruction slave 													 --
	custom_instruction_clock			: in  std_logic;
	custom_instruction_start			: in  std_logic;
	custom_instruction_done				: out std_logic;
	custom_instruction_address			: in  std_logic_vector(31 downto 0);
	custom_instruction_expecteddata	: in  std_logic_vector(31 downto 0);
	custom_instruction_newdata_index	: in  std_logic_vector(4  downto 0);
	custom_instruction_result			: out std_logic_vector(31 downto 0);
	---------------------------------------------------------------------
	-- test-and-set signals 		  --
	tas_lock			   : out std_logic;
	tas_locked			: in  std_logic;
	tas_unlock			: out std_logic;
	----------------------------------
	-- mem slave selection key 	  --
	sel_key				: out std_logic;
	----------------------------------
	-- Debug signals 					  --				 		  				-- 
	deb_state						: out std_logic_vector(2  downto 0);
	deb_expecteddata		   	: out std_logic_vector(31 downto 0);
	deb_avm_master_readdata 	: out std_logic_vector(31 downto 0);
	
	db_reset							: in  std_logic;
	db_start_output				: out std_logic;
	db_done_output					: out std_logic;
	db_address_output				: out std_logic_vector(31 downto 0);
	db_expecteddata_output		: out std_logic_vector(31 downto 0);
	db_newdata_index_output		: out std_logic_vector(7  downto 0)
	
	--------------------------------------------------------------
);
end entity Compare_and_Swap;
	
	
architecture custom_instruction_pipeline of Compare_and_Swap is
	
	component Unidade_de_Controle_CAS is
	port(	
		-- System signals 			     --
		clock 				: in  std_logic;
		start					: in  std_logic;
		reset					: in  std_logic;
		enable_registers	: out std_logic;
		enable_load_data	: out std_logic;
		set_result			: out std_logic;
		done 					: out std_logic;
		----------------------------------
		-- Avalon Master signals 	     --
		readdata_valid		: in	std_logic;
		read					: out std_logic;
		write					: out std_logic;
		chipselect			: out std_logic;
		----------------------------------
		-- Compare Signal				     -- 
		equal					: in  std_logic;
		----------------------------------
		-- Internal Timer signals 	  	  --
		timer_done			: in  std_logic;
		timer_reset			: out std_logic;
		timer_enable		: out std_logic;
		----------------------------------
		-- Test-and-Set signals 	  	  --
		tas_locked			: in  std_logic;
		tas_lock				: out std_logic; 
		tas_unlock			: out std_logic;
		----------------------------------
		-- processing signal				  --
		processing			: out std_logic;
		----------------------------------
		-- Debug signals 					  				 		  -- 
		deb_state			: out std_logic_vector(2 downto 0)
		----------------------------------------------------
	);	
	end component Unidade_de_Controle_CAS;
	
	component Fluxo_de_Dados_CAS is
	port(
		-- System inputs			  				  -- 
		clock 						: in  std_logic;
		start							: in  std_logic;
		reset							: in  std_logic;
		enable_registers			: in  std_logic;
		enable_load_data			: in  std_logic;
		set_result					: in 	std_logic;
		----------------------------------------
		-- Custom intruction slave 							 			 --
		address						: in  std_logic_vector(31 downto 0);
		expecteddata				: in  std_logic_vector(31 downto 0);
		newdata_index				: in  std_logic_vector(7  downto 0);
		result						: out std_logic_vector(31 downto 0);
		------------------------------------------------------------
		-- Internal Timer signals 	  	  		  --
		timer_done					: out std_logic;
		timer_reset					: in  std_logic;
		timer_enable				: in  std_logic;
		----------------------------------------
		-- Compare Signal				    		  -- 
		equal							: out std_logic;
		----------------------------------------
		-- Test-and-Set signals 	  	  		  --
		tas_locked					: in  std_logic;
		tas_unlock_IDLE			: out std_logic; 
		----------------------------------------
		-- Avalon MM master bus 									 		 --
		avm_master_address		: out std_logic_vector(31 downto 0);
		avm_master_readdata		: in  std_logic_vector(31 downto 0);
		avm_master_writedata		: out std_logic_vector(31 downto 0);
		------------------------------------------------------------
		-- Register File bus													 -- 
		avs_slave_address			: in  std_logic_vector(31 downto 0);
		avs_slave_chipselect		: in 	std_logic;
		avs_slave_write			: in  std_logic;
		avs_slave_writedata		: in  std_logic_vector(31 downto 0);
		------------------------------------------------------------
		-- Debug signals 					  				 		  			 -- 
		deb_expecteddata		   : out std_logic_vector(31 downto 0);
		deb_avm_master_readdata : out std_logic_vector(31 downto 0)
		------------------------------------------------------------
	); 
	end component Fluxo_de_dados_CAS;
	
	component db_custom_instruction_master is
	port(
		-- system signals --
		clock 						: in  std_logic; 
		reset 						: in  std_logic;
		
		-- Nios inputs --
		db_start_input				: in  std_logic;
		db_done_input				: in  std_logic;
		db_address_input			: in  std_logic_vector(31 downto 0);
		db_expecteddata_input	: in  std_logic_vector(31 downto 0);
		db_newdata_index_input	: in  std_logic_vector(7  downto 0);
		
		-- Nios outputs --
		db_start_output			: out  std_logic;
		db_done_output				: out  std_logic;
		db_address_output			: out  std_logic_vector(31 downto 0);
		db_expecteddata_output	: out  std_logic_vector(31 downto 0);
		db_newdata_index_output	: out  std_logic_vector(7  downto 0)
		
	); 
	end component;
	
	signal top_level_en_regs		: std_logic;
	signal top_level_en_load_data	: std_logic;
	signal top_level_set_result	: std_logic;
	signal top_level_result			: std_logic_vector(31 downto 0);
	signal top_level_done			: std_logic;
	
	signal top_level_timer_done 	: std_logic;
	signal top_level_timer_enable : std_logic;
	signal top_level_timer_clear 	: std_logic;
	
	signal top_level_write			: std_logic;
	signal top_level_read			: std_logic;
	signal top_level_chipselect	: std_logic;
	
	signal top_leval_equal			: std_logic;
	
	signal top_level_lock			: std_logic;
	signal top_level_unlock			: std_logic;
	signal top_level_unlock_IDLE  : std_logic;
	
	signal top_level_state			: std_logic_vector(2 downto 0);
	signal internal_avs_slave_address : std_logic_vector(31 downto 0);
	
	begin 
	
		CONTROLER_UNIT : Unidade_de_Controle_CAS port map (	
			-- System signals 			     --
			clock 				=> clock,
			start					=> custom_instruction_start,
			reset					=> reset,
			enable_registers	=> top_level_en_regs,
			enable_load_data	=> top_level_en_load_data,
			set_result			=> top_level_set_result,
			done 					=> top_level_done,
			----------------------------------
			-- Avalon Master signals 	     --
			readdata_valid		=> avm_master_readdata_valid,
			read					=> top_level_read,
			write					=> top_level_write,
			chipselect			=> top_level_chipselect,
			----------------------------------
			-- Compare Signal				     -- 
			equal					=> top_leval_equal,
			----------------------------------
			-- Internal Timer signals 	  	  --
			timer_done			=> top_level_timer_done,
			timer_reset			=> top_level_timer_clear,
			timer_enable		=> top_level_timer_enable,
			----------------------------------
			-- Test-and-Set signals 	  	  --
			tas_locked			=> tas_locked,
			tas_lock				=> top_level_lock,
			tas_unlock			=> top_level_unlock,
			----------------------------------
			processing			=> sel_key,
			deb_state			=> top_level_state
		);	
	
		DATA_PATH : Fluxo_de_Dados_CAS	port map (
			-- System inputs			  				  -- 
			clock 					=> clock,		
			start						=> custom_instruction_start,		
			reset						=> reset,		
			enable_registers		=> top_level_en_regs,		
			enable_load_data		=> top_level_en_load_data,		
			set_result				=> top_level_set_result,		
			----------------------------------------
			-- Custom intruction slave 							 			 --
			address					=> custom_instruction_address,	
			expecteddata			=> custom_instruction_expecteddata,		
			newdata_index			=> (others => '0'),		
			result					=> top_level_result,		
			------------------------------------------------------------
			-- Internal Timer signals 	  	  		  --
			timer_done				=> top_level_timer_done,		
			timer_reset				=> top_level_timer_clear,		
			timer_enable			=> top_level_timer_enable,		
			----------------------------------------
			-- Compare Signal				    		  -- 
			equal						=> top_leval_equal,		
			----------------------------------------
			-- Test-and-Set signals 	  	  		  --
			tas_locked				=> tas_locked,		
			tas_unlock_IDLE		=> top_level_unlock_IDLE,		 
			----------------------------------------
			-- Avalon MM master bus 									 		 --
			avm_master_address	=> avm_master_address,	
			avm_master_readdata	=> avm_master_readdata,	
			avm_master_writedata	=> avm_master_writedata,	
			------------------------------------------------------------
			-- Register File bus													 -- 
			avs_slave_address		=> internal_avs_slave_address,	
			avs_slave_chipselect	=> avs_slave_chipselect,	
			avs_slave_write		=> avs_slave_write,	
			avs_slave_writedata	=> avs_slave_writedata,	
			------------------------------------------------------------
			-- Debug signals 					  				 		  			 -- 
			deb_expecteddata		   => deb_expecteddata,
			deb_avm_master_readdata => deb_avm_master_readdata
			------------------------------------------------------------
		); 
		
		DEVICE_DB_FILE : db_custom_instruction_master port map (
			-- system signals --
			clock 						=> clock,
			reset 						=> db_reset,
			
			-- Nios inputs --
			db_start_input				=> custom_instruction_start,
			db_done_input				=> top_level_done,
			db_address_input			=> custom_instruction_address,
			db_expecteddata_input	=> custom_instruction_expecteddata,
			db_newdata_index_input	=> (others => '0'),
			
			-- Nios outputs --
			db_start_output			=> db_start_output,
			db_done_output				=> db_done_output,
			db_address_output			=> db_address_output,
			db_expecteddata_output	=> db_expecteddata_output,
			db_newdata_index_output	=> db_newdata_index_output
			
		); 
		
		-- Saidas Barramento Avalon MM master 			    --
		avm_master_read				<= top_level_read;
		avm_master_write				<= top_level_write;
		avm_master_chipselect		<= top_level_chipselect;
		---------------------------------------------------
		-- Custom Instruction Slave outputs			   --
		custom_instruction_done 	<= top_level_done;
		custom_instruction_result 	<= top_level_result;
		-----------------------------------------------
		-- Test-and-Set Bus																		--
		tas_lock						   <= top_level_lock;
		tas_unlock						<= top_level_unlock and top_level_unlock_IDLE;
		-------------------------------------------------------------------------
		-- debugger signals								  --
		deb_state						<= top_level_state;
		----------------------------------------------
		
		internal_avs_slave_address(1 downto 0) <= avs_slave_address;
		
end architecture custom_instruction_pipeline;





	
	
	