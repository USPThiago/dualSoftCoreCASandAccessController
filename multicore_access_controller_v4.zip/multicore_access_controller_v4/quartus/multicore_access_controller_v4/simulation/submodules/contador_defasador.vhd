
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;


entity contador_defasador is
generic(
	dataSize	: integer := 4
);
port(
	clock 	: in  std_logic;
	reset		: in  std_logic;
	enable	: in  std_logic;
	Q			: out std_logic_vector(dataSize downto 0)
);
end entity;


architecture behavior of contador_defasador is

	signal internal_counter : std_logic_vector(dataSize downto 0);
	
	begin 
	
		process(clock)
		begin 
		
			if clock'event and clock = '1' then
				if reset = '1' then
					internal_counter <= (others => '0');
				elsif enable = '1' then 
					internal_counter <= std_logic_vector(unsigned(internal_counter) + 1);
				end if;
			end if;
		
		end process;
		
		Q <= internal_counter;
		
end architecture;