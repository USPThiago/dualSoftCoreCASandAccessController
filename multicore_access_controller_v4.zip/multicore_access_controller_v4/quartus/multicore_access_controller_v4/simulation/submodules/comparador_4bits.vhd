
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity comparador_4bits is
generic(
	dataSize	: integer := 4
);
port(
	dataa		: in  std_logic_vector(dataSize downto 0);
	datab		: in  std_logic_vector(dataSize downto 0);
	res		: out std_logic
); 
end entity;

architecture behavior of comparador_4bits is

	begin 
	
		res <= '1' when dataa = datab else '0';
		
end architecture;