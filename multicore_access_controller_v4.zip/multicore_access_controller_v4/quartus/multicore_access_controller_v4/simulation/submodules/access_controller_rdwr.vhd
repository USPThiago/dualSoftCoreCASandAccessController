
library ieee;
use 	  ieee.std_logic_1164.all;
use 	  ieee.numeric_std.all;

entity access_controller_rdwr is
generic(
	AddressSize 					: integer := 9;
	dataSize							: integer := 31;
	byteenSize						: integer := 3
);
port(
	
	clock 							: in  std_logic;
	reset 							: in  std_logic;
	
	-- control unit 		--
	
	compare_and_swap_address_0 : in  std_logic_vector(AddressSize downto 0);
	compare_and_swap_address_1 : in  std_logic_vector(AddressSize downto 0);
	compare_and_swap_locked_0	: in  std_logic;
	compare_and_swap_locked_1	: in  std_logic;
	
	load_locked_0					: out std_logic;												-- Access controller signal: Nios II 0					  --
	load_locked_1					: out std_logic;												-- Access controller signal: Nios II 1					  --
	
	-- Data Path signals --
	
	DAddress_0						: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 0
	Dwrite_0							: in  std_logic := '0';										-- Avalon MM read input 								Nios II 0
	Dchipselect_0					: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 0
	Dreset_n_0						: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 0
	Dclk_en_0						: in  std_logic := '0';										-- Avalon MM clk_en input 								Nios II 0
	Dbyteen_0						: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 0
	
	Dreaddata_0						: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
	
	QAddress_0						: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 0
	Qwrite_0							: out std_logic := '0';										-- Avalon MM read output 								Nios II 0
	Qchipselect_0					: out std_logic := '0';										-- Avalon MM chipselect output 						Nios II 0
	Qreset_n_0						: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 0
	Qclk_en_0						: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 0
	Qbyteen_0						: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output 							Nios II 0
	
	Qreaddata_0						: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 0
	Qreaddata_valid_0				: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 0
	
	addressAquired_0 				: out std_logic_vector(AddressSize downto 0);
	
	DAddress_1						: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 1
	Dwrite_1							: in  std_logic := '0';										-- Avalon MM read input 								Nios II 1 
	Dchipselect_1					: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 1
	Dreset_n_1						: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 1
	Dclk_en_1						: in  std_logic := '0';											-- Avalon MM clk_en input 							Nios II 1
	Dbyteen_1						: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 1
	
	Dreaddata_1						: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
	
	QAddress_1						: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 1
	Qwrite_1							: out std_logic := '0';										-- Avalon MM read output 								Nios II 1
	Qchipselect_1					: out std_logic := '0';										-- Avalon MM chipselect outpuy 						Nios II 1
	Qreset_n_1						: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 1
	Qclk_en_1						: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 1
	Qbyteen_1						: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output 							Nios II 1
	
	Qreaddata_1						: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 1
	Qreaddata_valid_1				: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 1
	
	addressAquired_1 				: out std_logic_vector(AddressSize downto 0)
	
); 
end entity;


architecture behavior of access_controller_rdwr is

	component unidade_de_controle_access_controller_rdwr is
		generic(
		AddressSize 				: integer := 9;
		dataSize						: integer := 31;
		byteenSize					: integer := 3
	);
	port(
		
		clock 							: in  std_logic;
		reset 							: in  std_logic;
		
		chipselect_0					: in  std_logic;											-- Load Instruction 0        Nios II 0					  --
		chipselect_1					: in  std_logic;											-- Load Instruction 1		  Nios II 1					  --
		
		read_0							: in  std_logic;											-- Load Instruction 0        Nios II 0					  --
		read_1							: in  std_logic;											-- Load Instruction 1        Nios II 1					  --
		
		load_address_0 				: in  std_logic_vector(AddressSize downto 0);	-- Load Instruction 0        Nios II 0					  --
		load_address_1 				: in  std_logic_vector(AddressSize downto 0);	-- Load Instruction 1        Nios II 1					  --
		
		compare_and_swap_address_0 : in  std_logic_vector(AddressSize downto 0);	-- Access controller signal: Nios II 0					  --
		compare_and_swap_address_1 : in  std_logic_vector(AddressSize downto 0);	-- Access controller signal: Nios II 1					  --
		compare_and_swap_locked_0	: in  std_logic;											-- Access controller signal: Nios II 0					  --
		compare_and_swap_locked_1	: in  std_logic;											-- Access controller signal: Nios II 1					  --
		
		readdata_valid_0				: out std_logic;											-- access controller signal: Nios II 0					  --
		readdata_valid_1				: out std_logic;											-- access controller signal: Nios II 1					  --
		load_locked_0					: out std_logic;											-- Access controller signal: Nios II 0					  --
		load_locked_1					: out std_logic;											-- Access controller signal: Nios II 1					  --
		clear_0 							: out std_logic;											-- Control signal - Data Path access controlelr rdwr --  
		clear_1							: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 	
		enable_0 						: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 
		enable_1 						: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 
		select_0 						: out std_logic;											-- Control signal - Data Path access controlelr rdwr -- 
		select_1 						: out std_logic											-- Control signal - Data Path access controlelr rdwr -- 
		
	);
	end component;
	
	component fluxo_de_dados_access_controller_rdwr is
	generic(
		AddressSize : integer := 9;
		dataSize		: integer := 31;
		byteenSize	: integer := 3
	);
	port(
		
		clock					: in  std_logic;
		
		reset 				: in  std_logic;
		
		clear_0				: in  std_logic;												-- control inputs 										Nios II 0
		enable_0				: in  std_logic;												-- control inputs 										Nios II 0
		select_0				: in  std_logic;												-- control inputs 										Nios II 0

		DAddress_0			: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 0
		Dread_0				: in  std_logic := '0';										-- Avalon MM read input 								Nios II 0
		Dchipselect_0		: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 0
		Dreset_n_0			: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 0
		Dclk_en_0			: in  std_logic := '0';										-- Avalon MM clk_en input 								Nios II 0
		Dbyteen_0			: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 0
		
		Dreaddata_0			: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
		Dreaddata_valid_0	: in  std_logic;												-- Avalon MM readdata_valid (from memory)input
		
		QAddress_0			: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 0
		Qread_0				: out std_logic := '0';										-- Avalon MM read output 								Nios II 0
		Qchipselect_0		: out std_logic := '0';										-- Avalon MM chipselect output 						Nios II 0
		Qreset_n_0			: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 0
		Qclk_en_0			: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 0
		Qbyteen_0			: out std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen output 							Nios II 0
		
		Qreaddata_0			: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 0
		Qreaddata_valid_0	: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 0
		
		addressAquired_0 	: out std_logic_vector(AddressSize downto 0);
		
		clear_1				: in  std_logic;												-- control inputs 										Nios II 0
		enable_1				: in  std_logic;												-- control inputs 										Nios II 1
		select_1				: in  std_logic;												-- control inputs 										Nios II 1
		
		DAddress_1			: in  std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address input 							Nios II 1
		Dread_1				: in  std_logic := '0';										-- Avalon MM read input 								Nios II 1 
		Dchipselect_1		: in  std_logic := '0';										-- Avalon MM chipselect input 						Nios II 1
		Dreset_n_1			: in  std_logic := '1';										-- Avalon MM reset_n input 							Nios II 1
		Dclk_en_1			: in  std_logic := '0';											-- Avalon MM clk_en input 							Nios II 1
		Dbyteen_1			: in  std_logic_vector(byteenSize downto 0);			-- Avalon MM byteen input 								Nios II 1
		
		Dreaddata_1			: in  std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (from memory) input
		Dreaddata_valid_1	: in  std_logic;												-- Avalon MM readdata_valid (from memory)input
		
		QAddress_1			: out std_logic_Vector(AddressSize downto 0);		-- Avalon MM Address output 							Nios II 1
		Qread_1				: out std_logic := '0';										-- Avalon MM read output 								Nios II 1
		Qchipselect_1		: out std_logic := '0';										-- Avalon MM chipselect outpuy 						Nios II 1
		Qreset_n_1			: out std_logic := '1';										-- Avalon MM reset_n output 							Nios II 1
		Qclk_en_1			: out std_logic := '0';										-- Avalon MM clk_en output 							Nios II 1
		Qbyteen_1			: out std_logic_vector(byteenSize downto 0);		-- Avalon MM byteen output 							Nios II 1
		
		Qreaddata_1			: out std_logic_Vector(dataSize downto 0);			-- Avalon MM readdata (to master) output			Nios II 1
		Qreaddata_valid_1	: out std_logic;												-- Avalon MM readdata_valid (to master) output	Nios II 1
		
		addressAquired_1 	: out std_logic_vector(AddressSize downto 0)
		
	); 
	end component;

	signal internal_enable_0 			: std_logic := '0';
	signal internal_clear_0  			: std_logic := '0';
	signal internal_select_0 			: std_logic := '0';
	signal internal_enable_1 			: std_logic := '0';
	signal internal_clear_1  			: std_logic := '0';
	signal internal_select_1 			: std_logic := '0';
	signal internal_read_0				: std_logic := '0';
	signal internal_read_1 				: std_logic := '0';
	
	signal internal_qaddress_0 		: std_logic_vector(AddressSize downto 0);
	signal internal_qaddress_1 		: std_logic_vector(AddressSize downto 0);
	
	signal internal_readdata_valid_0 : std_logic := '0';
	signal internal_readdata_valid_1 : std_logic := '0';
	
	begin 
	
		DEVICE_UNIDADE_DE_CONTROLE_ACCESS_CONTROLLER_RDWR : unidade_de_controle_access_controller_rdwr
		generic map(
			AddressSize 					=> AddressSize,
			dataSize							=> dataSize,
			byteenSize						=> byteenSize
		)
		port map(
			
			clock 							=> clock,
			reset 							=> reset,
			
			chipselect_0					=> Dchipselect_0,
			chipselect_1					=> Dchipselect_1,
			
			read_0							=> Dwrite_0,
			read_1							=> Dwrite_1,
			
			load_address_0 				=> internal_qaddress_0,
			load_address_1 				=> internal_qaddress_1,
			
			compare_and_swap_address_0 => compare_and_swap_address_0,
			compare_and_swap_address_1 => compare_and_swap_address_1,
			compare_and_swap_locked_0	=> compare_and_swap_locked_0,
			compare_and_swap_locked_1	=> compare_and_swap_locked_1,
			
			readdata_valid_0				=> internal_readdata_valid_0,
			readdata_Valid_1				=> internal_readdata_valid_1,
			load_locked_0					=> load_locked_0,
			load_locked_1					=> load_locked_1,
			clear_0 							=> internal_clear_0,  
			clear_1							=> internal_clear_1, 	
			enable_0 						=> internal_enable_0, 
			enable_1 						=> internal_enable_1, 
			select_0 						=> internal_select_0, 
			select_1 						=> internal_select_1
			
		);
	
		DEVICE_FLUXO_DE_DADOS_ACCESS_CONTROLLER_RDWR : fluxo_de_dados_access_controller_rdwr 
		generic map(
			AddressSize 					=> AddressSize,
			dataSize							=> dataSize,
			byteenSize						=> byteenSize
		)
		port map(
			
			clock								=> clock,
			
			reset 							=> reset,
			
			clear_0							=> internal_clear_0,	
			enable_0							=> internal_enable_0,				
			select_0							=> internal_select_0,

			DAddress_0						=> DAddress_0,
			Dread_0							=> internal_read_0,
			Dchipselect_0					=> Dchipselect_0,
			Dreset_n_0						=> Dreset_n_0,
			Dclk_en_0						=> Dclk_en_0,
			Dbyteen_0						=> Dbyteen_0,
			
			Dreaddata_0						=> Dreaddata_0,
			Dreaddata_valid_0				=> internal_readdata_valid_0,
			
			QAddress_0						=> QAddress_0,
			Qread_0							=> Qwrite_0,
			Qchipselect_0					=> Qchipselect_0,
			Qreset_n_0						=> Qreset_n_0,
			Qclk_en_0						=> Qclk_en_0,
			Qbyteen_0						=> Qbyteen_0,
			
			Qreaddata_0						=> Qreaddata_0,
			Qreaddata_valid_0				=> Qreaddata_valid_0,
			
			addressAquired_0 				=> internal_qaddress_0,
			
			clear_1							=> internal_clear_1,
			enable_1							=> internal_enable_1,
			select_1							=> internal_select_1,
			
			DAddress_1						=> DAddress_1,
			Dread_1				 			=> internal_read_1,
			Dchipselect_1					=> Dchipselect_1,
			Dreset_n_1						=> Dreset_n_1,
			Dclk_en_1						=> Dclk_en_1,
			Dbyteen_1						=> Dbyteen_1,
			
			Dreaddata_1						=> Dreaddata_1,
			Dreaddata_valid_1				=> internal_readdata_valid_1,
			
			QAddress_1						=> QAddress_1,
			Qread_1							=> Qwrite_1,
			Qchipselect_1					=> Qchipselect_1,
			Qreset_n_1						=> Qreset_n_1,
			Qclk_en_1						=> Qclk_en_1,
			Qbyteen_1						=> Qbyteen_1,
						
			Qreaddata_1						=> Qreaddata_1,			
			Qreaddata_valid_1				=> Qreaddata_valid_1,
			
			addressAquired_1 				=> internal_qaddress_1
			
		); 
		
		internal_read_0  <= not Dwrite_0;
		internal_read_1  <= not Dwrite_1;
		
		addressAquired_0 <= internal_qaddress_0;
		addressAquired_1 <= internal_qaddress_1;
	
end architecture;




