
# (C) 2001-2026 Altera Corporation. All rights reserved.
# Your use of Altera Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Altera 
# Program License Subscription Agreement, Altera MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Altera and sold by Altera 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ACDS 20.1 720 win32 2026.10.28.17:09:37

# ----------------------------------------
# ncsim - auto-generated simulation script

# ----------------------------------------
# This script provides commands to simulate the following IP detected in
# your Quartus project:
#     multicore_access_controller_v4
# 
# Altera recommends that you source this Quartus-generated IP simulation
# script from your own customized top-level script, and avoid editing this
# generated script.
# 
# To write a top-level shell script that compiles Altera simulation libraries
# and the Quartus-generated IP in your project, along with your design and
# testbench files, copy the text from the TOP-LEVEL TEMPLATE section below
# into a new file, e.g. named "ncsim.sh", and modify text as directed.
# 
# You can also modify the simulation flow to suit your needs. Set the
# following variables to 1 to disable their corresponding processes:
# - SKIP_FILE_COPY: skip copying ROM/RAM initialization files
# - SKIP_DEV_COM: skip compiling the Quartus EDA simulation library
# - SKIP_COM: skip compiling Quartus-generated IP simulation files
# - SKIP_ELAB and SKIP_SIM: skip elaboration and simulation
# 
# ----------------------------------------
# # TOP-LEVEL TEMPLATE - BEGIN
# #
# # QSYS_SIMDIR is used in the Quartus-generated IP simulation script to
# # construct paths to the files required to simulate the IP in your Quartus
# # project. By default, the IP script assumes that you are launching the
# # simulator from the IP script location. If launching from another
# # location, set QSYS_SIMDIR to the output directory you specified when you
# # generated the IP script, relative to the directory from which you launch
# # the simulator. In this case, you must also copy the generated files
# # "cds.lib" and "hdl.var" - plus the directory "cds_libs" if generated - 
# # into the location from which you launch the simulator, or incorporate
# # into any existing library setup.
# #
# # Run Quartus-generated IP simulation script once to compile Quartus EDA
# # simulation libraries and Quartus-generated IP simulation files, and copy
# # any ROM/RAM initialization files to the simulation directory.
# # - If necessary, specify any compilation options:
# #   USER_DEFINED_COMPILE_OPTIONS
# #   USER_DEFINED_VHDL_COMPILE_OPTIONS applied to vhdl compiler
# #   USER_DEFINED_VERILOG_COMPILE_OPTIONS applied to verilog compiler
# #
# source <script generation output directory>/cadence/ncsim_setup.sh \
# SKIP_ELAB=1 \
# SKIP_SIM=1 \
# USER_DEFINED_COMPILE_OPTIONS=<compilation options for your design> \
# USER_DEFINED_VHDL_COMPILE_OPTIONS=<VHDL compilation options for your design> \
# USER_DEFINED_VERILOG_COMPILE_OPTIONS=<Verilog compilation options for your design> \
# QSYS_SIMDIR=<script generation output directory>
# #
# # Compile all design files and testbench files, including the top level.
# # (These are all the files required for simulation other than the files
# # compiled by the IP script)
# #
# ncvlog <compilation options> <design and testbench files>
# #
# # TOP_LEVEL_NAME is used in this script to set the top-level simulation or
# # testbench module/entity name.
# #
# # Run the IP script again to elaborate and simulate the top level:
# # - Specify TOP_LEVEL_NAME and USER_DEFINED_ELAB_OPTIONS.
# # - Override the default USER_DEFINED_SIM_OPTIONS. For example, to run
# #   until $finish(), set to an empty string: USER_DEFINED_SIM_OPTIONS="".
# #
# source <script generation output directory>/cadence/ncsim_setup.sh \
# SKIP_FILE_COPY=1 \
# SKIP_DEV_COM=1 \
# SKIP_COM=1 \
# TOP_LEVEL_NAME=<simulation top> \
# USER_DEFINED_ELAB_OPTIONS=<elaboration options for your design> \
# USER_DEFINED_SIM_OPTIONS=<simulation options for your design>
# #
# # TOP-LEVEL TEMPLATE - END
# ----------------------------------------
# 
# IP SIMULATION SCRIPT
# ----------------------------------------
# If multicore_access_controller_v4 is one of several IP cores in your
# Quartus project, you can generate a simulation script
# suitable for inclusion in your top-level simulation
# script by running the following command line:
# 
# ip-setup-simulation --quartus-project=<quartus project>
# 
# ip-setup-simulation will discover the Altera IP
# within the Quartus project, and generate a unified
# script which supports all the Altera IP within the design.
# ----------------------------------------
# ACDS 20.1 720 win32 2026.10.28.17:09:37
# ----------------------------------------
# initialize variables
TOP_LEVEL_NAME="multicore_access_controller_v4"
QSYS_SIMDIR="./../"
QUARTUS_INSTALL_DIR="C:/users/thiagos.chiotti/desktop/diretorioquartus/quartus/"
SKIP_FILE_COPY=0
SKIP_DEV_COM=0
SKIP_COM=0
SKIP_ELAB=0
SKIP_SIM=0
USER_DEFINED_ELAB_OPTIONS=""
USER_DEFINED_SIM_OPTIONS="-input \"@run 100; exit\""

# ----------------------------------------
# overwrite variables - DO NOT MODIFY!
# This block evaluates each command line argument, typically used for 
# overwriting variables. An example usage:
#   sh <simulator>_setup.sh SKIP_SIM=1
for expression in "$@"; do
  eval $expression
  if [ $? -ne 0 ]; then
    echo "Error: This command line argument, \"$expression\", is/has an invalid expression." >&2
    exit $?
  fi
done

# ----------------------------------------
# initialize simulation properties - DO NOT MODIFY!
ELAB_OPTIONS=""
SIM_OPTIONS=""
if [[ `ncsim -version` != *"ncsim(64)"* ]]; then
  :
else
  :
fi

# ----------------------------------------
# create compilation libraries
mkdir -p ./libraries/work/
mkdir -p ./libraries/error_adapter_0/
mkdir -p ./libraries/avalon_st_adapter/
mkdir -p ./libraries/rsp_mux_001/
mkdir -p ./libraries/rsp_mux/
mkdir -p ./libraries/rsp_demux_009/
mkdir -p ./libraries/rsp_demux_004/
mkdir -p ./libraries/cmd_mux_009/
mkdir -p ./libraries/cmd_mux_004/
mkdir -p ./libraries/cmd_mux/
mkdir -p ./libraries/cmd_demux_004/
mkdir -p ./libraries/cmd_demux_001/
mkdir -p ./libraries/cmd_demux/
mkdir -p ./libraries/dma_0_read_master_limiter/
mkdir -p ./libraries/router_014/
mkdir -p ./libraries/router_013/
mkdir -p ./libraries/router_012/
mkdir -p ./libraries/router_009/
mkdir -p ./libraries/router_008/
mkdir -p ./libraries/router_006/
mkdir -p ./libraries/router_005/
mkdir -p ./libraries/router_004/
mkdir -p ./libraries/router_003/
mkdir -p ./libraries/router_002/
mkdir -p ./libraries/router_001/
mkdir -p ./libraries/router/
mkdir -p ./libraries/Nios_II_1_debug_mem_slave_agent_rsp_fifo/
mkdir -p ./libraries/Nios_II_1_debug_mem_slave_agent/
mkdir -p ./libraries/Nios_II_1_data_master_agent/
mkdir -p ./libraries/access_controller_v3_Avalon_MM_slave_0_translator/
mkdir -p ./libraries/Compare_and_Swap_0_Avalon_MM_master_translator/
mkdir -p ./libraries/cpu/
mkdir -p ./libraries/rst_controller/
mkdir -p ./libraries/irq_mapper/
mkdir -p ./libraries/mm_interconnect_5/
mkdir -p ./libraries/mm_interconnect_4/
mkdir -p ./libraries/mm_interconnect_3/
mkdir -p ./libraries/mm_interconnect_2/
mkdir -p ./libraries/mm_interconnect_1/
mkdir -p ./libraries/mm_interconnect_0/
mkdir -p ./libraries/Nios_II_1_custom_instruction_master_multi_xconnect/
mkdir -p ./libraries/lag_0_custom_instruction_master_multi_slave_translator0/
mkdir -p ./libraries/lag_0_custom_instruction_master_multi_xconnect/
mkdir -p ./libraries/lag_0_custom_instruction_master_translator/
mkdir -p ./libraries/lag_0/
mkdir -p ./libraries/hexa7seg/
mkdir -p ./libraries/dma_0/
mkdir -p ./libraries/access_controller_v3/
mkdir -p ./libraries/Timer/
mkdir -p ./libraries/Saida_Nios_II_0/
mkdir -p ./libraries/SHARED_MEM/
mkdir -p ./libraries/Nios_II_1/
mkdir -p ./libraries/Nios_II_0/
mkdir -p ./libraries/MEM_Nios_II_1/
mkdir -p ./libraries/MEM_Nios_II_0/
mkdir -p ./libraries/Entrada_Nios_II_0/
mkdir -p ./libraries/Compare_and_Swap_0/
mkdir -p ./libraries/altera_ver/
mkdir -p ./libraries/lpm_ver/
mkdir -p ./libraries/sgate_ver/
mkdir -p ./libraries/altera_mf_ver/
mkdir -p ./libraries/cyclonev_ver/
mkdir -p ./libraries/cyclonev_hssi_ver/
mkdir -p ./libraries/cyclonev_pcie_hip_ver/
mkdir -p ./libraries/altera/
mkdir -p ./libraries/lpm/
mkdir -p ./libraries/sgate/
mkdir -p ./libraries/altera_mf/
mkdir -p ./libraries/altera_lnsim/
mkdir -p ./libraries/cyclonev/

# ----------------------------------------
# copy RAM/ROM files to simulation directory
if [ $SKIP_FILE_COPY -eq 0 ]; then
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_ociram_default_contents.dat ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_ociram_default_contents.hex ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_ociram_default_contents.mif ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_a.dat ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_a.hex ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_a.mif ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_b.dat ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_b.hex ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_b.mif ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_ociram_default_contents.dat ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_ociram_default_contents.hex ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_ociram_default_contents.mif ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_a.dat ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_a.hex ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_a.mif ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_b.dat ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_b.hex ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_b.mif ./
  cp -f $QSYS_SIMDIR/submodules/multicore_access_controller_v4_SHARED_MEM.hex ./
fi

# ----------------------------------------
# compile device library files
if [ $SKIP_DEV_COM -eq 0 ]; then
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v"                      -work altera_ver           
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v"                               -work lpm_ver              
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v"                                  -work sgate_ver            
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v"                              -work altera_mf_ver        
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_hmi_atoms_ncrypt.v"      -work cyclonev_ver         
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_atoms.v"                         -work cyclonev_ver         
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_hssi_atoms_ncrypt.v"     -work cyclonev_hssi_ver    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_hssi_atoms.v"                    -work cyclonev_hssi_ver    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_pcie_hip_atoms_ncrypt.v" -work cyclonev_pcie_hip_ver
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_pcie_hip_atoms.v"                -work cyclonev_pcie_hip_ver
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_syn_attributes.vhd"                -work altera               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_standard_functions.vhd"            -work altera               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/alt_dspbuilder_package.vhd"               -work altera               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_europa_support_lib.vhd"            -work altera               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives_components.vhd"         -work altera               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.vhd"                    -work altera               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/220pack.vhd"                              -work lpm                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.vhd"                             -work lpm                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate_pack.vhd"                           -work sgate                
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.vhd"                                -work sgate                
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf_components.vhd"                 -work altera_mf            
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.vhd"                            -work altera_mf            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv"                          -work altera_lnsim         
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim_components.vhd"              -work altera_lnsim         
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cadence/cyclonev_atoms_ncrypt.v"          -work cyclonev             
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_atoms.vhd"                       -work cyclonev             
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_components.vhd"                  -work cyclonev             
fi

# ----------------------------------------
# compile design files in correct order
if [ $SKIP_COM -eq 0 ]; then
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_avalon_st_adapter_error_adapter_0.sv" -work error_adapter_0                                         -cdslib ./cds_libs/error_adapter_0.cds.lib                                        
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_avalon_st_adapter.vhd"                -work avalon_st_adapter                                       -cdslib ./cds_libs/avalon_st_adapter.cds.lib                                      
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_mux_001.sv"                       -work rsp_mux_001                                             -cdslib ./cds_libs/rsp_mux_001.cds.lib                                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work rsp_mux_001                                             -cdslib ./cds_libs/rsp_mux_001.cds.lib                                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_mux.sv"                           -work rsp_mux                                                 -cdslib ./cds_libs/rsp_mux.cds.lib                                                
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work rsp_mux                                                 -cdslib ./cds_libs/rsp_mux.cds.lib                                                
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_demux_009.sv"                     -work rsp_demux_009                                           -cdslib ./cds_libs/rsp_demux_009.cds.lib                                          
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_demux_004.sv"                     -work rsp_demux_004                                           -cdslib ./cds_libs/rsp_demux_004.cds.lib                                          
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_mux_009.sv"                       -work cmd_mux_009                                             -cdslib ./cds_libs/cmd_mux_009.cds.lib                                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work cmd_mux_009                                             -cdslib ./cds_libs/cmd_mux_009.cds.lib                                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_mux_004.sv"                       -work cmd_mux_004                                             -cdslib ./cds_libs/cmd_mux_004.cds.lib                                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work cmd_mux_004                                             -cdslib ./cds_libs/cmd_mux_004.cds.lib                                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_mux.sv"                           -work cmd_mux                                                 -cdslib ./cds_libs/cmd_mux.cds.lib                                                
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work cmd_mux                                                 -cdslib ./cds_libs/cmd_mux.cds.lib                                                
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_demux_004.sv"                     -work cmd_demux_004                                           -cdslib ./cds_libs/cmd_demux_004.cds.lib                                          
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_demux_001.sv"                     -work cmd_demux_001                                           -cdslib ./cds_libs/cmd_demux_001.cds.lib                                          
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_demux.sv"                         -work cmd_demux                                               -cdslib ./cds_libs/cmd_demux.cds.lib                                              
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_traffic_limiter.sv"                                                      -work dma_0_read_master_limiter                               -cdslib ./cds_libs/dma_0_read_master_limiter.cds.lib                              
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_reorder_memory.sv"                                                       -work dma_0_read_master_limiter                               -cdslib ./cds_libs/dma_0_read_master_limiter.cds.lib                              
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_avalon_sc_fifo.v"                                                               -work dma_0_read_master_limiter                               -cdslib ./cds_libs/dma_0_read_master_limiter.cds.lib                              
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_avalon_st_pipeline_base.v"                                                      -work dma_0_read_master_limiter                               -cdslib ./cds_libs/dma_0_read_master_limiter.cds.lib                              
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_014.sv"                        -work router_014                                              -cdslib ./cds_libs/router_014.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_013.sv"                        -work router_013                                              -cdslib ./cds_libs/router_013.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_012.sv"                        -work router_012                                              -cdslib ./cds_libs/router_012.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_009.sv"                        -work router_009                                              -cdslib ./cds_libs/router_009.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_008.sv"                        -work router_008                                              -cdslib ./cds_libs/router_008.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_006.sv"                        -work router_006                                              -cdslib ./cds_libs/router_006.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_005.sv"                        -work router_005                                              -cdslib ./cds_libs/router_005.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_004.sv"                        -work router_004                                              -cdslib ./cds_libs/router_004.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_003.sv"                        -work router_003                                              -cdslib ./cds_libs/router_003.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_002.sv"                        -work router_002                                              -cdslib ./cds_libs/router_002.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_001.sv"                        -work router_001                                              -cdslib ./cds_libs/router_001.cds.lib                                             
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router.sv"                            -work router                                                  -cdslib ./cds_libs/router.cds.lib                                                 
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_avalon_sc_fifo.v"                                                               -work Nios_II_1_debug_mem_slave_agent_rsp_fifo                -cdslib ./cds_libs/Nios_II_1_debug_mem_slave_agent_rsp_fifo.cds.lib               
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_slave_agent.sv"                                                          -work Nios_II_1_debug_mem_slave_agent                         -cdslib ./cds_libs/Nios_II_1_debug_mem_slave_agent.cds.lib                        
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_burst_uncompressor.sv"                                                   -work Nios_II_1_debug_mem_slave_agent                         -cdslib ./cds_libs/Nios_II_1_debug_mem_slave_agent.cds.lib                        
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_master_agent.sv"                                                         -work Nios_II_1_data_master_agent                             -cdslib ./cds_libs/Nios_II_1_data_master_agent.cds.lib                            
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_slave_translator.sv"                                                     -work access_controller_v3_Avalon_MM_slave_0_translator       -cdslib ./cds_libs/access_controller_v3_Avalon_MM_slave_0_translator.cds.lib      
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_master_translator.sv"                                                    -work Compare_and_Swap_0_Avalon_MM_master_translator          -cdslib ./cds_libs/Compare_and_Swap_0_Avalon_MM_master_translator.cds.lib         
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu.v"                                        -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_debug_slave_sysclk.v"                     -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_debug_slave_tck.v"                        -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_debug_slave_wrapper.v"                    -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_test_bench.v"                             -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu.v"                                        -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_debug_slave_sysclk.v"                     -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_debug_slave_tck.v"                        -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_debug_slave_wrapper.v"                    -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_test_bench.v"                             -work cpu                                                     -cdslib ./cds_libs/cpu.cds.lib                                                    
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_reset_controller.v"                                                             -work rst_controller                                          -cdslib ./cds_libs/rst_controller.cds.lib                                         
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_reset_synchronizer.v"                                                           -work rst_controller                                          -cdslib ./cds_libs/rst_controller.cds.lib                                         
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_irq_mapper.sv"                                          -work irq_mapper                                              -cdslib ./cds_libs/irq_mapper.cds.lib                                             
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_5.v"                                    -work mm_interconnect_5                                       -cdslib ./cds_libs/mm_interconnect_5.cds.lib                                      
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4.v"                                    -work mm_interconnect_4                                       -cdslib ./cds_libs/mm_interconnect_4.cds.lib                                      
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_3.v"                                    -work mm_interconnect_3                                       -cdslib ./cds_libs/mm_interconnect_3.cds.lib                                      
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_2.v"                                    -work mm_interconnect_2                                       -cdslib ./cds_libs/mm_interconnect_2.cds.lib                                      
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_1.v"                                    -work mm_interconnect_1                                       -cdslib ./cds_libs/mm_interconnect_1.cds.lib                                      
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_0.v"                                    -work mm_interconnect_0                                       -cdslib ./cds_libs/mm_interconnect_0.cds.lib                                      
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_custom_instruction_master_multi_xconnect.sv"  -work Nios_II_1_custom_instruction_master_multi_xconnect      -cdslib ./cds_libs/Nios_II_1_custom_instruction_master_multi_xconnect.cds.lib     
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_customins_slave_translator.sv"                                                  -work lag_0_custom_instruction_master_multi_slave_translator0 -cdslib ./cds_libs/lag_0_custom_instruction_master_multi_slave_translator0.cds.lib
  ncvlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_lag_0_custom_instruction_master_multi_xconnect.sv"      -work lag_0_custom_instruction_master_multi_xconnect          -cdslib ./cds_libs/lag_0_custom_instruction_master_multi_xconnect.cds.lib         
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_customins_master_translator.v"                                                  -work lag_0_custom_instruction_master_translator              -cdslib ./cds_libs/lag_0_custom_instruction_master_translator.cds.lib             
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/comparador_4bits.vhd"                                                                  -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/contador_defasador.vhd"                                                                -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/defasador.vhd"                                                                         -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/fluxo_de_dados_defasador.vhd"                                                          -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/register_file_defasador.vhd"                                                           -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/register_n_bits.vhd"                                                                   -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/unidade_de_controle_defasador.vhd"                                                     -work lag_0                                                   -cdslib ./cds_libs/lag_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_hexa7seg.vhd"                                           -work hexa7seg                                                -cdslib ./cds_libs/hexa7seg.cds.lib                                               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_dma_0.vhd"                                              -work dma_0                                                   -cdslib ./cds_libs/dma_0.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/Register_File.vhd"                                                                     -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/access_controller_rdwr.vhd"                                                            -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/access_controller_v3.vhd"                                                              -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/avs_register_file.vhd"                                                                 -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/fluxo_de_dados_access_controller.vhd"                                                  -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/fluxo_de_dados_access_controller_rdwr.vhd"                                             -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/free_signal_logic.vhd"                                                                 -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/instruction_selector.vhd"                                                              -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multiplexador_demultiplexador_access_controller.vhd"                                   -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/mutex.vhd"                                                                             -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/register_file_access_controller_rdwr.vhd"                                              -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/register_n_bits_access_controller_rdwr.vhd"                                            -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/registrador_access_controller.vhd"                                                     -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/top_level_entity.vhd"                                                                  -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/unidade_de_controle_access_controller.vhd"                                             -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/unidade_de_controle_access_controller_rdwr.vhd"                                        -work access_controller_v3                                    -cdslib ./cds_libs/access_controller_v3.cds.lib                                   
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Timer.vhd"                                              -work Timer                                                   -cdslib ./cds_libs/Timer.cds.lib                                                  
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Saida_Nios_II_0.vhd"                                    -work Saida_Nios_II_0                                         -cdslib ./cds_libs/Saida_Nios_II_0.cds.lib                                        
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_SHARED_MEM.vhd"                                         -work SHARED_MEM                                              -cdslib ./cds_libs/SHARED_MEM.cds.lib                                             
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1.v"                                            -work Nios_II_1                                               -cdslib ./cds_libs/Nios_II_1.cds.lib                                              
  ncvlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0.v"                                            -work Nios_II_0                                               -cdslib ./cds_libs/Nios_II_0.cds.lib                                              
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_MEM_Nios_II_1.vhd"                                      -work MEM_Nios_II_1                                           -cdslib ./cds_libs/MEM_Nios_II_1.cds.lib                                          
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_MEM_Nios_II_0.vhd"                                      -work MEM_Nios_II_0                                           -cdslib ./cds_libs/MEM_Nios_II_0.cds.lib                                          
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Entrada_Nios_II_0.vhd"                                  -work Entrada_Nios_II_0                                       -cdslib ./cds_libs/Entrada_Nios_II_0.cds.lib                                      
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/Fluxo_de_Dados.vhd"                                                                    -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/Register_File.vhd"                                                                     -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/Unidade_de_Controle.vhd"                                                               -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/comparador.vhd"                                                                        -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/custom_intruction_CAS.vhd"                                                             -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/db_custom_instruction_master.vhd"                                                      -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/flipflop.vhd"                                                                          -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/registrador.vhd"                                                                       -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/submodules/timer.vhd"                                                                             -work Compare_and_Swap_0                                      -cdslib ./cds_libs/Compare_and_Swap_0.cds.lib                                     
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/multicore_access_controller_v4.vhd"                                                                                                                                                                                                               
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/multicore_access_controller_v4_lag_0_custom_instruction_master_translator.vhd"                                                                                                                                                                    
  ncvhdl -v93 $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS   "$QSYS_SIMDIR/multicore_access_controller_v4_nios_ii_1_custom_instruction_master_translator.vhd"                                                                                                                                                                
fi

# ----------------------------------------
# elaborate top level design
if [ $SKIP_ELAB -eq 0 ]; then
  export GENERIC_PARAM_COMPAT_CHECK=1
  ncelab -access +w+r+c -namemap_mixgen -relax $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS $TOP_LEVEL_NAME
fi

# ----------------------------------------
# simulate
if [ $SKIP_SIM -eq 0 ]; then
  eval ncsim -licqueue $SIM_OPTIONS $USER_DEFINED_SIM_OPTIONS $TOP_LEVEL_NAME
fi
