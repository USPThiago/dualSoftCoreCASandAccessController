
# (C) 2001-2026 Altera Corporation. All rights reserved.
# Your use of Altera Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Altera 
# Program License Subscription Agreement, Altera MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Altera and sold by Altera 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ----------------------------------------
# Auto-generated simulation script msim_setup.tcl
# ----------------------------------------
# This script provides commands to simulate the following IP detected in
# your Quartus project:
#     multicore_access_controller_v4
# 
# Altera recommends that you source this Quartus-generated IP simulation
# script from your own customized top-level script, and avoid editing this
# generated script.
# 
# To write a top-level script that compiles Altera simulation libraries and
# the Quartus-generated IP in your project, along with your design and
# testbench files, copy the text from the TOP-LEVEL TEMPLATE section below
# into a new file, e.g. named "mentor.do", and modify the text as directed.
# 
# ----------------------------------------
# # TOP-LEVEL TEMPLATE - BEGIN
# #
# # QSYS_SIMDIR is used in the Quartus-generated IP simulation script to
# # construct paths to the files required to simulate the IP in your Quartus
# # project. By default, the IP script assumes that you are launching the
# # simulator from the IP script location. If launching from another
# # location, set QSYS_SIMDIR to the output directory you specified when you
# # generated the IP script, relative to the directory from which you launch
# # the simulator.
# #
# set QSYS_SIMDIR <script generation output directory>
# #
# # Source the generated IP simulation script.
# source $QSYS_SIMDIR/mentor/msim_setup.tcl
# #
# # Set any compilation options you require (this is unusual).
# set USER_DEFINED_COMPILE_OPTIONS <compilation options>
# set USER_DEFINED_VHDL_COMPILE_OPTIONS <compilation options for VHDL>
# set USER_DEFINED_VERILOG_COMPILE_OPTIONS <compilation options for Verilog>
# #
# # Call command to compile the Quartus EDA simulation library.
# dev_com
# #
# # Call command to compile the Quartus-generated IP simulation files.
# com
# #
# # Add commands to compile all design files and testbench files, including
# # the top level. (These are all the files required for simulation other
# # than the files compiled by the Quartus-generated IP simulation script)
# #
# vlog <compilation options> <design and testbench files>
# #
# # Set the top-level simulation or testbench module/entity name, which is
# # used by the elab command to elaborate the top level.
# #
# set TOP_LEVEL_NAME <simulation top>
# #
# # Set any elaboration options you require.
# set USER_DEFINED_ELAB_OPTIONS <elaboration options>
# #
# # Call command to elaborate your design and testbench.
# elab
# #
# # Run the simulation.
# run -a
# #
# # Report success to the shell.
# exit -code 0
# #
# # TOP-LEVEL TEMPLATE - END
# ----------------------------------------
# 
# IP SIMULATION SCRIPT
# ----------------------------------------
# If multicore_access_controller_v4 is one of several IP cores in your
# Quartus project, you can generate a simulation script
# suitable for inclusion in your top-level simulation
# script by running the following command line:
# 
# ip-setup-simulation --quartus-project=<quartus project>
# 
# ip-setup-simulation will discover the Altera IP
# within the Quartus project, and generate a unified
# script which supports all the Altera IP within the design.
# ----------------------------------------
# ACDS 20.1 720 win32 2026.10.28.17:09:37

# ----------------------------------------
# Initialize variables
if ![info exists SYSTEM_INSTANCE_NAME] { 
  set SYSTEM_INSTANCE_NAME ""
} elseif { ![ string match "" $SYSTEM_INSTANCE_NAME ] } { 
  set SYSTEM_INSTANCE_NAME "/$SYSTEM_INSTANCE_NAME"
}

if ![info exists TOP_LEVEL_NAME] { 
  set TOP_LEVEL_NAME "multicore_access_controller_v4"
}

if ![info exists QSYS_SIMDIR] { 
  set QSYS_SIMDIR "./../"
}

if ![info exists QUARTUS_INSTALL_DIR] { 
  set QUARTUS_INSTALL_DIR "C:/users/thiagos.chiotti/desktop/diretorioquartus/quartus/"
}

if ![info exists USER_DEFINED_COMPILE_OPTIONS] { 
  set USER_DEFINED_COMPILE_OPTIONS ""
}
if ![info exists USER_DEFINED_VHDL_COMPILE_OPTIONS] { 
  set USER_DEFINED_VHDL_COMPILE_OPTIONS ""
}
if ![info exists USER_DEFINED_VERILOG_COMPILE_OPTIONS] { 
  set USER_DEFINED_VERILOG_COMPILE_OPTIONS ""
}
if ![info exists USER_DEFINED_ELAB_OPTIONS] { 
  set USER_DEFINED_ELAB_OPTIONS ""
}

# ----------------------------------------
# Initialize simulation properties - DO NOT MODIFY!
set ELAB_OPTIONS ""
set SIM_OPTIONS ""
if ![ string match "*-64 vsim*" [ vsim -version ] ] {
} else {
}

# ----------------------------------------
# Copy ROM/RAM files to simulation directory
alias file_copy {
  echo "\[exec\] file_copy"
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_ociram_default_contents.dat ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_ociram_default_contents.hex ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_ociram_default_contents.mif ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_a.dat ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_a.hex ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_a.mif ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_b.dat ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_b.hex ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_rf_ram_b.mif ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_ociram_default_contents.dat ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_ociram_default_contents.hex ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_ociram_default_contents.mif ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_a.dat ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_a.hex ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_a.mif ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_b.dat ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_b.hex ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_rf_ram_b.mif ./
  file copy -force $QSYS_SIMDIR/submodules/multicore_access_controller_v4_SHARED_MEM.hex ./
}

# ----------------------------------------
# Create compilation libraries
proc ensure_lib { lib } { if ![file isdirectory $lib] { vlib $lib } }
ensure_lib          ./libraries/     
ensure_lib          ./libraries/work/
vmap       work     ./libraries/work/
vmap       work_lib ./libraries/work/
if ![ string match "*ModelSim ALTERA*" [ vsim -version ] ] {
  ensure_lib                       ./libraries/altera_ver/           
  vmap       altera_ver            ./libraries/altera_ver/           
  ensure_lib                       ./libraries/lpm_ver/              
  vmap       lpm_ver               ./libraries/lpm_ver/              
  ensure_lib                       ./libraries/sgate_ver/            
  vmap       sgate_ver             ./libraries/sgate_ver/            
  ensure_lib                       ./libraries/altera_mf_ver/        
  vmap       altera_mf_ver         ./libraries/altera_mf_ver/        
  ensure_lib                       ./libraries/altera_lnsim_ver/     
  vmap       altera_lnsim_ver      ./libraries/altera_lnsim_ver/     
  ensure_lib                       ./libraries/cyclonev_ver/         
  vmap       cyclonev_ver          ./libraries/cyclonev_ver/         
  ensure_lib                       ./libraries/cyclonev_hssi_ver/    
  vmap       cyclonev_hssi_ver     ./libraries/cyclonev_hssi_ver/    
  ensure_lib                       ./libraries/cyclonev_pcie_hip_ver/
  vmap       cyclonev_pcie_hip_ver ./libraries/cyclonev_pcie_hip_ver/
  ensure_lib                       ./libraries/altera/               
  vmap       altera                ./libraries/altera/               
  ensure_lib                       ./libraries/lpm/                  
  vmap       lpm                   ./libraries/lpm/                  
  ensure_lib                       ./libraries/sgate/                
  vmap       sgate                 ./libraries/sgate/                
  ensure_lib                       ./libraries/altera_mf/            
  vmap       altera_mf             ./libraries/altera_mf/            
  ensure_lib                       ./libraries/altera_lnsim/         
  vmap       altera_lnsim          ./libraries/altera_lnsim/         
  ensure_lib                       ./libraries/cyclonev/             
  vmap       cyclonev              ./libraries/cyclonev/             
}
ensure_lib                                                         ./libraries/error_adapter_0/                                        
vmap       error_adapter_0                                         ./libraries/error_adapter_0/                                        
ensure_lib                                                         ./libraries/avalon_st_adapter/                                      
vmap       avalon_st_adapter                                       ./libraries/avalon_st_adapter/                                      
ensure_lib                                                         ./libraries/rsp_mux_001/                                            
vmap       rsp_mux_001                                             ./libraries/rsp_mux_001/                                            
ensure_lib                                                         ./libraries/rsp_mux/                                                
vmap       rsp_mux                                                 ./libraries/rsp_mux/                                                
ensure_lib                                                         ./libraries/rsp_demux_009/                                          
vmap       rsp_demux_009                                           ./libraries/rsp_demux_009/                                          
ensure_lib                                                         ./libraries/rsp_demux_004/                                          
vmap       rsp_demux_004                                           ./libraries/rsp_demux_004/                                          
ensure_lib                                                         ./libraries/cmd_mux_009/                                            
vmap       cmd_mux_009                                             ./libraries/cmd_mux_009/                                            
ensure_lib                                                         ./libraries/cmd_mux_004/                                            
vmap       cmd_mux_004                                             ./libraries/cmd_mux_004/                                            
ensure_lib                                                         ./libraries/cmd_mux/                                                
vmap       cmd_mux                                                 ./libraries/cmd_mux/                                                
ensure_lib                                                         ./libraries/cmd_demux_004/                                          
vmap       cmd_demux_004                                           ./libraries/cmd_demux_004/                                          
ensure_lib                                                         ./libraries/cmd_demux_001/                                          
vmap       cmd_demux_001                                           ./libraries/cmd_demux_001/                                          
ensure_lib                                                         ./libraries/cmd_demux/                                              
vmap       cmd_demux                                               ./libraries/cmd_demux/                                              
ensure_lib                                                         ./libraries/dma_0_read_master_limiter/                              
vmap       dma_0_read_master_limiter                               ./libraries/dma_0_read_master_limiter/                              
ensure_lib                                                         ./libraries/router_014/                                             
vmap       router_014                                              ./libraries/router_014/                                             
ensure_lib                                                         ./libraries/router_013/                                             
vmap       router_013                                              ./libraries/router_013/                                             
ensure_lib                                                         ./libraries/router_012/                                             
vmap       router_012                                              ./libraries/router_012/                                             
ensure_lib                                                         ./libraries/router_009/                                             
vmap       router_009                                              ./libraries/router_009/                                             
ensure_lib                                                         ./libraries/router_008/                                             
vmap       router_008                                              ./libraries/router_008/                                             
ensure_lib                                                         ./libraries/router_006/                                             
vmap       router_006                                              ./libraries/router_006/                                             
ensure_lib                                                         ./libraries/router_005/                                             
vmap       router_005                                              ./libraries/router_005/                                             
ensure_lib                                                         ./libraries/router_004/                                             
vmap       router_004                                              ./libraries/router_004/                                             
ensure_lib                                                         ./libraries/router_003/                                             
vmap       router_003                                              ./libraries/router_003/                                             
ensure_lib                                                         ./libraries/router_002/                                             
vmap       router_002                                              ./libraries/router_002/                                             
ensure_lib                                                         ./libraries/router_001/                                             
vmap       router_001                                              ./libraries/router_001/                                             
ensure_lib                                                         ./libraries/router/                                                 
vmap       router                                                  ./libraries/router/                                                 
ensure_lib                                                         ./libraries/Nios_II_1_debug_mem_slave_agent_rsp_fifo/               
vmap       Nios_II_1_debug_mem_slave_agent_rsp_fifo                ./libraries/Nios_II_1_debug_mem_slave_agent_rsp_fifo/               
ensure_lib                                                         ./libraries/Nios_II_1_debug_mem_slave_agent/                        
vmap       Nios_II_1_debug_mem_slave_agent                         ./libraries/Nios_II_1_debug_mem_slave_agent/                        
ensure_lib                                                         ./libraries/Nios_II_1_data_master_agent/                            
vmap       Nios_II_1_data_master_agent                             ./libraries/Nios_II_1_data_master_agent/                            
ensure_lib                                                         ./libraries/access_controller_v3_Avalon_MM_slave_0_translator/      
vmap       access_controller_v3_Avalon_MM_slave_0_translator       ./libraries/access_controller_v3_Avalon_MM_slave_0_translator/      
ensure_lib                                                         ./libraries/Compare_and_Swap_0_Avalon_MM_master_translator/         
vmap       Compare_and_Swap_0_Avalon_MM_master_translator          ./libraries/Compare_and_Swap_0_Avalon_MM_master_translator/         
ensure_lib                                                         ./libraries/cpu/                                                    
vmap       cpu                                                     ./libraries/cpu/                                                    
ensure_lib                                                         ./libraries/rst_controller/                                         
vmap       rst_controller                                          ./libraries/rst_controller/                                         
ensure_lib                                                         ./libraries/irq_mapper/                                             
vmap       irq_mapper                                              ./libraries/irq_mapper/                                             
ensure_lib                                                         ./libraries/mm_interconnect_5/                                      
vmap       mm_interconnect_5                                       ./libraries/mm_interconnect_5/                                      
ensure_lib                                                         ./libraries/mm_interconnect_4/                                      
vmap       mm_interconnect_4                                       ./libraries/mm_interconnect_4/                                      
ensure_lib                                                         ./libraries/mm_interconnect_3/                                      
vmap       mm_interconnect_3                                       ./libraries/mm_interconnect_3/                                      
ensure_lib                                                         ./libraries/mm_interconnect_2/                                      
vmap       mm_interconnect_2                                       ./libraries/mm_interconnect_2/                                      
ensure_lib                                                         ./libraries/mm_interconnect_1/                                      
vmap       mm_interconnect_1                                       ./libraries/mm_interconnect_1/                                      
ensure_lib                                                         ./libraries/mm_interconnect_0/                                      
vmap       mm_interconnect_0                                       ./libraries/mm_interconnect_0/                                      
ensure_lib                                                         ./libraries/Nios_II_1_custom_instruction_master_multi_xconnect/     
vmap       Nios_II_1_custom_instruction_master_multi_xconnect      ./libraries/Nios_II_1_custom_instruction_master_multi_xconnect/     
ensure_lib                                                         ./libraries/lag_0_custom_instruction_master_multi_slave_translator0/
vmap       lag_0_custom_instruction_master_multi_slave_translator0 ./libraries/lag_0_custom_instruction_master_multi_slave_translator0/
ensure_lib                                                         ./libraries/lag_0_custom_instruction_master_multi_xconnect/         
vmap       lag_0_custom_instruction_master_multi_xconnect          ./libraries/lag_0_custom_instruction_master_multi_xconnect/         
ensure_lib                                                         ./libraries/lag_0_custom_instruction_master_translator/             
vmap       lag_0_custom_instruction_master_translator              ./libraries/lag_0_custom_instruction_master_translator/             
ensure_lib                                                         ./libraries/lag_0/                                                  
vmap       lag_0                                                   ./libraries/lag_0/                                                  
ensure_lib                                                         ./libraries/hexa7seg/                                               
vmap       hexa7seg                                                ./libraries/hexa7seg/                                               
ensure_lib                                                         ./libraries/dma_0/                                                  
vmap       dma_0                                                   ./libraries/dma_0/                                                  
ensure_lib                                                         ./libraries/access_controller_v3/                                   
vmap       access_controller_v3                                    ./libraries/access_controller_v3/                                   
ensure_lib                                                         ./libraries/Timer/                                                  
vmap       Timer                                                   ./libraries/Timer/                                                  
ensure_lib                                                         ./libraries/Saida_Nios_II_0/                                        
vmap       Saida_Nios_II_0                                         ./libraries/Saida_Nios_II_0/                                        
ensure_lib                                                         ./libraries/SHARED_MEM/                                             
vmap       SHARED_MEM                                              ./libraries/SHARED_MEM/                                             
ensure_lib                                                         ./libraries/Nios_II_1/                                              
vmap       Nios_II_1                                               ./libraries/Nios_II_1/                                              
ensure_lib                                                         ./libraries/Nios_II_0/                                              
vmap       Nios_II_0                                               ./libraries/Nios_II_0/                                              
ensure_lib                                                         ./libraries/MEM_Nios_II_1/                                          
vmap       MEM_Nios_II_1                                           ./libraries/MEM_Nios_II_1/                                          
ensure_lib                                                         ./libraries/MEM_Nios_II_0/                                          
vmap       MEM_Nios_II_0                                           ./libraries/MEM_Nios_II_0/                                          
ensure_lib                                                         ./libraries/Entrada_Nios_II_0/                                      
vmap       Entrada_Nios_II_0                                       ./libraries/Entrada_Nios_II_0/                                      
ensure_lib                                                         ./libraries/Compare_and_Swap_0/                                     
vmap       Compare_and_Swap_0                                      ./libraries/Compare_and_Swap_0/                                     

# ----------------------------------------
# Compile device library files
alias dev_com {
  echo "\[exec\] dev_com"
  if ![ string match "*ModelSim ALTERA*" [ vsim -version ] ] {
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v"                     -work altera_ver           
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v"                              -work lpm_ver              
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v"                                 -work sgate_ver            
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v"                             -work altera_mf_ver        
    eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv"                         -work altera_lnsim_ver     
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/mentor/cyclonev_atoms_ncrypt.v"          -work cyclonev_ver         
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/mentor/cyclonev_hmi_atoms_ncrypt.v"      -work cyclonev_ver         
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_atoms.v"                        -work cyclonev_ver         
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/mentor/cyclonev_hssi_atoms_ncrypt.v"     -work cyclonev_hssi_ver    
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_hssi_atoms.v"                   -work cyclonev_hssi_ver    
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/mentor/cyclonev_pcie_hip_atoms_ncrypt.v" -work cyclonev_pcie_hip_ver
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_pcie_hip_atoms.v"               -work cyclonev_pcie_hip_ver
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_syn_attributes.vhd"               -work altera               
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_standard_functions.vhd"           -work altera               
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/alt_dspbuilder_package.vhd"              -work altera               
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_europa_support_lib.vhd"           -work altera               
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives_components.vhd"        -work altera               
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.vhd"                   -work altera               
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/220pack.vhd"                             -work lpm                  
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.vhd"                            -work lpm                  
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate_pack.vhd"                          -work sgate                
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.vhd"                               -work sgate                
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf_components.vhd"                -work altera_mf            
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.vhd"                           -work altera_mf            
    eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QUARTUS_INSTALL_DIR/eda/sim_lib/mentor/altera_lnsim_for_vhdl.sv"         -work altera_lnsim         
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim_components.vhd"             -work altera_lnsim         
    eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QUARTUS_INSTALL_DIR/eda/sim_lib/mentor/cyclonev_atoms_ncrypt.v"          -work cyclonev             
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_atoms.vhd"                      -work cyclonev             
    eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QUARTUS_INSTALL_DIR/eda/sim_lib/cyclonev_components.vhd"                 -work cyclonev             
  }
}

# ----------------------------------------
# Compile the design files in correct order
alias com {
  echo "\[exec\] com"
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_avalon_st_adapter_error_adapter_0.sv" -work error_adapter_0                                        
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_avalon_st_adapter.vhd"                -work avalon_st_adapter                                      
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_mux_001.sv"                       -work rsp_mux_001                                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work rsp_mux_001                                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_mux.sv"                           -work rsp_mux                                                
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work rsp_mux                                                
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_demux_009.sv"                     -work rsp_demux_009                                          
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_rsp_demux_004.sv"                     -work rsp_demux_004                                          
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_mux_009.sv"                       -work cmd_mux_009                                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work cmd_mux_009                                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_mux_004.sv"                       -work cmd_mux_004                                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work cmd_mux_004                                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_mux.sv"                           -work cmd_mux                                                
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_arbitrator.sv"                                                           -work cmd_mux                                                
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_demux_004.sv"                     -work cmd_demux_004                                          
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_demux_001.sv"                     -work cmd_demux_001                                          
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_cmd_demux.sv"                         -work cmd_demux                                              
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_traffic_limiter.sv"                                                      -work dma_0_read_master_limiter                              
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_reorder_memory.sv"                                                       -work dma_0_read_master_limiter                              
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_avalon_sc_fifo.v"                                                               -work dma_0_read_master_limiter                              
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_avalon_st_pipeline_base.v"                                                      -work dma_0_read_master_limiter                              
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_014.sv"                        -work router_014                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_013.sv"                        -work router_013                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_012.sv"                        -work router_012                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_009.sv"                        -work router_009                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_008.sv"                        -work router_008                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_006.sv"                        -work router_006                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_005.sv"                        -work router_005                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_004.sv"                        -work router_004                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_003.sv"                        -work router_003                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_002.sv"                        -work router_002                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router_001.sv"                        -work router_001                                             
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4_router.sv"                            -work router                                                 
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_avalon_sc_fifo.v"                                                               -work Nios_II_1_debug_mem_slave_agent_rsp_fifo               
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_slave_agent.sv"                                                          -work Nios_II_1_debug_mem_slave_agent                        
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_burst_uncompressor.sv"                                                   -work Nios_II_1_debug_mem_slave_agent                        
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_master_agent.sv"                                                         -work Nios_II_1_data_master_agent                            
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_slave_translator.sv"                                                     -work access_controller_v3_Avalon_MM_slave_0_translator      
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_merlin_master_translator.sv"                                                    -work Compare_and_Swap_0_Avalon_MM_master_translator         
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu.v"                                        -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_debug_slave_sysclk.v"                     -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_debug_slave_tck.v"                        -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_debug_slave_wrapper.v"                    -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_cpu_test_bench.v"                             -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu.v"                                        -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_debug_slave_sysclk.v"                     -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_debug_slave_tck.v"                        -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_debug_slave_wrapper.v"                    -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0_cpu_test_bench.v"                             -work cpu                                                    
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_reset_controller.v"                                                             -work rst_controller                                         
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_reset_synchronizer.v"                                                           -work rst_controller                                         
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_irq_mapper.sv"                                          -work irq_mapper                                             
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_5.v"                                    -work mm_interconnect_5                                      
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_4.v"                                    -work mm_interconnect_4                                      
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_3.v"                                    -work mm_interconnect_3                                      
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_2.v"                                    -work mm_interconnect_2                                      
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_1.v"                                    -work mm_interconnect_1                                      
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_mm_interconnect_0.v"                                    -work mm_interconnect_0                                      
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1_custom_instruction_master_multi_xconnect.sv"  -work Nios_II_1_custom_instruction_master_multi_xconnect     
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/altera_customins_slave_translator.sv"                                                  -work lag_0_custom_instruction_master_multi_slave_translator0
  eval  vlog -sv $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_lag_0_custom_instruction_master_multi_xconnect.sv"      -work lag_0_custom_instruction_master_multi_xconnect         
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/altera_customins_master_translator.v"                                                  -work lag_0_custom_instruction_master_translator             
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/comparador_4bits.vhd"                                                                  -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/contador_defasador.vhd"                                                                -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/defasador.vhd"                                                                         -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/fluxo_de_dados_defasador.vhd"                                                          -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/register_file_defasador.vhd"                                                           -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/register_n_bits.vhd"                                                                   -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/unidade_de_controle_defasador.vhd"                                                     -work lag_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_hexa7seg.vhd"                                           -work hexa7seg                                               
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_dma_0.vhd"                                              -work dma_0                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/Register_File.vhd"                                                                     -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/access_controller_rdwr.vhd"                                                            -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/access_controller_v3.vhd"                                                              -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/avs_register_file.vhd"                                                                 -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/fluxo_de_dados_access_controller.vhd"                                                  -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/fluxo_de_dados_access_controller_rdwr.vhd"                                             -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/free_signal_logic.vhd"                                                                 -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/instruction_selector.vhd"                                                              -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multiplexador_demultiplexador_access_controller.vhd"                                   -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/mutex.vhd"                                                                             -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/register_file_access_controller_rdwr.vhd"                                              -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/register_n_bits_access_controller_rdwr.vhd"                                            -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/registrador_access_controller.vhd"                                                     -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/top_level_entity.vhd"                                                                  -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/unidade_de_controle_access_controller.vhd"                                             -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/unidade_de_controle_access_controller_rdwr.vhd"                                        -work access_controller_v3                                   
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Timer.vhd"                                              -work Timer                                                  
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Saida_Nios_II_0.vhd"                                    -work Saida_Nios_II_0                                        
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_SHARED_MEM.vhd"                                         -work SHARED_MEM                                             
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_1.v"                                            -work Nios_II_1                                              
  eval  vlog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS     "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Nios_II_0.v"                                            -work Nios_II_0                                              
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_MEM_Nios_II_1.vhd"                                      -work MEM_Nios_II_1                                          
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_MEM_Nios_II_0.vhd"                                      -work MEM_Nios_II_0                                          
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/multicore_access_controller_v4_Entrada_Nios_II_0.vhd"                                  -work Entrada_Nios_II_0                                      
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/Fluxo_de_Dados.vhd"                                                                    -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/Register_File.vhd"                                                                     -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/Unidade_de_Controle.vhd"                                                               -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/comparador.vhd"                                                                        -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/custom_intruction_CAS.vhd"                                                             -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/db_custom_instruction_master.vhd"                                                      -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/flipflop.vhd"                                                                          -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/registrador.vhd"                                                                       -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/submodules/timer.vhd"                                                                             -work Compare_and_Swap_0                                     
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/multicore_access_controller_v4.vhd"                                                                                                                            
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/multicore_access_controller_v4_lag_0_custom_instruction_master_translator.vhd"                                                                                 
  eval  vcom $USER_DEFINED_VHDL_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS        "$QSYS_SIMDIR/multicore_access_controller_v4_nios_ii_1_custom_instruction_master_translator.vhd"                                                                             
}

# ----------------------------------------
# Elaborate top level design
alias elab {
  echo "\[exec\] elab"
  eval vsim -t ps $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS -L work -L work_lib -L error_adapter_0 -L avalon_st_adapter -L rsp_mux_001 -L rsp_mux -L rsp_demux_009 -L rsp_demux_004 -L cmd_mux_009 -L cmd_mux_004 -L cmd_mux -L cmd_demux_004 -L cmd_demux_001 -L cmd_demux -L dma_0_read_master_limiter -L router_014 -L router_013 -L router_012 -L router_009 -L router_008 -L router_006 -L router_005 -L router_004 -L router_003 -L router_002 -L router_001 -L router -L Nios_II_1_debug_mem_slave_agent_rsp_fifo -L Nios_II_1_debug_mem_slave_agent -L Nios_II_1_data_master_agent -L access_controller_v3_Avalon_MM_slave_0_translator -L Compare_and_Swap_0_Avalon_MM_master_translator -L cpu -L rst_controller -L irq_mapper -L mm_interconnect_5 -L mm_interconnect_4 -L mm_interconnect_3 -L mm_interconnect_2 -L mm_interconnect_1 -L mm_interconnect_0 -L Nios_II_1_custom_instruction_master_multi_xconnect -L lag_0_custom_instruction_master_multi_slave_translator0 -L lag_0_custom_instruction_master_multi_xconnect -L lag_0_custom_instruction_master_translator -L lag_0 -L hexa7seg -L dma_0 -L access_controller_v3 -L Timer -L Saida_Nios_II_0 -L SHARED_MEM -L Nios_II_1 -L Nios_II_0 -L MEM_Nios_II_1 -L MEM_Nios_II_0 -L Entrada_Nios_II_0 -L Compare_and_Swap_0 -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclonev_ver -L cyclonev_hssi_ver -L cyclonev_pcie_hip_ver -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L cyclonev $TOP_LEVEL_NAME
}

# ----------------------------------------
# Elaborate the top level design with -voptargs=+acc option
alias elab_debug {
  echo "\[exec\] elab_debug"
  eval vsim -voptargs=+acc -t ps $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS -L work -L work_lib -L error_adapter_0 -L avalon_st_adapter -L rsp_mux_001 -L rsp_mux -L rsp_demux_009 -L rsp_demux_004 -L cmd_mux_009 -L cmd_mux_004 -L cmd_mux -L cmd_demux_004 -L cmd_demux_001 -L cmd_demux -L dma_0_read_master_limiter -L router_014 -L router_013 -L router_012 -L router_009 -L router_008 -L router_006 -L router_005 -L router_004 -L router_003 -L router_002 -L router_001 -L router -L Nios_II_1_debug_mem_slave_agent_rsp_fifo -L Nios_II_1_debug_mem_slave_agent -L Nios_II_1_data_master_agent -L access_controller_v3_Avalon_MM_slave_0_translator -L Compare_and_Swap_0_Avalon_MM_master_translator -L cpu -L rst_controller -L irq_mapper -L mm_interconnect_5 -L mm_interconnect_4 -L mm_interconnect_3 -L mm_interconnect_2 -L mm_interconnect_1 -L mm_interconnect_0 -L Nios_II_1_custom_instruction_master_multi_xconnect -L lag_0_custom_instruction_master_multi_slave_translator0 -L lag_0_custom_instruction_master_multi_xconnect -L lag_0_custom_instruction_master_translator -L lag_0 -L hexa7seg -L dma_0 -L access_controller_v3 -L Timer -L Saida_Nios_II_0 -L SHARED_MEM -L Nios_II_1 -L Nios_II_0 -L MEM_Nios_II_1 -L MEM_Nios_II_0 -L Entrada_Nios_II_0 -L Compare_and_Swap_0 -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclonev_ver -L cyclonev_hssi_ver -L cyclonev_pcie_hip_ver -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L cyclonev $TOP_LEVEL_NAME
}

# ----------------------------------------
# Compile all the design files and elaborate the top level design
alias ld "
  dev_com
  com
  elab
"

# ----------------------------------------
# Compile all the design files and elaborate the top level design with -voptargs=+acc
alias ld_debug "
  dev_com
  com
  elab_debug
"

# ----------------------------------------
# Print out user commmand line aliases
alias h {
  echo "List Of Command Line Aliases"
  echo
  echo "file_copy                                         -- Copy ROM/RAM files to simulation directory"
  echo
  echo "dev_com                                           -- Compile device library files"
  echo
  echo "com                                               -- Compile the design files in correct order"
  echo
  echo "elab                                              -- Elaborate top level design"
  echo
  echo "elab_debug                                        -- Elaborate the top level design with -voptargs=+acc option"
  echo
  echo "ld                                                -- Compile all the design files and elaborate the top level design"
  echo
  echo "ld_debug                                          -- Compile all the design files and elaborate the top level design with -voptargs=+acc"
  echo
  echo 
  echo
  echo "List Of Variables"
  echo
  echo "TOP_LEVEL_NAME                                    -- Top level module name."
  echo "                                                     For most designs, this should be overridden"
  echo "                                                     to enable the elab/elab_debug aliases."
  echo
  echo "SYSTEM_INSTANCE_NAME                              -- Instantiated system module name inside top level module."
  echo
  echo "QSYS_SIMDIR                                       -- Platform Designer base simulation directory."
  echo
  echo "QUARTUS_INSTALL_DIR                               -- Quartus installation directory."
  echo
  echo "USER_DEFINED_COMPILE_OPTIONS                      -- User-defined compile options, added to com/dev_com aliases."
  echo
  echo "USER_DEFINED_ELAB_OPTIONS                         -- User-defined elaboration options, added to elab/elab_debug aliases."
  echo
  echo "USER_DEFINED_VHDL_COMPILE_OPTIONS                 -- User-defined vhdl compile options, added to com/dev_com aliases."
  echo
  echo "USER_DEFINED_VERILOG_COMPILE_OPTIONS              -- User-defined verilog compile options, added to com/dev_com aliases."
}
file_copy
h
