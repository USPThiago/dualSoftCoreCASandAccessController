
library ieee;
use     ieee.std_logic_1164.all; 
use 	  ieee.numeric_std.all;


entity multicore_access_controller_v4_system is
port(
	-- system signals	--
	clock				: in  std_logic;
	reset				: in  std_logic;								-- global reset must be connected to the KEY_0
	-- users inputs --
	switchs			: in  std_logic_vector(9  downto 0);
	gpios				: in  std_logic_vector(15 downto 0);
	keys				: in  std_logic_vector(2  downto 0);
	-- FPGA outputs --
	leds				: out std_logic_vector(9  downto 0);
	hex7seg_0		: out std_logic_vector(6  downto 0);
	hex7seg_1		: out std_logic_vector(6  downto 0);
	hex7seg_2		: out std_logic_vector(6  downto 0);
	hex7seg_3		: out std_logic_vector(6  downto 0);
	hex7seg_4		: out std_logic_vector(6  downto 0);
	hex7seg_5		: out std_logic_vector(6  downto 0)
);
end entity;


architecture behavior of multicore_access_controller_v4_system is 

	component multicore_access_controller_v4 is
	port (
		clk_clk                                               : in  std_logic                     := '0';             --                                   clk.clk
		compare_and_swap_0_db_signals_db_address_output       : out std_logic_vector(31 downto 0);                    --         compare_and_swap_0_db_signals.db_address_output
		compare_and_swap_0_db_signals_db_done_output          : out std_logic;                                        --                                      .db_done_output
		compare_and_swap_0_db_signals_db_expecteddata_output  : out std_logic_vector(31 downto 0);                    --                                      .db_expecteddata_output
		compare_and_swap_0_db_signals_db_newdata_index_output : out std_logic_vector(7 downto 0);                     --                                      .db_newdata_index_output
		compare_and_swap_0_db_signals_db_reset                : in  std_logic                     := '0';             --                                      .db_reset
		compare_and_swap_0_db_signals_db_start_output         : out std_logic;                                        --                                      .db_start_output
		compare_and_swap_1_db_signals_db_address_output       : out std_logic_vector(31 downto 0);                    --         compare_and_swap_1_db_signals.db_address_output
		compare_and_swap_1_db_signals_db_done_output          : out std_logic;                                        --                                      .db_done_output
		compare_and_swap_1_db_signals_db_expecteddata_output  : out std_logic_vector(31 downto 0);                    --                                      .db_expecteddata_output
		compare_and_swap_1_db_signals_db_newdata_index_output : out std_logic_vector(7 downto 0);                     --                                      .db_newdata_index_output
		compare_and_swap_1_db_signals_db_reset                : in  std_logic                     := '0';             --                                      .db_reset
		compare_and_swap_1_db_signals_db_start_output         : out std_logic;                                        --                                      .db_start_output
		dma_0_control_port_slave_address                      : in  std_logic_vector(2 downto 0)  := (others => '0'); --              dma_0_control_port_slave.address
		dma_0_control_port_slave_chipselect                   : in  std_logic                     := '0';             --                                      .chipselect
		dma_0_control_port_slave_readdata                     : out std_logic_vector(15 downto 0);                    --                                      .readdata
		dma_0_control_port_slave_write_n                      : in  std_logic                     := '0';             --                                      .write_n
		dma_0_control_port_slave_writedata                    : in  std_logic_vector(15 downto 0) := (others => '0'); --                                      .writedata
		entrada_nios_ii_0_external_connection_export          : in  std_logic_vector(7 downto 0)  := (others => '0'); -- entrada_nios_ii_0_external_connection.export
		entrada_nios_ii_1_external_connection_export          : in  std_logic_vector(7 downto 0)  := (others => '0'); -- entrada_nios_ii_1_external_connection.export
		hexa7seg_external_connection_export                   : out std_logic_vector(23 downto 0);                    --          hexa7seg_external_connection.export
		lag_0_users_input_us_delay                            : in  std_logic_vector(3 downto 0)  := (others => '0'); --                     lag_0_users_input.us_delay
		lag_0_users_input_go                                  : in  std_logic                     := '0';             --                                      .go
		lag_1_users_input_us_delay                            : in  std_logic_vector(3 downto 0)  := (others => '0'); --                     lag_1_users_input.us_delay
		lag_1_users_input_go                                  : in  std_logic                     := '0';             --                                      .go
		reset_reset_n                                         : in  std_logic                     := '0';             --                                 reset.reset_n
		saida_nios_ii_0_external_connection_export            : out std_logic_vector(7 downto 0);                     --   saida_nios_ii_0_external_connection.export
		saida_nios_ii_1_external_connection_export            : out std_logic_vector(7 downto 0)                      --   saida_nios_ii_1_external_connection.export
	);
	end component multicore_access_controller_v4;
	
		component hexa7seg is
    port (
        hexa : in  std_logic_vector(3 downto 0);
        sseg : out std_logic_vector(6 downto 0)
    );
	end component hexa7seg;
	
	component dma_controller_module is
	port(
		clock 				: in  std_logic;
		reset					: in  std_logic;
		start					: in  std_logic;
		readaddress			: in  std_logic_vector(16 downto 0);
		module_writedata	: out std_logic_vector(16 downto 0);
		module_address		: out std_logic_vector(2  downto 0);
		module_write_n		: out std_logic;
		module_chipselect	: out std_logic
	);
	end component;
	
	
	component registrador is
	port(
		clock 	: in  std_logic;
		clear 	: in  std_logic;
		enable	: in  std_logic;
		D			: in  std_logic_vector(31 downto 0);
		Q 			: out std_logic_vector(31 downto 0)
	); 
	end component registrador;
		
	component edge_detector is
	port(
		clock : in  std_logic;
		reset	: in  std_logic;
		d		: in  std_logic;
		q		: out std_logic
	);
	end component edge_detector;
	
	signal internal_access_cotroller_0_db_signals_db_state_uc_0     : std_logic_vector(3 downto 0);                     --       access_cotroller_0_db_signals.db_state_uc_0
	signal internal_access_cotroller_0_db_signals_db_state_uc_1     : std_logic_vector(3 downto 0);                     --                                    .db_state_uc_1
	signal internal_clk_clk                                         : std_logic                     := '0';             --                                 clk.clk
	signal internal_compare_and_swap_up_1_debbuger_bus_expecteddata : std_logic_vector(31 downto 0);                    --  compare_and_swap_up_1_debbuger_bus.expecteddata
	signal internal_compare_and_swap_up_1_debbuger_bus_state        : std_logic_vector(2 downto 0);                     --                                    .state
	signal internal_compare_and_swap_up_1_debbuger_bus_readdata     : std_logic_vector(31 downto 0);                    --                                    .readdata
	signal internal_compare_and_swap_up_2_debbuger_bus_expecteddata : std_logic_vector(31 downto 0);                    --  compare_and_swap_up_2_debbuger_bus.expecteddata
	signal internal_compare_and_swap_up_2_debbuger_bus_state        : std_logic_vector(2 downto 0);                     --                                    .state
	signal internal_compare_and_swap_up_2_debbuger_bus_readdata     : std_logic_vector(31 downto 0);                    --                                    .readdata
	signal internal_dma_0_control_port_slave_address                : std_logic_vector(31 downto 0) := (others => '0'); --            dma_0_control_port_slave.address
	signal internal_dma_0_control_port_slave_chipselect             : std_logic                     := '0';             --                                    .chipselect
	signal internal_dma_0_control_port_slave_readdata               : std_logic_vector(31 downto 0);                    --                                    .readdata
	signal internal_dma_0_control_port_slave_write_n                : std_logic                     := '0';             --                                    .write_n
	signal internal_dma_0_control_port_slave_writedata              : std_logic_vector(31 downto 0) := (others => '0'); --                                    .writedata
	signal internal_entrada_up_1_external_connection_export         : std_logic_vector(7 downto 0)  := (others => '0'); --    entrada_up_1_external_connection.export
	signal internal_entrada_up_0_external_connection_export         : std_logic_vector(7 downto 0)  := (others => '0'); --    entrada_up_2_external_connection.export
	signal internal_hexa7seg_external_connection_export             : std_logic_vector(23 downto 0);                    --        hexa7seg_external_connection.export
	signal internal_reset_reset_n                                   : std_logic                     := '0';             --                               reset.reset_n
	signal internal_reset_entrada_1_in_reset_reset                  : std_logic                     := '0';             --            reset_entrada_1_in_reset.reset
	signal internal_reset_entrada_0_in_reset_reset                  : std_logic                     := '0';             --            reset_entrada_2_in_reset.reset
	signal internal_reset_mem_in_reset_reset                        : std_logic                     := '0';             --                  reset_mem_in_reset.reset
	signal internal_saida_up_0_external_connection_export           : std_logic_vector(7 downto 0);                     --      saida_up_1_external_connection.export
	signal internal_saida_up_1_external_connection_export           : std_logic_vector(7 downto 0);                     --      saida_up_2_external_connection.export
	signal internal_software_resets_external_connection_export      : std_logic_vector(7 downto 0);                     -- software_resets_external_connection.
	
	signal internal_hexa7seg													 : std_logic_vector(23 downto 0);
	signal internal_start_dma_controller									 : std_logic;
	signal keys_n																	 : std_logic_vector(2 downto 0);
	
	signal db_dma_0_control_port_slave_address							 : std_logic_vector(2  downto 0);
	signal db_dma_0_control_port_slave_chipselect						 :	std_logic_vector(0  downto 0) := (others => '0');
	signal db_dma_0_control_port_slave_readdata							 : std_logic_vector(16 downto 0);
	signal db_dma_0_control_port_slave_write_n							 : std_logic_vector(0  downto 0) := (others => '0');
	signal db_dma_0_control_port_slave_writedata							 : std_logic_vector(16 downto 0);
	signal db_dma_0_control_port_start										 : std_logic_vector(0  downto 0) := (others => '0'); 
	signal db_dma_0_control_port_start_n									 : std_logic_vector(0  downto 0) := (others => '1'); 
	signal db_dma_0_control_port_slave_chipselect_n						 :	std_logic_vector(0  downto 0) := (others => '1');
	signal db_internal_reset													 : std_logic := '0';
	
	signal db_bus_address_0														 : std_logic_vector(31 downto 0); 
	signal db_bus_done_0															 : std_logic;
	signal db_bus_expecteddata_0												 : std_logic_vector(31 downto 0);
	signal db_bus_new_dataindex_0												 : std_logic_vector(7  downto 0);
	signal db_bus_start_0														 : std_logic;
	
	signal db_bus_address_1														 : std_logic_vector(31 downto 0); 
	signal db_bus_done_1															 : std_logic;
	signal db_bus_expecteddata_1												 : std_logic_vector(31 downto 0);
	signal db_bus_new_dataindex_1												 : std_logic_vector(7  downto 0);
	signal db_bus_start_1														 : std_logic;
	
	signal intenral_lag_0_user_delay											 : std_logic_vector(3 downto 0);
	signal internal_lag_1_user_delay											 : std_logic_vector(3 downto 0);
	signal internal_lags_go														 : std_logic := '0';
	
	begin 
	
		DUT : multicore_access_controller_v4 port map (
			clk_clk                                                       => clock,
			compare_and_swap_0_db_signals_db_address_output       			=> db_bus_address_0,
			compare_and_swap_0_db_signals_db_done_output          			=> db_bus_done_0,
			compare_and_swap_0_db_signals_db_expecteddata_output  			=> db_bus_expecteddata_0,
			compare_and_swap_0_db_signals_db_newdata_index_output 			=> db_bus_new_dataindex_0,
			compare_and_swap_0_db_signals_db_reset                			=> db_internal_reset,
			compare_and_swap_0_db_signals_db_start_output         			=> db_bus_start_0,
			compare_and_swap_1_db_signals_db_address_output       			=> db_bus_address_1,
			compare_and_swap_1_db_signals_db_done_output          			=> db_bus_done_1,
			compare_and_swap_1_db_signals_db_expecteddata_output  			=> db_bus_expecteddata_1,
			compare_and_swap_1_db_signals_db_newdata_index_output 			=> db_bus_new_dataindex_1,
			compare_and_swap_1_db_signals_db_reset                			=> db_internal_reset,
			compare_and_swap_1_db_signals_db_start_output         			=> db_bus_start_1,
			dma_0_control_port_slave_address                     				=> internal_dma_0_control_port_slave_address(2 downto 0),
			dma_0_control_port_slave_chipselect                  				=> internal_dma_0_control_port_slave_chipselect,
			dma_0_control_port_slave_readdata                    				=> internal_dma_0_control_port_slave_readdata(15 downto 0),
			dma_0_control_port_slave_write_n                     				=> internal_dma_0_control_port_slave_write_n,
			dma_0_control_port_slave_writedata                  				=> internal_dma_0_control_port_slave_writedata(15 downto 0),
			lag_0_users_input_us_delay                            		   => intenral_lag_0_user_delay,	
			lag_0_users_input_go                                  		   => internal_lags_go,	
			lag_1_users_input_us_delay                            		   => internal_lag_1_user_delay,	
			lag_1_users_input_go                                  		   => internal_lags_go,	
			entrada_nios_ii_0_external_connection_export                   => internal_entrada_up_0_external_connection_export,	-- Modified to test aplication [2026 09 01]
			entrada_nios_ii_1_external_connection_export                   => internal_entrada_up_1_external_connection_export,	-- Modified to test aplication [2026 09 01]
			hexa7seg_external_connection_export                            => internal_hexa7seg_external_connection_export,
			reset_reset_n                                                  => reset,
			saida_nios_ii_0_external_connection_export                     => internal_saida_up_0_external_connection_export,
			saida_nios_ii_1_external_connection_export                     => internal_saida_up_1_external_connection_export		-- Modified to test aplication [2026 09 01]
		);
		
		DEVICE_HEX7SEG_0 : hexa7seg port map (
			  hexa => internal_hexa7seg(3  downto 0),
			  sseg => hex7seg_0
		);
		 
		DEVICE_HEX7SEG_1 : hexa7seg port map (
			  hexa => internal_hexa7seg(7  downto 4),
			  sseg => hex7seg_1
		);
		
		DEVICE_HEX7SEG_2 : hexa7seg port map (
			  hexa => internal_hexa7seg(11 downto 8),
			  sseg => hex7seg_2
		);
		 
		DEVICE_HEX7SEG_3 : hexa7seg port map (
			  hexa => internal_hexa7seg(15 downto 12),
			  sseg => hex7seg_3
		);
		
		DEVICE_HEX7SEG_4 : hexa7seg port map (
			  hexa => internal_hexa7seg(19 downto 16),
			  sseg => hex7seg_4
		);
		 
		DEVICE_HEX7SEG_5 : hexa7seg port map (
			  hexa => internal_hexa7seg(23 downto 20),
			  sseg => hex7seg_5
		);
		
		DEVICE_FIRMWARE : dma_controller_module port map(
			clock 				=> clock,
			reset					=> internal_reset_reset_n,
			start					=> internal_start_dma_controller,
			readaddress			=> '0' & gpios,
			module_writedata	=> internal_dma_0_control_port_slave_writedata(16 downto 0),
			module_address		=> internal_dma_0_control_port_slave_address(2 downto 0),
			module_write_n		=> internal_dma_0_control_port_slave_write_n,
			module_chipselect	=> internal_dma_0_control_port_slave_chipselect
		);
		
		
		
		DEVICE_EDGEDETECTOR_1 : edge_detector port map (
			clock  	=> clock,
			reset		=> internal_reset_reset_n,
			d			=> keys_n(0),
			q			=> internal_entrada_up_0_external_connection_export(0)
		);
		
		DEVICE_EDGEDETECTOR_2 : edge_detector port map (
			clock  	=> clock,
			reset		=> internal_reset_reset_n,
			d			=> keys_n(1),
			q			=> db_internal_reset
		);
		
		DEVICE_EDGEDETECTOR_3 : edge_detector port map (
			clock  	=> clock,
			reset		=> internal_reset_reset_n,
			d			=> keys_n(2),
			q			=> internal_start_dma_controller
		);
		
		-- conections --

		DEVICE_DB_REGISTER_1 : registrador port map (
			clock 	=> clock,
			clear 	=> internal_reset_reset_n,
			enable	=> db_dma_0_control_port_slave_chipselect_n(0),
			D			=> internal_dma_0_control_port_slave_address,
			Q(2 downto 0) => db_dma_0_control_port_slave_address
		); 
		
		DEVICE_DB_REGISTER_2 : registrador port map (
			clock 	=> clock,
			clear 	=> internal_reset_reset_n,
			enable	=> db_dma_0_control_port_slave_chipselect_n(0),
			D			=> (0 => internal_dma_0_control_port_slave_chipselect, others => '0'),
			Q(0 downto 0) => db_dma_0_control_port_slave_chipselect
		);
		
		DEVICE_DB_REGISTER_3 : registrador port map (
			clock 	=> clock,
			clear 	=> internal_reset_reset_n,
			enable	=> db_dma_0_control_port_slave_chipselect_n(0),
			D			=> internal_dma_0_control_port_slave_readdata,
			Q(16 downto 0) => db_dma_0_control_port_slave_readdata
		);
		
		DEVICE_DB_REGISTER_4 : registrador port map (
			clock 	=> clock,
			clear 	=> internal_reset_reset_n,
			enable	=> db_dma_0_control_port_slave_chipselect_n(0),
			D			=> internal_dma_0_control_port_slave_writedata,
			Q(16 downto 0) => db_dma_0_control_port_slave_writedata
		);
		
		DEVICE_DB_REGISTER_5 : registrador port map (
			clock 	=> clock,
			clear 	=> internal_reset_reset_n,
			enable	=> db_dma_0_control_port_slave_chipselect_n(0),
			D			=> (0 => internal_dma_0_control_port_slave_write_n, others => '0'),
			Q(0 downto 0) => db_dma_0_control_port_slave_write_n
		);
		
		DEVICE_DB_REGISTER_6 : registrador port map (
			clock 	=> clock,
			clear 	=> internal_reset_reset_n,
			enable	=> db_dma_0_control_port_start_n(0),
			D			=> (0 => internal_start_dma_controller, others => '0'),
			Q(0 downto 0) => db_dma_0_control_port_start
		);	
		
		internal_clk_clk 			<= clock;
		internal_reset_reset_n	<= not reset;
		keys_n  			  			<= not keys; 
		
		internal_hexa7seg <= internal_hexa7seg_external_connection_export 			  		    when switchs(4 downto 0) = "00000" else
									x"00" & internal_dma_0_control_port_slave_readdata(15 downto 0) when switchs(4 downto 0) = "00001" else
									x"00" & gpios																	 when switchs(4 downto 0) = "00010" else
									x"00000" & '0' & db_dma_0_control_port_slave_address	 	 		 when switchs(4 downto 0) = "00011" else
									(0 => db_dma_0_control_port_slave_chipselect(0), others => '0') when switchs(4 downto 0) = "00100" else
									x"00" & db_dma_0_control_port_slave_readdata(15 downto 0) 		 when switchs(4 downto 0) = "00101" else
									x"00" & db_dma_0_control_port_slave_writedata(15 downto 0)	 	 when switchs(4 downto 0) = "00110" else
									(0 => db_dma_0_control_port_slave_write_n(0), others => '0')	 when switchs(4 downto 0) = "00111" else
									(0 => db_dma_0_control_port_start(0), others => '0')				 when switchs(4 downto 0) = "01000" else
									db_bus_address_0(23 downto 0)												 when switchs(4 downto 0) = "01001" else
									(0 => db_bus_done_0, others => '0')										 when switchs(4 downto 0) = "01010" else
									db_bus_expecteddata_0(23 downto 0)										 when switchs(4 downto 0) = "01011" else
									(23 downto 8 => '0') & db_bus_new_dataindex_0						 when switchs(4 downto 0) = "01100" else
									(0 => db_bus_start_0, others => '0')									 when switchs(4 downto 0) = "01101" else
									db_bus_address_1(23 downto 0)			 									 when switchs(4 downto 0) = "01110" else
									(0 => db_bus_done_1, others => '0')										 when switchs(4 downto 0) = "01111" else
									db_bus_expecteddata_1(23 downto 0)										 when switchs(4 downto 0) = "10000" else
									(23 downto 8 => '0') & db_bus_new_dataindex_1						 when switchs(4 downto 0) = "10001" else
									(0 => db_bus_start_1, others => '0')									 when switchs(4 downto 0) = "10010" else
									x"FFFFFF";
		
		intenral_lag_0_user_delay <= '0' & switchs(8 downto 6) when switchs(5) = '0' else (others => '0');
		internal_lag_1_user_delay <= '0' & switchs(8 downto 6) when switchs(5) = '1' else (others => '0');
		internal_lags_go			  <= switchs(9);
		
		internal_entrada_up_0_external_connection_export(1)<= switchs(9);
		internal_entrada_up_1_external_connection_export(1 downto 0)<= switchs(9) & internal_entrada_up_0_external_connection_export(0);
		db_dma_0_control_port_start_n 							<= not db_dma_0_control_port_start;
		db_dma_0_control_port_slave_chipselect_n				<= not db_dma_0_control_port_slave_chipselect; 
		leds(7 downto 0)												<= internal_saida_up_0_external_connection_export;
		leds(8)															<= internal_entrada_up_0_external_connection_export(0);
		
end architecture;
	
	
	
	
	