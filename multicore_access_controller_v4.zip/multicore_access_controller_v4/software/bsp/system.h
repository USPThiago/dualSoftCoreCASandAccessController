/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'Nios_II_0' in SOPC Builder design 'multicore_access_controller_v4'
 * SOPC Builder design path: C:/ProjetosQuartus/multicore_access_controller_v4/quartus/multicore_access_controller_v4.sopcinfo
 *
 * Generated: Wed Oct 28 15:22:31 BRT 2026
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2_gen2"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x00004020
#define ALT_CPU_CPU_ARCH_NIOS2_R1
#define ALT_CPU_CPU_FREQ 50000000u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x00000000
#define ALT_CPU_CPU_IMPLEMENTATION "tiny"
#define ALT_CPU_DATA_ADDR_WIDTH 0x12
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x0000c020
#define ALT_CPU_FLASH_ACCELERATOR_LINES 0
#define ALT_CPU_FLASH_ACCELERATOR_LINE_SIZE 0
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 50000000
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 0
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 0
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_ILLEGAL_INSTRUCTION_EXCEPTION
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 0
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_ICACHE_SIZE 0
#define ALT_CPU_INST_ADDR_WIDTH 0x10
#define ALT_CPU_NAME "Nios_II_0"
#define ALT_CPU_OCI_VERSION 1
#define ALT_CPU_RESET_ADDR 0x0000c000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x00004020
#define NIOS2_CPU_ARCH_NIOS2_R1
#define NIOS2_CPU_FREQ 50000000u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x00000000
#define NIOS2_CPU_IMPLEMENTATION "tiny"
#define NIOS2_DATA_ADDR_WIDTH 0x12
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x0000c020
#define NIOS2_FLASH_ACCELERATOR_LINES 0
#define NIOS2_FLASH_ACCELERATOR_LINE_SIZE 0
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 0
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 0
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_ILLEGAL_INSTRUCTION_EXCEPTION
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 0
#define NIOS2_ICACHE_LINE_SIZE_LOG2 0
#define NIOS2_ICACHE_SIZE 0
#define NIOS2_INST_ADDR_WIDTH 0x10
#define NIOS2_OCI_VERSION 1
#define NIOS2_RESET_ADDR 0x0000c000


/*
 * Compare_and_Swap_0 configuration
 *
 */

#define ALT_MODULE_CLASS_Compare_and_Swap_0 Compare_and_Swap_v2
#define COMPARE_AND_SWAP_0_BASE 0x30000
#define COMPARE_AND_SWAP_0_IRQ -1
#define COMPARE_AND_SWAP_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define COMPARE_AND_SWAP_0_NAME "/dev/Compare_and_Swap_0"
#define COMPARE_AND_SWAP_0_SPAN 16
#define COMPARE_AND_SWAP_0_TYPE "Compare_and_Swap_v2"


/*
 * Custom instruction macros
 *
 */

#define ALT_CI_LAG_0(n,A,B) __builtin_custom_inii(ALT_CI_LAG_0_N+(n&ALT_CI_LAG_0_N_MASK),(A),(B))
#define ALT_CI_LAG_0_N 0x0
#define ALT_CI_LAG_0_N_MASK ((1<<5)-1)


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ACCESS_CONTROLLER_V3
#define __ALTERA_AVALON_ONCHIP_MEMORY2
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_TIMER
#define __ALTERA_NIOS2_GEN2
#define __COMPARE_AND_SWAP_V2
#define __LAG


/*
 * Entrada_Nios_II_0 configuration
 *
 */

#define ALT_MODULE_CLASS_Entrada_Nios_II_0 altera_avalon_pio
#define ENTRADA_NIOS_II_0_BASE 0x1000
#define ENTRADA_NIOS_II_0_BIT_CLEARING_EDGE_REGISTER 0
#define ENTRADA_NIOS_II_0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define ENTRADA_NIOS_II_0_CAPTURE 0
#define ENTRADA_NIOS_II_0_DATA_WIDTH 8
#define ENTRADA_NIOS_II_0_DO_TEST_BENCH_WIRING 0
#define ENTRADA_NIOS_II_0_DRIVEN_SIM_VALUE 0
#define ENTRADA_NIOS_II_0_EDGE_TYPE "NONE"
#define ENTRADA_NIOS_II_0_FREQ 50000000
#define ENTRADA_NIOS_II_0_HAS_IN 1
#define ENTRADA_NIOS_II_0_HAS_OUT 0
#define ENTRADA_NIOS_II_0_HAS_TRI 0
#define ENTRADA_NIOS_II_0_IRQ -1
#define ENTRADA_NIOS_II_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define ENTRADA_NIOS_II_0_IRQ_TYPE "NONE"
#define ENTRADA_NIOS_II_0_NAME "/dev/Entrada_Nios_II_0"
#define ENTRADA_NIOS_II_0_RESET_VALUE 0
#define ENTRADA_NIOS_II_0_SPAN 16
#define ENTRADA_NIOS_II_0_TYPE "altera_avalon_pio"


/*
 * MEM_Nios_II_0 configuration
 *
 */

#define ALT_MODULE_CLASS_MEM_Nios_II_0 altera_avalon_onchip_memory2
#define MEM_NIOS_II_0_ALLOW_IN_SYSTEM_MEMORY_CONTENT_EDITOR 0
#define MEM_NIOS_II_0_ALLOW_MRAM_SIM_CONTENTS_ONLY_FILE 0
#define MEM_NIOS_II_0_BASE 0xc000
#define MEM_NIOS_II_0_CONTENTS_INFO ""
#define MEM_NIOS_II_0_DUAL_PORT 0
#define MEM_NIOS_II_0_GUI_RAM_BLOCK_TYPE "AUTO"
#define MEM_NIOS_II_0_INIT_CONTENTS_FILE "multicore_access_controller_v4_MEM_Nios_II_0"
#define MEM_NIOS_II_0_INIT_MEM_CONTENT 1
#define MEM_NIOS_II_0_INSTANCE_ID "NONE"
#define MEM_NIOS_II_0_IRQ -1
#define MEM_NIOS_II_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define MEM_NIOS_II_0_NAME "/dev/MEM_Nios_II_0"
#define MEM_NIOS_II_0_NON_DEFAULT_INIT_FILE_ENABLED 1
#define MEM_NIOS_II_0_RAM_BLOCK_TYPE "AUTO"
#define MEM_NIOS_II_0_READ_DURING_WRITE_MODE "DONT_CARE"
#define MEM_NIOS_II_0_SINGLE_CLOCK_OP 0
#define MEM_NIOS_II_0_SIZE_MULTIPLE 1
#define MEM_NIOS_II_0_SIZE_VALUE 16384
#define MEM_NIOS_II_0_SPAN 16384
#define MEM_NIOS_II_0_TYPE "altera_avalon_onchip_memory2"
#define MEM_NIOS_II_0_WRITABLE 1


/*
 * Saida_Nios_II_0 configuration
 *
 */

#define ALT_MODULE_CLASS_Saida_Nios_II_0 altera_avalon_pio
#define SAIDA_NIOS_II_0_BASE 0x1020
#define SAIDA_NIOS_II_0_BIT_CLEARING_EDGE_REGISTER 0
#define SAIDA_NIOS_II_0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define SAIDA_NIOS_II_0_CAPTURE 0
#define SAIDA_NIOS_II_0_DATA_WIDTH 8
#define SAIDA_NIOS_II_0_DO_TEST_BENCH_WIRING 0
#define SAIDA_NIOS_II_0_DRIVEN_SIM_VALUE 0
#define SAIDA_NIOS_II_0_EDGE_TYPE "NONE"
#define SAIDA_NIOS_II_0_FREQ 50000000
#define SAIDA_NIOS_II_0_HAS_IN 0
#define SAIDA_NIOS_II_0_HAS_OUT 1
#define SAIDA_NIOS_II_0_HAS_TRI 0
#define SAIDA_NIOS_II_0_IRQ -1
#define SAIDA_NIOS_II_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define SAIDA_NIOS_II_0_IRQ_TYPE "NONE"
#define SAIDA_NIOS_II_0_NAME "/dev/Saida_Nios_II_0"
#define SAIDA_NIOS_II_0_RESET_VALUE 0
#define SAIDA_NIOS_II_0_SPAN 16
#define SAIDA_NIOS_II_0_TYPE "altera_avalon_pio"


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "Cyclone V"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/null"
#define ALT_STDERR_BASE 0x0
#define ALT_STDERR_DEV null
#define ALT_STDERR_TYPE ""
#define ALT_STDIN "/dev/null"
#define ALT_STDIN_BASE 0x0
#define ALT_STDIN_DEV null
#define ALT_STDIN_TYPE ""
#define ALT_STDOUT "/dev/null"
#define ALT_STDOUT_BASE 0x0
#define ALT_STDOUT_DEV null
#define ALT_STDOUT_TYPE ""
#define ALT_SYSTEM_NAME "multicore_access_controller_v4"


/*
 * Timer configuration
 *
 */

#define ALT_MODULE_CLASS_Timer altera_avalon_timer
#define TIMER_ALWAYS_RUN 0
#define TIMER_BASE 0x2000
#define TIMER_COUNTER_SIZE 32
#define TIMER_FIXED_PERIOD 0
#define TIMER_FREQ 50000000
#define TIMER_IRQ 0
#define TIMER_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_LOAD_VALUE 49999
#define TIMER_MULT 0.001
#define TIMER_NAME "/dev/Timer"
#define TIMER_PERIOD 1
#define TIMER_PERIOD_UNITS "ms"
#define TIMER_RESET_OUTPUT 0
#define TIMER_SNAPSHOT 1
#define TIMER_SPAN 32
#define TIMER_TICKS_PER_SEC 1000
#define TIMER_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_TYPE "altera_avalon_timer"


/*
 * access_controller_v3 configuration
 *
 */

#define ACCESS_CONTROLLER_V3_BASE 0x0
#define ACCESS_CONTROLLER_V3_IRQ -1
#define ACCESS_CONTROLLER_V3_IRQ_INTERRUPT_CONTROLLER_ID -1
#define ACCESS_CONTROLLER_V3_NAME "/dev/access_controller_v3"
#define ACCESS_CONTROLLER_V3_SPAN 4096
#define ACCESS_CONTROLLER_V3_TYPE "access_controller_v3"
#define ALT_MODULE_CLASS_access_controller_v3 access_controller_v3


/*
 * hal configuration
 *
 */

#define ALT_INCLUDE_INSTRUCTION_RELATED_EXCEPTION_API
#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER
#define ALT_TIMESTAMP_CLK none

#endif /* __SYSTEM_H_ */
