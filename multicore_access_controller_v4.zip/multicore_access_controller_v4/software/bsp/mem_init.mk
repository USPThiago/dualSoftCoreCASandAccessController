
#########################################################################
#######     M E M   I N I T    M A K E F I L E   C O N T E N T     ######
#########################################################################

#########################################################################
# This file is intended to be included by public.mk
#
#
# The following variables must be defined before including this file:
# - ELF
#
# The following variables may be defined to override the default behavior:
# - HDL_SIM_DIR
# - HDL_SIM_INSTALL_DIR
# - MEM_INIT_DIR
# - MEM_INIT_INSTALL_DIR
# - QUARTUS_PROJECT_DIR
# - SOPC_NAME
# - SIM_OPTIMIZE
# - RESET_ADDRESS
#
#########################################################################

#------------------------------------------------------------------------------
#                         The adjust-path macro
#
# If Make is launched from Windows through
# Windows Subsystem for Linux (WSL).  The adjust-path macro converts absolute windows 
# paths into unix style paths (Example: c:/dir -> /c/dir). 
# The adjust_path_mixed function converts WSL path to Windows path.
# This will ensure paths are readable by GNU Make.
#------------------------------------------------------------------------------

UNAME = $(shell uname -r)
ifeq ($(findstring Microsoft,$(UNAME)),Microsoft)
	WINDOWS_EXE = .exe
endif

eq = $(and $(findstring $(1),$(2)),$(findstring $(2),$(1)))

ifdef WINDOWS_EXE 
	adjust-path = $(if $1,$(shell wslpath "$1"),)
	adjust-path-mixed = $(if $(call eq,$(shell echo $1 | head -c 5),/mnt/),$(shell echo $1 | sed 's/\/mnt\///g;s/\//:\//1'),$1)
else # !WINDOWS_EXE
	adjust-path = $1
	adjust-path-mixed = $1
endif


ifeq ($(MEM_INIT_FILE),)
# MEM_INIT_FILE should be set equal to the working relative path to this
# mem_init.mk makefile fragment
MEM_INIT_FILE := $(wildcard $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST)))
endif

ifeq ($(ELF2DAT),)
ELF2DAT := elf2dat
endif

ifeq ($(ELF2HEX),)
ELF2HEX := elf2hex$(WINDOWS_EXE)
endif

ifeq ($(ELF2FLASH),)
ELF2FLASH := elf2flash$(WINDOWS_EXE)
endif

ifeq ($(FLASH2DAT),)
FLASH2DAT := flash2dat
endif

ifeq ($(ALT_FILE_CONVERT),)
ALT_FILE_CONVERT := alt-file-convert$(WINDOWS_EXE)
endif

ifeq ($(NM),)
NM := nios2-elf-nm$(WINDOWS_EXE)
endif

ifeq ($(MKDIR),)
MKDIR := mkdir -p
endif

ifeq ($(RM),)
RM := rm -f
endif

ifeq ($(CP),)
CP := cp
endif

ifeq ($(ECHO),)
ECHO := echo
endif

MEM_INIT_DIR ?= mem_init
HDL_SIM_DIR ?= $(MEM_INIT_DIR)/hdl_sim

ifdef QUARTUS_PROJECT_DIR
MEM_INIT_INSTALL_DIR ?= $(patsubst %/,%,$(QUARTUS_PROJECT_DIR))
ifdef SOPC_NAME
HDL_SIM_INSTALL_DIR ?= $(patsubst %/,%,$(QUARTUS_PROJECT_DIR))/$(SOPC_NAME)_sim
endif
endif

MEM_INIT_DESCRIPTOR_FILE ?= $(MEM_INIT_DIR)/meminit.spd

MEM_INIT_QIP_FILE ?= $(MEM_INIT_DIR)/meminit.qip

#-------------------------------------
# Default Flash Boot Loaders
#-------------------------------------

BOOT_LOADER_PATH ?= $(SOPC_KIT_NIOS2)/components/altera_nios2
BOOT_LOADER_CFI_LOC ?= $(BOOT_LOADER_PATH)/boot_loader_cfi.srec
BOOT_LOADER_CFI_BE_LOC ?= $(BOOT_LOADER_PATH)/boot_loader_cfi_be.srec

ifdef WINDOWS_EXE
	BOOT_LOADER_CFI=$(shell wslpath -w $(BOOT_LOADER_CFI_LOC))
	BOOT_LOADER_CFI_BE=$(shell wslpath -w $(BOOT_LOADER_CFI_BE_LOC))
else # !WINDOWS_EXE
	BOOT_LOADER_CFI=$(BOOT_LOADER_CFI_LOC)
	BOOT_LOADER_CFI_BE=$(BOOT_LOADER_CFI_BE_LOC)
endif

#-------------------------------------
# Default Target
#-------------------------------------

.PHONY: default_mem_init
ifeq ($(QSYS),1)
default_mem_init: mem_init_generate
else
default_mem_init: mem_init_install
endif
#-------------------------------------
# Runtime Macros
#-------------------------------------

define post-process-info
	@echo Post-processing to create $@...
endef

target_stem = $(notdir $(basename $@))

mem_start_address = $($(target_stem)_START)
mem_end_address = $($(target_stem)_END)
mem_span = $($(target_stem)_SPAN)
mem_width = $($(target_stem)_WIDTH)
mem_hex_width = $($(target_stem)_HEX_DATA_WIDTH)
mem_endianness = $($(target_stem)_ENDIANNESS)
mem_create_lanes = $($(target_stem)_CREATE_LANES)

mem_pad_flag = $($(target_stem)_PAD_FLAG)
mem_reloc_input_flag = $($(target_stem)_RELOC_INPUT_FLAG)
mem_no_zero_fill_flag = $($(target_stem)_NO_ZERO_FILL_FLAG)

flash_mem_epcs_flag = $($(target_stem)_EPCS_FLAGS)
flash_mem_cfi_flag = $($(target_stem)_CFI_FLAGS)
flash_mem_boot_loader_flag = $($(target_stem)_BOOT_LOADER_FLAG)

elf2dat_extra_args = $(mem_pad_flag)
elf2hex_extra_args = $(mem_no_zero_fill_flag)
elf2flash_extra_args = $(flash_mem_cfi_flag) $(flash_mem_epcs_flag) $(flash_mem_boot_loader_flag)
flash2dat_extra_args = $(mem_pad_flag) $(mem_reloc_input_flag)

#------------------------------------------------------------------------------
#                              BSP SPECIFIC CONTENT
#
# The content below is controlled by the BSP and SOPC System
#------------------------------------------------------------------------------
#START OF BSP SPECIFIC

#-------------------------------------
# Global Settings
#-------------------------------------


# The following TYPE comment allows tools to identify the 'type' of target this 
# makefile is associated with. 
# TYPE: BSP_MEMINIT_MAKEFILE

# This following VERSION comment indicates the version of the tool used to 
# generate this makefile. A makefile variable is provided for VERSION as well. 
# ACDS_VERSION: 20.1
ACDS_VERSION := 20.1

# This following BUILD_NUMBER comment indicates the build number of the tool 
# used to generate this makefile. 
# BUILD_NUMBER: 720

# Optimize for simulation
SIM_OPTIMIZE ?= 0

# The CPU reset address as needed by elf2flash
RESET_ADDRESS ?= 0x0000c000

# The specific Nios II ELF file format to use.
NIOS2_ELF_FORMAT ?= elf32-littlenios2

#-------------------------------------
# Pre-Initialized Memory Descriptions
#-------------------------------------

# Memory: MEM_Nios_II_0
MEM_0 := multicore_access_controller_v4_MEM_Nios_II_0
$(MEM_0)_NAME := MEM_Nios_II_0
$(MEM_0)_MEM_INIT_FILE_PARAM_NAME := INIT_FILE
HEX_FILES += $(MEM_INIT_DIR)/$(MEM_0).hex
MEM_INIT_INSTALL_FILES += $(MEM_INIT_INSTALL_DIR)/$(MEM_0).hex
DAT_FILES += $(HDL_SIM_DIR)/$(MEM_0).dat
HDL_SIM_INSTALL_FILES += $(HDL_SIM_INSTALL_DIR)/$(MEM_0).dat
SYM_FILES += $(HDL_SIM_DIR)/$(MEM_0).sym
HDL_SIM_INSTALL_FILES += $(HDL_SIM_INSTALL_DIR)/$(MEM_0).sym
$(MEM_0)_START := 0x0000c000
$(MEM_0)_END := 0x0000ffff
$(MEM_0)_SPAN := 0x00004000
$(MEM_0)_HIERARCHICAL_PATH := MEM_Nios_II_0
$(MEM_0)_WIDTH := 32
$(MEM_0)_HEX_DATA_WIDTH := 32
$(MEM_0)_ENDIANNESS := --little-endian-mem
$(MEM_0)_CREATE_LANES := 0

.PHONY: MEM_Nios_II_0
MEM_Nios_II_0: check_elf_exists $(MEM_INIT_DIR)/$(MEM_0).hex $(HDL_SIM_DIR)/$(MEM_0).dat $(HDL_SIM_DIR)/$(MEM_0).sym


#END OF BSP SPECIFIC

#-------------------------------------
# Pre-Initialized Memory Targets
#-------------------------------------

.PHONY: mem_init_install mem_init_generate mem_init_clean

ifeq ($(QSYS),1)
# Target mem_init_install is deprecated for QSys based systems
# To initialize onchip memories for Quartus II Synthesis with Qsys based systems:
#  1) Use "make mem_init_genearate"
#  2) Add the generated mem_init/meminit.qip file to your Quartus II Project
#
mem_init_install:
	$(error Deprecated Makefile Target: '$@'. Use target 'mem_init_generate' and then add $(MEM_INIT_QIP_FILE) to your Quartus II Project)

else # QSYS != 1, if SopcBuilder based system

ifneq ($(MEM_INIT_INSTALL_DIR),)
mem_init_install: $(MEM_INIT_INSTALL_FILES)
endif

ifneq ($(HDL_SIM_INSTALL_DIR),)
mem_init_install: $(HDL_SIM_INSTALL_FILES)
endif

mem_init_install: mem_init_generate
ifeq ($(MEM_INIT_INSTALL_DIR),)
	@echo "WARNING: MEM_INIT_INSTALL_DIR not set. Set your QUARTUS_PROJECT_DIR environment variable."
endif
ifeq ($(HDL_SIM_INSTALL_DIR),)
	@echo "WARNING: HDL_SIM_INSTALL_DIR not set. Set your QUARTUS_PROJECT_DIR and SOPC_NAME environment variable."
endif

$(MEM_INIT_INSTALL_FILES): $(MEM_INIT_INSTALL_DIR)/%: $(MEM_INIT_DIR)/%
	@$(MKDIR) $(@D)
	@$(CP) -v $< $@

$(HDL_SIM_INSTALL_FILES): $(HDL_SIM_INSTALL_DIR)/%: $(HDL_SIM_DIR)/%
	@$(MKDIR) $(@D)
	@$(CP) -v $< $@

endif # QSYS == 1


mem_init_generate: hex dat sym flash $(MEM_INIT_DESCRIPTOR_FILE) $(MEM_INIT_QIP_FILE)

mem_init_clean:
	@$(RM) -r $(MEM_INIT_DIR) $(HDL_SIM_DIR) $(FLASH_FILES)

.PHONY: hex dat sym flash

hex: check_elf_exists $(HEX_FILES)

dat: check_elf_exists $(DAT_FILES)

sym: check_elf_exists $(SYM_FILES)

flash: check_elf_exists $(FLASH_FILES)

#-------------------------------------
# Pre-Initialized Memory Rules
#-------------------------------------

.PHONY: check_elf_exists
check_elf_exists: $(call adjust-path,$(ELF))
ifeq ($(ELF),)
	$(error ELF var not set in mem_init.mk)
endif

$(filter-out $(FLASH_DAT_FILES),$(DAT_FILES)): %.dat: $(call adjust-path,$(ELF))
	$(post-process-info)
	@$(MKDIR) $(@D)
	$(ELF2DAT) --infile=$(call adjust-path-mixed,$<) --outfile=$@ \
		--base=$(mem_start_address) --end=$(mem_end_address) --width=$(mem_width) \
		$(mem_endianness) --create-lanes=$(mem_create_lanes) $(elf2dat_extra_args)

$(foreach i,0 1 2 3 4 5 6 7,%_lane$(i).dat): %.dat
	@true

ELF_TO_HEX_CMD_NO_BOOTLOADER = $(ELF2HEX) $(call adjust-path-mixed,$<) $(mem_start_address) $(mem_end_address) --width=$(mem_hex_width) \
			$(mem_endianness) --create-lanes=$(mem_create_lanes) $(elf2hex_extra_args) $@
			
ELF_TO_HEX_CMD_WITH_BOOTLOADER = $(ALT_FILE_CONVERT) -I $(NIOS2_ELF_FORMAT) -O hex --input=$(call adjust-path-mixed,$<) --output=$@ \
			--base=$(mem_start_address) --end=$(mem_end_address) --reset=$(RESET_ADDRESS) \
			--out-data-width=$(mem_hex_width) $(flash_mem_boot_loader_flag)

ELF_TO_HEX_CMD = $(strip $(if $(flash_mem_boot_loader_flag), \
	$(ELF_TO_HEX_CMD_WITH_BOOTLOADER), \
	$(ELF_TO_HEX_CMD_NO_BOOTLOADER) \
	))

$(HEX_FILES): %.hex: $(call adjust-path,$(ELF))
	$(post-process-info)
	@$(MKDIR) $(@D)
	$(ELF_TO_HEX_CMD)

$(SYM_FILES): %.sym: $(call adjust-path,$(ELF))
	$(post-process-info)
	@$(MKDIR) $(@D)
	$(NM) -n $(call adjust-path-mixed,$<) > $@

$(FLASH_FILES): %.flash: $(call adjust-path,$(ELF))
	$(post-process-info)
	@$(MKDIR) $(@D)
	$(ELF2FLASH) --input=$(call adjust-path-mixed,$<) --output=$@ --sim_optimize=$(SIM_OPTIMIZE) $(elf2flash_extra_args)

#
# Function generate_spd_entry
# Arg1: path to the memory initialization file
# Arg2: Type HEX or DAT
# Arg3: Output spd file to append
gen_spd_entry.BASE_FILE = $(basename $(notdir $1))
gen_spd_entry.PARAM_NAME = $($(gen_spd_entry.BASE_FILE)_MEM_INIT_FILE_PARAM_NAME)
gen_spd_entry.MEM_PATH = $($(gen_spd_entry.BASE_FILE)_HIERARCHICAL_PATH)
gen_spd_entry.SETTINGS = $(strip \
	path=\"$1\" \
	type=\"$2\" \
	$(if $(gen_spd_entry.PARAM_NAME),initParamName=\"$(gen_spd_entry.PARAM_NAME)\") \
	$(if $(gen_spd_entry.MEM_PATH),memoryPath=\"$(gen_spd_entry.MEM_PATH)\") \
)
define gen_spd_entry
$(ECHO) "<file $(gen_spd_entry.SETTINGS) />" >> $3
endef

$(MEM_INIT_DESCRIPTOR_FILE).DAT_FILESET := $(patsubst $(dir $(MEM_INIT_DESCRIPTOR_FILE))%,%,$(DAT_FILES))
$(MEM_INIT_DESCRIPTOR_FILE).HEX_FILESET := $(patsubst $(dir $(MEM_INIT_DESCRIPTOR_FILE))%,%,$(HEX_FILES))

$(MEM_INIT_DESCRIPTOR_FILE): %.spd: $(MEM_INIT_FILE)
	$(post-process-info)
	@$(MKDIR) $(@D)
	@$(RM) $@
	@$(ECHO) "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $@
	@$(ECHO) "<simPackage>" >> $@
	@$(foreach dat_file,$($@.DAT_FILESET),$(call gen_spd_entry,$(dat_file),DAT,$@) &&)true
	@$(foreach hex_file,$($@.HEX_FILESET),$(call gen_spd_entry,$(hex_file),HEX,$@) &&)true
	@$(ECHO) "</simPackage>" >> $@

.DELETE_ON_ERROR: $(MEM_INIT_DESCRIPTOR_FILE)

$(MEM_INIT_QIP_FILE): %.qip: $(MEM_INIT_FILE)
	$(post-process-info)
	@$(MKDIR) $(@D)
	@$(RM) $@
	@$(ECHO) "set_global_assignment -name SEARCH_PATH $$::quartus(qip_path)" > $@

.DELETE_ON_ERROR: $(MEM_INIT_QIP_FILE)
