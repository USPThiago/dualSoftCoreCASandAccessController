

#include <stdint.h>
#include "./../bsp/system.h"
#include "./../bsp/HAL/inc/io.h"
#include "./../bsp/HAL/inc/sys/alt_alarm.h"

/* Defitions of test cases address                                            */
#define TEST_1_ADDRESS  (UINT32_C(0x0004))                 /* test 1 address  */
#define TEST_2_ADDRESS  (UINT32_C(0x0008))                 /* test 2 address  */
#define TEST_3_ADDRESS  (UINT32_C(0x000C))                 /* test 3 address  */
#define TEST_4_ADDRESS  (UINT32_C(0x0010))                 /* test 4 address  */
#define TEST_5_ADDRESS  (UINT32_C(0x0014))                 /* test 5 address  */
#define TEST_6_ADDRESS  (UINT32_C(0x0018))                 /* test 6 address  */
#define TEST_7_ADDRESS  (UINT32_C(0x0004))                 /* test 7 address  */
#define TEST_8_ADDRESS  (UINT32_C(0x0008))                 /* test 8 address  */
#define TEST_9_ADDRESS  (UINT32_C(0x000C))                 /* test 9 address  */
#define TEST_10_ADDRESS (UINT32_C(0x0028))                 /* test 10 address */
#define TEST_11_ADDRESS (UINT32_C(0x0014))                 /* test 11 address */
#define TEST_12_ADDRESS (UINT32_C(0x0030))                 /* test 12 address */
#define TEST_13_ADDRESS (UINT32_C(0x0034))                 /* test 13 address */
#define TEST_14_ADDRESS (UINT32_C(0x0038))                 /* test 14 address */
#define TEST_15_ADDRESS (UINT32_C(0x0018))                 /* test 15 address */
#define TEST_16_ADDRESS (UINT32_C(0x0040))                 /* test 16 address */
#define TEST_17_ADDRESS (UINT32_C(0x0044))                 /* test 17 address */
#define TEST_18_ADDRESS (UINT32_C(0x0048))                 /* test 18 address */
#define TEST_19_ADDRESS (UINT32_C(0x004C))                 /* test 19 address */
#define TEST_20_ADDRESS (UINT32_C(0x0050))                 /* test 20 address */

/* Definitions of test cases expected values                                  */
#define TEST_1_EXPECTED_VALUES  (UINT32_C(0x00000000)) /* expected values 1 address  */
#define TEST_2_EXPECTED_VALUES  (UINT32_C(0x00000000)) /* expected values 2 address  */
#define TEST_3_EXPECTED_VALUES  (UINT32_C(0x00000000)) /* expected values 3 address  */
#define TEST_4_EXPECTED_VALUES  (UINT32_C(0x00000000)) /* expected values 4 address  */
#define TEST_5_EXPECTED_VALUES  (UINT32_C(0x00000000)) /* expected values 5 address  */
#define TEST_6_EXPECTED_VALUES  (UINT32_C(0x00000000)) /* expected values 6 address  */
#define TEST_7_EXPECTED_VALUES  (UINT32_C(0x00000001)) /* expected values 7 address  */
#define TEST_8_EXPECTED_VALUES  (UINT32_C(0x00000002)) /* expected values 8 address  */
#define TEST_9_EXPECTED_VALUES  (UINT32_C(0x00000003)) /* expected values 9 address  */
#define TEST_10_EXPECTED_VALUES (UINT32_C(0x00000000)) /* expected values 10 address */
#define TEST_11_EXPECTED_VALUES (UINT32_C(0x00000005)) /* expected values 11 address  */
#define TEST_12_EXPECTED_VALUES (UINT32_C(0x00000000)) /* expected values 12 address  */
#define TEST_13_EXPECTED_VALUES (UINT32_C(0x00000000)) /* expected values 13 address  */
#define TEST_14_EXPECTED_VALUES (UINT32_C(0x00000000)) /* expected values 14 address  */
#define TEST_15_EXPECTED_VALUES (UINT32_C(0x00000000)) /* expected values 15 address  */
#define TEST_16_EXPECTED_VALUES (UINT32_C(0x00000000)) /* expected values 16 address  */


/* Definitions of new data                                                          */
#define TEST_1_NEWDATA  (UINT32_C(0x00000001)) /* newdata 1 address                 */
#define TEST_2_NEWDATA  (UINT32_C(0x00000002)) /* newdata 2 address                 */
#define TEST_3_NEWDATA  (UINT32_C(0x00000003)) /* newdata 3 address                 */
#define TEST_4_NEWDATA  (UINT32_C(0x00000004)) /* newdata 4 address                 */
#define TEST_5_NEWDATA  (UINT32_C(0x00000005)) /* newdata 5 address                 */
#define TEST_6_NEWDATA  (UINT32_C(0x00000006)) /* newdata 6 address                 */
#define TEST_7_NEWDATA  (UINT32_C(0x00000007)) /* newdata 7 address                 */
#define TEST_8_NEWDATA  (UINT32_C(0x00000008)) /* newdata 8 address                 */
#define TEST_9_NEWDATA  (UINT32_C(0x00000009)) /* newdata 9 address                 */
#define TEST_10_NEWDATA (UINT32_C(0x0000000A)) /* newdata 10 address                */
#define TEST_11_NEWDATA (UINT32_C(0x0000000B)) /* newdata 1 address                */
#define TEST_12_NEWDATA (UINT32_C(0x0000000C)) /* newdata 2 address                */
#define TEST_13_NEWDATA (UINT32_C(0x0000000D)) /* newdata 3 address                */
#define TEST_14_NEWDATA (UINT32_C(0x0000000E)) /* newdata 4 address                */
#define TEST_15_NEWDATA (UINT32_C(0x0000000F)) /* newdata 5 address                */
#define TEST_16_NEWDATA (UINT32_C(0x00000010)) /* newdata 6 address                */

void wait_time(int delay_time){

    int start_time = alt_nticks();
    while(alt_nticks() - start_time < delay_time){}

    return;
}

int main(){

    int answers;
    int readdata;
    int go = 0;
    int delay = 3 * 1000;

    int led = 0;
    int counter = 0;
    int inittick = 0;
    int delay_debug = 2 * 1000;

    /* teste 1 : CAS não simultâneo e não concorrente            - Nucleo 0 escreve endereço de memória                 */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x02);

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
            if(alt_nticks() -  inittick > delay_debug){
                counter++;
                led = (counter % 2) + 1;
                IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, led);
                inittick = alt_nticks();
            }
        } 
        go = 0;

        IOWR_32DIRECT(COMPARE_AND_SWAP_0_BASE,0,TEST_1_NEWDATA);       
        answers = (uint32_t)ALT_CI_LAG_0(0, TEST_1_ADDRESS, TEST_1_EXPECTED_VALUES);   

        if(answers != 0){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x81);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x41);
        }          
        
        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        }
        go = 0;       

    /* teste 2 : CAS não simultâneo e não concorrente            - Nucleo 1 escreve endereço de memória                 */

        while(go == 0){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;       

    /* teste 3 : CAS simultâneo e não concorrente                - Nucleo 1 inicia escrita durante escrita de núcleo 0  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x03);

        while(go == 0){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        IOWR_32DIRECT(COMPARE_AND_SWAP_0_BASE,0,TEST_3_NEWDATA);       
        answers = (uint32_t)ALT_CI_LAG_0(0, TEST_3_ADDRESS, TEST_3_EXPECTED_VALUES);   
            
        if(answers != 0){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x83);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x43);
        }          
        wait_time(delay);                                                      
        go = 0;       

    /* teste 4 : CAS simultâneo e não concorrente                - Nucleo 0 inicia escrita durante escrita de núcleo 1  */

        while(go == 0){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        wait_time(delay);                                                      
        go = 0;       
    
    /* teste 5 : WAW - CAS simultâneo e concorrente  			 - Nucleo 1 inicia escrita durante escrita de núcleo 0  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x05);

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        IOWR_32DIRECT(COMPARE_AND_SWAP_0_BASE,0,TEST_5_NEWDATA);       
        answers = (uint32_t)ALT_CI_LAG_0(0, TEST_5_ADDRESS, TEST_5_EXPECTED_VALUES);   
            
        if(answers != 0){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x85);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x45);
        }          
        wait_time(delay);                                                      
        go = 0;  

    /* teste 6 : WAW - CAS simultâneo e concorrente  			 - Nucleo 1 inicia escrita durante escrita de núcleo 1  */

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        wait_time(delay);                                                      
        go = 0;       
 
    /* teste 7 : Leitura não simultânea e não concorrente 	     - Nucleo 0 lê enndereço de memória					    */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x07);
      
        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        readdata = IORD_32DIRECT(TEST_7_ADDRESS, 0);

        if(readdata == TEST_7_EXPECTED_VALUES){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x87);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x47);
        } 

        wait_time(delay);                                                      
        go = 0;       

    /* teste 8 : Leitura não simultânea e não concorrente 	     - Nucleo 1 lê enndereço de memória					    */

        while(go == 0){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;

    /* teste 9 : leitura simultânea e não concorrente 		     - Núcleo 1 inicia leitura durante leitura de núcleo 0  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x09);
        
        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        if(readdata == TEST_9_EXPECTED_VALUES){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x89);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x49);
        } 

        readdata = IORD_32DIRECT(TEST_9_ADDRESS, 0);

        wait_time(delay);                                                      
        go = 0; 

    /* teste 10: leitura simultânea e não concorrente 		     - Núcleo 0 inicia leitura durante leitura de núcleo 1  */

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;        

    /* teste 11: Leitura simultânea e concorrente	   			 - Núcleo 1 inicia leitura durante leitura de núcleo 0  */
        
        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x0B);

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 

        readdata = IORD_32DIRECT(TEST_11_ADDRESS, 0);

        if(readdata == TEST_11_EXPECTED_VALUES){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x8B);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x4B);
        } 

        wait_time(delay);                                                      
        go = 0; 

    /* teste 12: Leitura simultânea e concorrente	   			 - Núcleo 0 inicia leitura durante leitura de núcleo 1  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x0C);   

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;    

    /* teste 13: WAR - escrita simultânea a leitura   			 - Núcleo 1 inicia escrita durante leitura de núcleo 0  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x0D);

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;   

    /* teste 14: WAR - escrita simultânea a leitura   			 - Núcleo 0 inicia escrita durante leitura de núcleo 1  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x0E);

        while(go != 1){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;       

    /* teste 15: RAW - leitura simultânea a escrita   			 - Núcleo 1 inicia leitura durante escrita de núcleo 0  */

        IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x0F);

        IOWR_32DIRECT(COMPARE_AND_SWAP_0_BASE,0,TEST_15_NEWDATA);       
        answers = (uint32_t)ALT_CI_LAG_0(0, TEST_15_ADDRESS, TEST_15_EXPECTED_VALUES);   
      
        while(go == 0){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);            
        }     

        if(answers != 0){
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x8F);
        }         
        else{ 
            IOWR_8DIRECT(SAIDA_NIOS_II_0_BASE, 0, 0x4F);
        }

        wait_time(delay);                                                      
        go = 0;       

    /* teste 16: RAW - leitura simultânea a escrita   			 - Núcleo 0 inicia leitura durante escrita de núcleo 1  */

        while(go == 0){
            go = IORD_8DIRECT(ENTRADA_NIOS_II_0_BASE, 0);
        } 
        wait_time(delay);                                                      
        go = 0;   


    return 0;
}

